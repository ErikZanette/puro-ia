# Curso Introdução à Carnívora: Bloco 6 (a real sobre as plantas)

Bloco 6 - Real sobre as Plantas
Bloco 6 - Real sobre as plantas 

6.1 Introdução – Botânica 101: O que as plantas realmente querem?
Plantas são seres vivos e, como qualquer outro organismo, seu principal objetivo é sobreviver e se reproduzir. Mas, ao contrário dos animais, que podem fugir ou se defender fisicamente de predadores, as plantas estão presas ao solo. Elas não têm dentes, garras ou músculos para escapar do perigo. Então, como elas evitam serem devoradas?
A resposta está na química. Ao longo de milhões de anos, as plantas desenvolveram um arsenal de compostos químicos para desencorajar predadores, sejam eles insetos, fungos, bactérias ou mamíferos famintos. Algumas criam espinhos ou possuem cascas duras, mas a grande maioria aposta em algo muito mais sofisticado: toxinas e antinutrientes que interferem diretamente no organismo de quem as consome.
Agora, pare e pense: quando vemos um leão caçando uma zebra, fica óbvio que o leão quer comer e que a zebra quer fugir. Mas e quando olhamos para uma bela salada verde no prato? Nosso instinto nos diz que aquilo é natural e saudável. Ou seria o que foi programado no nosso cérebro desde criança? Afinal se ouvissemos que o seu é vermelho desde criança, iríamos pensar que a cor azul é vermelho…A maioria de nós sempre ouviu desde criança: “Coma seus vegetais que são importantes…”Mas nunca ouvimos “Com essa carne gordurosa que é essencial pra você…” E o interessante é que existe umas das tecnologias mais avançadas criadas pelo homem para nos dar uma noção. A lingua!!!!!
O paladar é uma incrível ferramenta evolucionária que nos permite saber se algo é seguro ou perigoso para comer.
O azedo que sentimos em vegetais como espinafre
O picante que sentimos em vegetais como pimentas ou mostarda
O amargo de muitas folhas e sementes
O gosto zero que sentimos na salada…
Tudo isso são sinais de alerta do nosso corpo. Essas sensações desagradáveis ou até a falta de sensação, não são um erro – é uma ferramenta que se aperfeiçoou por milhões de anos.Perigoso = azedo, picante, amargoSem gosto = sem nutriente
Agora compare com a carne gordurosa: suculenta, macia, cheia de sabor. Isso não é coincidência. Nosso cérebro foi moldado para buscar e gostar da gordura animal, porque ela é nutritiva e foi essencial para nossa evolução.
Nota: Óbvio que os ultraprocessados não se encaixam aqui, pois eles foram criados em laboratório para “burlar” esse sistema evolucionário, enganando nosso paladar. Mas vamos voltar ao que interessa...
Se você não entendeu ainda, esses gostos (alertas) que sentimos é a detecção dos mecanismos de defesa das plantas. Pois o jeito que elas atacam é invisível.
Esse "jogo da sobrevivência" entre plantas e animais vem acontecendo há milhões de anos. Enquanto as plantas criam novos compostos para afastar predadores, certos animais evoluem maneiras de resistir a essas substâncias. Não todas, apenas substâncias específicas. Um exemplo clássico são os coalas, que se alimentam quase exclusivamente de folhas de eucalipto – uma planta altamente tóxica para a maioria das espécies. Mas ele não se alimenta de mais nenhuma planta, pois não desenvolveu as defesas necessárias. O mesmo acontece com os pandas e o bambu. Esses animais desenvolveram adaptações específicas para consumir essas plantas sem morrer no processo.
Se diferentes espécies têm adaptações únicas para consumir certos vegetais, isso significa que nós, humanos, também temos restrições naturais. O fato de podermos comer algo não significa que ele seja ideal para o nosso corpo. Apenas significa que conseguimos tolerar os mecanismos de defesa até certo ponto – mas será que essa tolerância nos protege dos efeitos negativos no longo prazo?
Muitas pessoas argumentam que "a dose faz o veneno", ou seja, que pequenas quantidades de substâncias tóxicas não causariam danos significativos. Mas será que isso realmente faz sentido? Vamos pensar em um exemplo extremo: a cicuta, uma planta que parece inofensiva, mas é tão tóxica que pode matar um ser humano em poucas horas. Foi justamente a cicuta que matou Sócrates, envenenado deliberadamente como parte de sua sentença de morte na Grécia Antiga. A toxina presente nesta planta, chamada coniína, ataca o sistema nervoso e paralisa os músculos até que a vítima pare de respirar.
Agora, imagine que, em vez de ingerir uma dose letal de cicuta — algo entre 6 a 8 gramas das folhas frescas ou 0,5 a 1 grama de coniína pura —, você consumisse apenas 0,1 grama todos os dias. Isso faria bem para a sua saúde? Ou, no longo prazo, você ainda estaria constantemente se intoxicando, mesmo que de forma sutil?
Essa é a grande questão: só porque algo não nos mata na hora, não significa que ele seja inofensivo. Muitas substâncias presentes nas plantas podem gerar efeitos negativos acumulativos – inflamação crônica, distúrbios digestivos, problemas hormonais, entre outros. No mundo moderno, onde estamos constantemente expostos a estresse, toxinas ambientais e alimentos processados, será que faz sentido adicionar pequenas doses diárias de compostos vegetais potencialmente prejudiciais ao nosso corpo?
E se vocês não sabem, mais de 99,9% de todas as plantas ao redor do mundo não fazem parte da nossa alimentação diária, e a vasta maioria delas contêm toxinas perigosas ou letais para os humanos. Se você se perdesse em uma floresta e começasse a comer folhas e frutos aleatórios, haveria uma grande chance de passar mal instantaneamente – ou até não sair vivo de lá.
Mas e os vegetais que consumimos no dia a dia? Não ouvimos a vida toda que eles são essenciais para a saúde? Se as plantas possuem compostos tóxicos para se defender, será que consumi-las sem critério é realmente uma boa ideia?
No próximo bloco, vamos explorar quais são esses mecanismos de defesa e como eles podem afetar o corpo humano. Você pode se surpreender com o que a ciência já sabe sobre o assunto.

6.2 Mecanismos de defesa Químicos

Muitas pessoas acreditam que precisamos comer vegetais para obter certos nutrientes essenciais, mas a verdade é que não existe nada nas plantas que não possamos encontrar na carne. Todos os aminoácidos essenciais, vitaminas e minerais que nosso corpo necessita podem ser obtidos a partir de alimentos de origem animal. Na verdade, existem nutrientes na carne que não encontramos em plantas, como a vitamina B12
E o pior de tudo: como já sabemos, as plantas vêm equipadas com mecanismos químicos para se defender dos predadores. Como vimos no bloco anterior, a maioria das plantas ao redor do mundo são mortais para os humanos. Mas o mais surpreendente é que até mesmo os vegetais que fazem parte da nossa alimentação diária possuem compostos poderosos, capazes de interferir na digestão, bloquear a absorção de nutrientes e até causar toxicidade quando consumidos regularmente.
A seguir, vamos entrar em detalhes sobre esses mecanismos de defesa e como eles podem afetar nossa saúde.
Antinutrientes
Os antinutrientes são compostos presentes em muitas plantas que reduzem a absorção de minerais essenciais pelo nosso corpo e podem causar deficiências nutricionais, doenças metabólicas e até problemas renais.
🔸 Ácido Fítico
Presente em grãos, sementes e leguminosas.
Liga-se a minerais como zinco, ferro, cálcio e magnésio, impedindo a absorção pelo corpo.
Consequências: deficiências minerais, fraqueza óssea (por falta de cálcio), anemia (por falta de ferro) e imunidade comprometida.
🔸 Oxalatos
Presentes em vegetais como espinafre, beterraba e acelga.
Ligam-se ao cálcio, formando cristais que podem levar à formação de pedras nos rins e contribuir para gota e artrite (devido à deposição de cristais nas articulações).
Consequências: dor crônica, inflamação articular, problemas renais e aumento do risco de deficiência de cálcio.
🔸 Inibidores de Protease
Encontrados na soja e em outras leguminosas.
Dificultam a digestão das proteínas, o que pode causar desconforto digestivo e reduzir a eficiência da absorção de aminoácidos essenciais.
Consequências: dificuldade de ganho de massa muscular, baixa recuperação muscular, inchaço abdominal e má digestão.

Toxinas Naturais
As toxinas naturais são compostos que as plantas produzem para afastar predadores, mas que também afetam negativamente os seres humanos. Elas podem danificar o intestino, prejudicar a absorção de nutrientes e alterar o sistema imunológico.
🔸 Lectinas
Presentes em grãos e leguminosas, como feijão e trigo.
Danificam a parede intestinal, aumentando a permeabilidade intestinal (leaky gut), o que pode levar a inflamações crônicas e contribuir para doenças autoimunes como artrite reumatoide e doença de Crohn.
Consequências: distúrbios digestivos, inflamação sistêmica, fadiga crônica e sensibilidades alimentares.
🔸 Saponinas
Presentes na quinoa e na soja.
Podem perfurar a membrana das células intestinais, comprometendo a integridade do sistema digestivo e facilitando a entrada de toxinas e antígenos na corrente sanguínea.
Consequências: leaky gut, inflamação intestinal, intolerâncias alimentares e baixa imunidade.
🔸 Glucosinolatos
Encontrados nos vegetais crucíferos como brócolis, couve e couve-flor.
Interferem na função da tireoide, dificultando a absorção de iodo e levando a hipotireoidismo e desequilíbrios hormonais.
Consequências: cansaço extremo, ganho de peso, frio constante e queda de cabelo.

Disruptores Hormonais
Algumas plantas possuem compostos que interferem diretamente no nosso sistema hormonal, imitando ou bloqueando hormônios essenciais.
🔸 Fitoestrógenos
Presentes na soja.
Imitam o estrogênio humano e podem causar desequilíbrios hormonais, afetando a fertilidade, o ciclo menstrual e o metabolismo.
Consequências: redução da testosterona nos homens, infertilidade, retenção de líquidos e dificuldade para perder gordura corporal.
🔸 Goitrogênios
Encontrados em vegetais crucíferos como brócolis, couve e rúcula.
Prejudicam a função da tireoide, dificultando a produção dos hormônios essenciais para o metabolismo.
Consequências: hipotireoidismo, ganho de peso, cansaço, depressão e dificuldade de concentração.

Neurotoxinas
Algumas plantas produzem compostos neurotóxicos, que afetam diretamente o funcionamento do sistema nervoso. Esses compostos interferem na comunicação entre os neurônios, podendo causar náuseas, confusão mental, alucinações, convulsões, paralisia e até morte, dependendo da dose.
🔸 Solanina
Presente em batatas (especialmente quando verdes ou brotadas), tomates e berinjelas.
Pode ser tóxica em grandes quantidades, causando náusea, vômito, diarreia, confusão mental, alucinações e dificuldades neurológicas mais graves, como paralisia e convulsões em casos extremos.
Venenos MortaisAntes de finalizar, eu queria falar como um bônus a minha descoberta preferida — que é a que me deixa perplexo até hoje. A presença de cianeto nas amêndoas. Sim, cianeto, aquele veneno mortal que já foi usado ao longo da história para assassinatos e execuções. O corpo humano não tolera altas doses dessa substância, pois ela bloqueia a capacidade das células de utilizarem oxigênio, levando à morte em poucos minutos.
O mais surpreendente é que as amêndoas amargas, uma variação das amêndoas comuns, contêm quantidades altíssimas de amigdalina, um composto que libera cianeto quando mastigado. Estima-se que consumir apenas 100g de amêndoas amargas pode ser letal para um adulto. Isso sem contar que crianças ou pessoas mais sensíveis podem ter problemas com doses ainda menores.
Mas não são só as amêndoas. Outros alimentos comuns também carregam esse veneno escondido. A linhaça, muito usada em pães, vitaminas e dietas "fitness", também contém compostos que liberam cianeto. E a mandioca, um alimento típico em várias regiões do Brasil, especialmente a versão crua ou mal preparada, é outra fonte conhecida de cianeto. Mesmo a farinha de mandioca e a tapioca carregam esse risco, especialmente se não forem bem processadas.
Então, será que precisamos mesmo desse prato colorido? Será que esse tal "equilíbrio" faz sentido? O que as pessoas querem dizer quando falam de balancear a alimentação? Ah, eu quero 50% de nutrientes e 50% de oxalatos e lectinas. O balanço perfeito, né? Hahaha, não, obrigado! Eu prefiro receber 100% de nutrição e 0% de antinutrientes. E é exatamente isso que acontece na dieta carnívora.

6.3 Antes vs Depois
Muitas pessoas acham que as frutas são "inofensivas", já que são o jeito das plantas se proliferarem. A verdade é que, ainda assim, a maioria das frutas não é comestível para humanos e são extremamente tóxicas. Elas querem que alguém transporte suas sementes — não necessariamente a gente.
Um exemplo clássico é o casuar, uma ave gigante da Austrália. Ele evoluiu e é adaptado para comer frutas específicas que seriam altamente tóxicas para humanos, como a Cassowary Plum. Algumas dessas plantas dependem exclusivamente dele para dispersar suas sementes. Se você comesse essas frutas, provavelmente não sairia vivo pra contar a história.
É claro que, se você comparar comer frutas com comer açúcar refinado e ultraprocessados, provavelmente as frutas vão ser uma escolha melhor para a saúde. Mas existe um fato bem interessante, que talvez pouca gente saiba, e é o que eu quero focar nesse submódulo:
As frutas de hoje em dia vêm sendo cada vez mais alteradas geneticamente para terem mais "carne" (polpa), serem mais doces e visualmente mais atraentes.
Tudo isso foi feito para nos induzir a comer mais, tornando essas frutas super palatáveis, muito diferentes do que um dia já foram.

Sem brincadeira. Vamos ver o antes e depois de algumas frutas, e você pode tirar suas próprias conclusões:
1. Banana
Antes: Cheia de sementes duras e quase impossível de comer.
Depois: Doce, macia, praticamente sem sementes, criada para ser fácil de comer e digerir.
Nota: A banana que você compra no mercado hoje é um híbrido criado pelo homem, principalmente das espécies Musa acuminata e Musa balbisiana.

2. Melancia
Antes: Pequena, com polpa pálida e cheia de sementes grandes e duras.
Depois: Imensa, quase toda feita de água e açúcar, com muito mais polpa e menos sementes.
Nota: A melancia moderna tem muito mais frutose que a original, e praticamente nenhuma semelhança com a versão ancestral que existia há 5000 anos.

3. Tomate
Antes: Pequeno, com casca grossa, sabor amargo e cheio de sementes.
Depois: Grande, suculento, doce e com casca fina, criado para ser mais palatável e visualmente atrativo.
Nota: O tomate que conhecemos hoje é resultado de séculos de seleção artificial. As variedades selvagens tinham pouca polpa, eram ácidas e amargas, e muitas pessoas evitavam comer tomate cru até o século XIX, quando passou a ser cultivado para consumo direto.

4. Maçã
Antes: Azeda, dura e com muita fibra.
Depois: Super doce, com muita polpa, quase sem acidez.
Nota: A maçã moderna tem até 50 vezes mais açúcar do que suas antecessoras selvagens.

5. Milho
Antes: Um capim duro e quase sem grão, chamado teosinto, com apenas 5 cm de comprimento e poucas sementes duras.
Depois: A espiga de milho que conhecemos hoje foi inteiramente criada pelo homem, com grãos grandes, doces e fáceis de comer.
Nota: O milho moderno tem muito mais açúcar e quase não se parece com o original.

6. Pêssego
Antes: Pequeno, com muita pele, polpa dura e sabor amargo.
Depois: Grande, suculento, doce e com polpa macia, fácil de comer e com menos taninos.
Nota: O pêssego moderno é resultado de milhares de anos de seleção artificial. O pêssego selvagem original tinha apenas cerca de 2 a 4 centímetros, com polpa seca e amarga e um caroço enorme. Hoje, ele é até 64 vezes maior, muito mais doce e praticamente irreconhecível em relação ao ancestral.
E para vocês que pensam que as frutas consideradas seguras são inofensivas, tente derrubar suco de limão na sua pele e tomar sol. Vai ser bem desagradável e pode causar queimaduras sérias. Isso se chama fitofotodermatite. Mas não para por aí. Existem outras frutas e plantas que fazem o mesmo. O figo, por exemplo, pode causar irritações e queimaduras químicas na pele por causa do látex que ele libera. A manga verde, especialmente a casca e a seiva, pode causar dermatite severa em quem encostar ou manipular sem proteção, já que ela contém urushiol — o mesmo composto tóxico encontrado na hera venenosa. Ou seja, como estamos vendo, as plantas e as frutas não são tão inofensivas quanto pensávamos.
Agora vem a parte que quase ninguém sabe:
Também existem vegetais que não só foram modificados, mas nunca existiram na natureza como os conhecemos hoje. Eles foram criados do zero pelos seres humanos, através de manipulação seletiva ao longo dos séculos.
Por exemplo:
Brócolis — Não é uma planta "natural". Ele foi desenvolvido a partir da mostarda selvagem (Brassica oleracea) através de seleção artificial, pelos romanos, por volta do século 6 a.C..
Couve-flor, couve-de-bruxelas, repolho e couve — Também vieram da mesma planta original, a Brassica oleracea, e só existem do jeito que conhecemos hoje graças à manipulação humana intencional.
Ou seja:

Esses vegetais e frutas não são simplesmente presentes da natureza, como muita gente pensa. Eles foram moldados e manipulados pelo homem ao longo de milhares de anos para atender aos nossos interesses.

6.4 Recapitulando
Quem diria, hein? As plantas, que estão na Terra há milhões de anos antes de nós, não são tão inofensivas assim.

Nesse modulo, aprendemos que a natureza é um verdadeiro campo de batalha. Plantas e animais estão presos em uma guerra evolucionária há milhões de anos. De um lado, as plantas tentam se proteger tornando-se mais tóxicas, desenvolvendo compostos químicos para afastar predadores. Do outro, certos animais evoluem resistências específicas a essas toxinas, mas sempre dentro de um contexto limitado.

Também exploramos os diferentes mecanismos de defesa das plantas, como antinutrientes que impedem a absorção de minerais, toxinas naturais que podem afetar o sistema digestivo e nervoso, e compostos como oxalatos e lectinas, que podem causar desde inflamação até problemas renais. Até mesmo alimentos considerados "saudáveis", como espinafre e amêndoas, carregam altas doses de substâncias que podem ser prejudiciais ao nosso corpo.

Além disso, vimos como muitas das frutas e vegetais que consumimos hoje não são simplesmente presentes da natureza, mas sim alimentos criados e manipulados pelo homem ao longo de milhares de anos. Eles foram selecionados para serem mais doces, maiores e mais atrativos — não necessariamente mais saudáveis ou adequados para a nossa biologia. Quando comparamos o "antes e depois" desses alimentos, fica claro o quanto nos afastamos do que é natural.

Pra mim é  bem claro: Nós, humanos, não evoluímos para comer um tipo específico de planta. Em vez disso, criamos técnicas como cozimento, fermentação e processamento para tentar minimizar os danos das toxinas vegetais. Mas se precisamos de tantos truques para "tornar seguro" um alimento, será que ele deveria estar no nosso prato? Quando olhamos para a carne, a resposta fica clara: não precisamos neutralizar nada para consumi-la. Ela já vem pronta para nos nutrir da melhor forma possível.
