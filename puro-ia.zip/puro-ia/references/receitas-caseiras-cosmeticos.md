# Lista de Compras e Receitas Caseiras (cosméticos caseiros sem água)

Lista de Compras e Receitas Caseiras
Complemento do material "A Indústria da Beleza": o que comprar e como fazer em casa as trocas da lista verde.
Antes de começar
Toda receita deste material é feita sem água. Essa é a regra que deixa o caseiro seguro.
Por que sem água. Onde tem água, crescem fungo e bactéria em poucos dias. Por isso todo creme, loção e tônico industrial precisa de conservante, e conservante caseiro não funciona de verdade. Bálsamo, manteiga, óleo e pó não têm água, então não precisam de conservante nenhum. A única exceção é a máscara de argila, que é feita na hora e não é guardada.
Higiene:
Lave os utensílios e os potes, passe álcool 70% e deixe secar completamente. Uma gota de água no pote já basta para estragar.
Use uma panela e uma espátula só para isso, separadas da cozinha.
Não enfie o dedo molhado no pote. Use uma espátula limpa ou retire com a mão seca.
Pese, não meça. As receitas estão em gramas. Uma balança de cozinha simples resolve e deixa o resultado igual toda vez.
Teste antes. Passe um pouco na parte de dentro do braço e espere 24 horas. Natural também pode dar alergia, principalmente em pele sensível.
Validade. Em geral, de 6 a 12 meses, guardado em pote fechado, longe do sol e do calor. Jogue fora se:
o cheiro ficar rançoso, de óleo velho;
mudar de cor;
aparecer qualquer ponto de mofo.
Calor. Sebo, óleo de coco e manteigas amolecem no calor. Em dia quente, derreter um pouco é normal e não estraga o produto. Se incomodar, guarde na geladeira ou aumente um pouco a cera de abelha da receita.
Lista de compras
Com 14 ingredientes dá para fazer todas as receitas. Não precisa comprar tudo de uma vez: comece pelos da primeira tabela.
O básico (faz a maior parte das receitas)
Ingrediente | Para que serve | O que observar na compra
Sebo bovino | Base do bálsamo, do labial e da pomada | De preferência de boi criado a pasto. Pode comprar já purificado ou fazer em casa com sebo de boi
Cera de abelha | Dá firmeza ao labial e à pomada | Pura, amarela ou branca, sem parafina misturada. Em bloco ou em pastilhas
Manteiga de karité | Hidrata e dá cremosidade | Crua (não refinada) tem mais nutrientes; a refinada tem menos cheiro. As duas servem
Manteiga de cacau | Hidrata e dá firmeza | Pura, sem açúcar nem aroma. Tem cheiro natural de chocolate
Óleo de coco | Base do desodorante e da manteiga corporal | Extravirgem, prensado a frio. Derrete acima de uns 24 °C
Azeite de oliva | Amolece as receitas e serve de demaquilante | Extravirgem, o mesmo da cozinha
Bicarbonato de sódio | Desodorante e pó dental | O comum de supermercado, puro
Argila branca (caulim) | Pó dental e máscara | Pura, para uso cosmético, sem corante nem perfume

Para completar
Ingrediente | Para que serve | O que observar na compra
Araruta ou amido de milho | Absorve umidade no desodorante | Puro, de supermercado
Óxido de zinco | Pomada de assadura e desodorante para pele sensível | Grau cosmético ou farmacêutico, "non-nano". É um pó muito fino: use máscara ao manusear
Hidroxiapatita | Ajuda a remineralizar o esmalte no pó dental | Grau cosmético, em pó
Óleo de jojoba | Hidrata sem pesar, bom para rosto e demaquilante | Puro, prensado a frio
Vitamina E (tocoferol) | Retarda o ranço dos óleos | Pura, em óleo. Antioxidante, não conservante: não substitui a regra do sem água
Sabão de castela | Limpar pele e corpo | Em barra, base de azeite, sem fragrância. Melhor comprar pronto: fazer sabão exige soda cáustica

Utensílios
Balança de cozinha
Panela pequena e uma tigela de vidro ou inox para banho-maria, só para isso
Espátula de silicone
Potes de vidro com tampa (âmbar protege melhor da luz)
Tubos vazios para protetor labial
Batedeira ou fouet, para deixar o bálsamo aerado (opcional)
Máscara simples, para mexer com pós finos como óxido de zinco e argila
Receitas
Todas usam banho-maria: uma tigela de vidro ou inox apoiada sobre uma panela com um pouco de água em fogo baixo, sem a água encostar na tigela. Derreter em fogo direto queima as gorduras.
1. Como purificar o sebo em casa
Se comprar o sebo já purificado, pule esta parte.
Ingrediente: 1 kg de sebo bovino (peça com o açougueiro). Rende cerca de 700 g.
Tire as partes de carne e de sangue e pique o sebo em cubos pequenos, ou passe no processador.
Coloque numa panela de fundo grosso, em fogo bem baixo, sem água. Mexa de vez em quando.
Em 2 a 3 horas a gordura derrete e sobram pedacinhos dourados. Não deixe fritar nem escurecer.
Coe num pano limpo de algodão ou filtro de café. Coe duas vezes se quiser mais branco e com menos cheiro.
Guarde em pote de vidro. Fica branco e firme ao esfriar. Validade: 12 meses fora da geladeira, mais na geladeira.
2. Bálsamo de sebo (hidratante de rosto e corpo)
O hidratante do dia a dia. Substitui creme com petrolato, PEG e conservante.
Ingredientes:
75 g de sebo purificado
25 g de azeite ou óleo de jojoba
Opcional: 5 gotas de vitamina E
Modo de fazer:
Derreta o sebo em banho-maria.
Tire do fogo e misture o azeite (ou jojoba) e a vitamina E.
Passe para o pote e deixe firmar em temperatura ambiente.
Para uma textura mais leve: leve à geladeira por 20 a 30 minutos, até começar a firmar nas bordas, e bata com a batedeira por 3 a 5 minutos até ficar aerado.
Validade: 6 meses. Uso: pouca quantidade, aquecida entre as mãos. Serve para criança. Para pele oleosa, use jojoba em vez de azeite.
3. Protetor labial
Substitui o labial com petrolato, BHA, açúcar e corante.
Ingredientes (rende uns 6 tubos):
10 g de cera de abelha
10 g de manteiga de cacau ou de karité
10 g de sebo ou óleo de coco
Modo de fazer:
Derreta a cera primeiro em banho-maria, porque ela demora mais.
Junte a manteiga e o sebo e mexa até ficar tudo líquido.
Despeje nos tubos ou em um pote ainda quente e deixe esfriar sem tampa.
Validade: 12 meses. Para o calor da Bahia, aumente a cera para 12 g. Para ficar mais macio, diminua para 8 g. Sem sabor e sem cor de propósito: não ensina a criança a lamber o lábio.
4. Desodorante
Substitui antitranspirante com alumínio, talco, siloxano e fragrância.
Ingredientes:
30 g de óleo de coco
15 g de manteiga de karité
30 g de araruta ou amido de milho
5 g de bicarbonato (1 colher de chá rasa)
Opcional: 5 g de cera de abelha, para ficar firme no calor
Modo de fazer:
Derreta o óleo de coco, o karité e a cera (se usar) em banho-maria.
Tire do fogo e misture a araruta e o bicarbonato até não ter grumos.
Coloque num pote pequeno e deixe firmar.
Validade: 6 meses. Uso: uma porção do tamanho de uma ervilha, espalhada com os dedos.
Pele sensível: o bicarbonato pode irritar e deixar a axila vermelha, principalmente logo depois de depilar. Nesse caso, troque os 5 g de bicarbonato por 5 g de óxido de zinco. Desodorante natural não bloqueia o suor. Os primeiros dias podem parecer mais úmidos, e o cheiro também depende muito da alimentação.
5. Pó dental
Substitui pasta com SLS, corante, adoçante e triclosan.
Ingredientes:
2 colheres de sopa de argila branca (caulim)
1 colher de chá de bicarbonato
Opcional: 1 colher de chá de hidroxiapatita
Modo de fazer:
Misture tudo num pote de vidro seco.
Para usar, molhe a escova, encoste no pó (ou pegue uma pitada com uma colher seca) e escove normalmente.
Validade: 12 meses, desde que o pote fique seco. Não enfie a escova molhada no pote: a água entra e estraga. Criança: use só uma pitada e acompanhe a escovação. Não tem espuma nem sabor doce, então pode estranhar no começo.
6. Manteiga corporal
Para corpo, pés, cotovelos e pele muito seca.
Ingredientes:
50 g de manteiga de karité
25 g de manteiga de cacau
25 g de óleo de coco ou azeite
Modo de fazer:
Derreta as manteigas em banho-maria e junte o óleo.
Leve à geladeira até começar a firmar nas bordas (uns 30 minutos).
Bata com a batedeira até ficar cremosa e passe para o pote.
Validade: 6 meses. Rende bastante: aplique com a pele ainda um pouco úmida depois do banho.
7. Pomada para assadura
Substitui pomada com petrolato, lanolina e fragrância. O óxido de zinco forma uma barreira entre a pele e a umidade da fralda.
Ingredientes:
50 g de sebo purificado ou manteiga de karité
15 g de cera de abelha
10 g de óxido de zinco
Modo de fazer:
Derreta a cera e o sebo (ou karité) em banho-maria.
Tire do fogo. Coloque a máscara e acrescente o óxido de zinco aos poucos, mexendo bem até não ter grumos.
Continue mexendo enquanto esfria, para o zinco não assentar no fundo.
Validade: 12 meses. Assadura que não melhora em 2 a 3 dias, que sangra ou que tem pontinhos vermelhos em volta precisa ser vista pelo pediatra.
8. Demaquilante
Não precisa receita. Use azeite extravirgem ou óleo de jojoba puro.
Passe o óleo no rosto seco e massageie por 1 minuto. Ele dissolve maquiagem, inclusive rímel.
Retire com um pano de algodão umedecido em água morna.
9. Máscara de argila
A única receita com água, por isso é feita na hora e o que sobrar vai fora.
Misture 1 colher de sopa de argila branca com água filtrada aos poucos, até virar uma pasta.
Aplique no rosto limpo, fora da região dos olhos.
Retire com água morna em 10 minutos, antes de secar e rachar. Argila que racha na pele resseca.
Use 1 vez por semana. Pele oleosa pode usar argila verde no lugar da branca.
10. Cabelo
Shampoo caseiro não funciona bem: o sabão comum deixa resíduo no fio. O melhor é comprar um shampoo pronto seguindo o checklist do final deste material e lavar menos vezes.
O que dá para fazer em casa é o enxágue de vinagre, feito na hora:
Misture 1 colher de sopa de vinagre de maçã em 1 copo (250 ml) de água.
Depois do shampoo, despeje no cabelo, espere 1 minuto e enxágue.
Ajuda a soltar resíduo e deixa o fio mais solto. Não use vinagre puro.
Para as pontas secas, uma gota de óleo de jojoba ou de bálsamo de sebo nas mãos, espalhada só nas pontas, substitui o finalizador de silicone.
O que não fazer em casa
Algumas receitas que circulam na internet trazem mais risco do que o produto que querem substituir.
Não faça | Por quê | O que fazer no lugar
Protetor solar caseiro | Não tem como saber o FPS nem se o filtro ficou distribuído por igual. Pode dar falsa sensação de proteção | Comprar pronto com óxido de zinco em creme. Usar sombra, roupa e evitar o sol forte do meio do dia por muito tempo, respeitando o tom de pele e o tempo de cada um
Creme, loção ou tônico com água, chá ou babosa fresca para guardar | Contamina com fungo e bactéria em poucos dias, mesmo na geladeira | Fazer só receitas sem água, ou preparar na hora e usar tudo
Limão na pele | Causa queimadura e mancha escura quando a pele pega sol depois (fitofotodermatite) | Para mancha, procurar orientação profissional
Bicarbonato ou vinagre puros no rosto | Alteram o pH e agridem a barreira da pele | Usar só nas proporções das receitas
Óleo essencial em bebê, criança pequena e gestante | Traz os mesmos alérgenos da fragrância, e alguns são tóxicos em pouca quantidade | Deixar as receitas sem cheiro. Adulto que quiser usar: no máximo 1 gota para cada 10 g de produto
Sabão com soda cáustica sem experiência | A soda queima pele e olho, e o sabão mal curado fica cáustico | Comprar sabão de castela pronto
Alisante ou tintura caseira "natural" | Receitas com produtos de limpeza ou misturas sem controle podem queimar o couro cabeludo | Aceitar a textura natural ou procurar profissional que use produto sem formol e sem ácido glioxílico

Quando comprar pronto
Shampoo, sabonete, protetor solar e maquiagem são mais fáceis de comprar prontos. Antes de levar, confira o rótulo:
☐ Não tem nenhum ingrediente da lista vermelha
☐ Não tem "Parfum", "Fragrance" ou "Aroma" (procure "fragrance-free" ou "sem fragrância")
☐ Não tem nada terminado em "-paraben"
☐ Não tem "PEG-" nem "-eth" (Laureth, Ceteareth)
☐ Não tem "fluoro" no nome de nenhum ingrediente
☐ Não tem corante "CI" com número começando de 1 a 7 (os pigmentos minerais CI 77xxx podem)
☐ Lista de ingredientes curta: quanto menos itens, menos exposição
☐ Tem registro ou notificação na Anvisa (o número aparece no rótulo)
Se o ingrediente for desconhecido, pesquise o nome exato entre aspas junto com "endocrine disruptor" ou "contact allergen" antes de comprar.
Este documento é material de apoio educacional do Protocolo Superhumano e não substitui avaliação individual com profissional de saúde.
