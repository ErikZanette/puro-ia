# Ebook 30 Receitas Carnívoras

OVOS
Monte seu próprio negócio, com
vendas de ovos de páscoa gourmet.

INTRODUÇÃO
A alimentação carnívora tem ganhado cada vez mais
espaço entre pessoas que buscam uma forma mais
simples, natural e eficiente de se alimentar. Baseada
principalmente em alimentos de origem animal, essa
abordagem valoriza ingredientes nutritivos, preparações
diretas e refeições que realmente sustentam o corpo.
Pensando nisso, este eBook foi desenvolvido para mostrar
que seguir uma alimentação carnívora não precisa ser
complicado nem repetitivo. Pelo contrário: com alguns
ingredientes e técnicas simples, é possível preparar pratos
extremamente saborosos, crocantes, suculentos e cheios
de personalidade.
Aqui você encontrará 30 receitas selecionadas, que vão
desde preparações rápidas para o dia a dia até ideias
diferentes para variar o cardápio. O objetivo é trazer
opções práticas, com ingredientes acessíveis e passos
fáceis de seguir, permitindo que qualquer pessoa consiga
preparar essas receitas sem dificuldade.
Mais do que apenas um livro de receitas, este material foi
pensado para servir como inspiração na sua cozinha. Ele
mostra que, mesmo com uma base alimentar simples, é
possível explorar diferentes texturas, cortes, formas de
preparo e combinações que transformam ingredientes
comuns em refeições incríveis.
Agora é hora de colocar a mão na massa, experimentar
novos preparos e aproveitar tudo o que a culinária
carnívora pode oferecer.
Bom apetite.
SUMÁRIO
04 - Enroladinho recheado
05 - Petisco de Frango com Bacon 
06 - Canapés
07 - Pão Carnívoro 
08 - Maionese Carnívora 
09 - Pasta de Ovos 
10 - Requeijão Caseiro 
11 - Ovos Cremosos 
12 - Cestinha de Bacon e Ovos 
13 - Muffin de Parmesão 
14 - Filé Mignon com Mostarda 
15 - Bife Ancho na Manteiga 
16 - Prime Rib 
17 - Almôndegas ao Creme 
18 - Carne Seca 
19 - Peito Bovino na Pressão 
20 - Costela de Cordeiro 
21 - Paleta de Cordeiro 
22 - Farofa de Bacon e Ovos 
23 - Costela Suína na Brasa 
24 - Prime Rib Suíno 
25 - Torresmo na Pressão 
26 - Coxa de Frango com Parmesão 
27 - Farinha de Frango 
28 - Almôndegas de Frango 
29 - Chip de Pele de Frango 
30 - Salmão Grelhado 
31 - Ceviche de Tilápia 
32 - Poke de Salmão com Bacon 
33 - Bacalhau Gratinado 
Enroladinho recheado
• Ingredientes
• Modo de Preparo
• 400g de carne moída
• Sal e pimenta-do-reino a gosto 
• 400g de bacon fatiado 
• 300g de queijo provolone cortado em palitos 
1. Tempere a carne com sal e pimenta.
 2. Coloque as fatias de bacon sobre uma esteira (ou papel filme), dispondo-as
uma ao lado da outra.
 3. Por cima, faça uma camada com a carne moída temperada. 
4. Coloque as tiras de provolone por cima da carne e enrole. 
5. Coloque em uma forma e leve ao forno pré-aquecido a 200°C por 15 a 20
minutos ou até dourar. 
6. Retire e sirva em seguida.
4
Petisco de Frango com Bacon 
• Ingredientes
• Modo de Preparo
• 500g peito de frango
 • 250g bacon em fatias 
• Palitos de dente 
• Sal a gosto 
• Temperos a gosto
1. Corte o peito de frango em cubos com cerca de 2,5cm. 2. Em uma tigela,
tempere o frango com sal e temperos de sua preferência.
 3. Deixe marinar por cerca de 20 minutos. 
4. Corte as fatias de bacon com tamanho suficiente para envolver o frango.
 5. Envolva cada cubo de frango com uma fatia de bacon cada, fixando com
um palito de dente.
 6. Coloque os enroladinhos em uma travessa antiaderente ou untada, lado a
lado.
 7. Leve ao forno pré-aquecido a 180°C por cerca de 20 a 25 min, até dourar o
bacon.
5
Canapés
• Ingredientes
• Modo de Preparo
• Pão carnívoro 
• Manteiga derretida 
• Cobertura de sua preferência
1. Pré-aqueça o forno a 250°C. 
2. Corte o pão carnívoro em fatias de aproximadamente 5mm de espessura.
3. Em seguida, corte no formato desejado (em quadrados, por exemplo). 
4. Pincele as fatias de pão com manteiga derretida.
 5. Coloque as fatias em uma assadeira e leve ao forno por cerca de 10 a 15
minutos, até dourar. 
6. Prepare os canapés com a cobertura de sua preferência. Sirva. 
Sugestões: pasta de gorgonzola, pasta de sardinha, hackepeter, pasta de ovo,
carne ou frango desfiado, salmão defumado e cream cheese, etc.
6
Pão Carnívoro 
• Ingredientes
• Modo de Preparo
• 600g de frango cozido 
• 12 ovos 
• 12 colheres de sopa de queijo ralado (160g)
 • 2 colheres de sopa de bicarbonato de sódio. 
• 2 colheres de sopa de vinagre
1. Bata primeiramente os ovos.
 2. Em seguida, processe todos os ingredientes (menos o fermento) no
liquidificador ou processador. Acrescentar o fermento e misture um pouco
mais. 
3. Coloque logo em seguida na forma para pão (untada, se necessário).
 4. Leve ao forno pré-aquecido a 220°C por 30 a 40 minutos. 
5. Ao retirar do forno, desenforme e deixe esfriar em uma grade.
7
Maionese Carnívora 
• Ingredientes
• Modo de Preparo
• 3 ovos cozidos 
• 2 colheres (sopa) de vinagre branco 
• Meia xícara de manteiga derretida (preferencialmente ghee ou clarificada)
• 1 pitada de sal 
• 1 colher de chá de mostarda (opcional)
• Orégano ou outros temperos (opcional)
1. Cozinhe os ovos só até solidificar o interior da gema (cerca de 8 a 10
minutos após colocar os ovos em água fervente). 
2. Coloque os ovos no liquidificador, o sal, o vinagre e os opcionais, se quiser.
3. Vá colocando a manteiga aos poucos e batendo em baixa velocidade.
 4. Deixe a maionese bater até que o ovo tenha se dissolvido completamente
e ganhe a consistência desejada. Se for necessário, passe uma espátula dos
lados do liquidificador.
8
Pasta de Ovos 
• Ingredientes
• Modo de Preparo
• 4 ovos cozidos
• ½ xícara (chá) de maionese carnívora 
• Sal e pimenta-do-reino moída na hora a gosto
• ½ cebola (opcional) 
• Salsinha a gosto (opcional)
• Temperos a gosto (opcional)
1. Com um garfo amasse bem os ovos em uma tigela. 
2. Junte a maionese e outros ingredientes que serão utilizados. 
3. Tempere com sal e pimenta a gosto e misture bem até que todos os
ingredientes estejam incorporados.
 4. Sirva a seguir.
9
Requeijão Caseiro 
• Ingredientes
• Modo de Preparo
• 1 litro de leite integral
• 2 colheres (sopa) de vinagre
branco 
• 25g de manteiga em temperatura
ambiente
• ½ colher (chá) de sal 
1. Coloque o leite numa panela média e
leve ao fogo alto. Assim que ferver,
reserve ½ xícara do leite e desligue o
fogo. 
2. Junte o vinagre e misture
delicadamente. Deixe talhar por 5
minutos.
 3. Forre uma peneira com um pano de
algodão fino (ou filtro de papel) e
coloque sobre uma tigela funda.
4. Despeje o leite talhado na peneira e,
com uma colher ou espátula de silicone,
pressione para extrair o máximo de soro.
 5. Transfira o queijo para o liquidificador.
 10
 6. Junte a ½ xícara (chá) de leite morno
reservado, a manteiga e o sal. Bata bem
até formar um creme liso – caso
necessário, pare de bater e raspe a lateral
do liquidificador com a espátula.
 7. Transfira o requeijão para um pote de
vidro e deixe esfriar completamente
antes de tampar. 
8. Leve para a geladeira por, no mínimo,
2 horas para terminar de firmar. 
9. O requeijão caseiro dura 5 dias
armazenado num pote com fechamento
hermético na geladeira.
Ovos Cremosos 
• Ingredientes
• Modo de Preparo
• 4 ovos (no mínimo) 
• 1 colher de sopa de manteiga 
• Cerca de 50g de queijo (qualquer tipo que derreta) 
• Sal a gosto 
• Temperos a gosto (sugestão: pimenta-do-reino branca e cúrcuma) 
• Utensílio sugerido: fouet
1. Misture os ovos, sal e temperos em uma tigela. 
2. Leve a uma panela em fogo médio junto com a manteiga. 
3. Mexa regularmente. Quanto mais próximo do ponto, maior a velocidade.
4. Quando engrossar, adicione o queijo e continue mexendo bem. 
5. Os ovos devem cozinhar lentamente. Se necessário, retire um pouco da
fonte de calor, sempre mexendo, retornando, se necessário, para acertar o
ponto. 
6. Quando chegar ao ponto desejado, transfira imediatamente para o prato.
11
Cestinha de Bacon e Ovos 
• Ingredientes
• Modo de Preparo
Para cada unidade: 
• 1 fatia de bacon 
• 1 ovo 
• 1 pitada de sal
1. Forre cada forminha de empada ou muffin com uma fatia de bacon em
cada uma delas, envolvendo as laterais e o fundo de cada forma. 
2. Leve as forminhas ao forno pré-aquecido a 240°C por 5 a 10 minutos, para
que pré-assem (opcional). 
3. Retire do forno e quebre 1 ovo dentro de cada cestinho de bacon e
tempere com uma pitada de sal. 
4. Volte ao forno a 220°C por 10 a 20 minutos, até que os ovos estejam
firmes. 
5. Aguarde esfriar um pouco e desenforme. 
6. Sirva.
12
Muffin de Parmesão 
• Ingredientes
• Modo de Preparo
• 6 ovos 
• 50g de queijo parmesão ralado 
• Temperos de sua preferência 
• Sal e pimenta a gosto 
• Sugestões de recheio: queijo em cubos, carne moída, frango desfiado,
presunto.
1. Pré-aquecer o forno a 190°C e untar as forminhas ou use de silicone. 
2. Misturar os ovos, o tempero, a pimenta e o queijo ralado e reservar. 
3. Preencher cerca ½ de cada forminha com o recheio. 
4. Completar o preenchimento das forminhas com a mistura dos ovos. 
5. Levar ao forno por cerca de 25-30 min. 
6. Retirar do forno e servir. 
7. Pode ser guardado em geladeira ou congelador para consumo posterior.
13
Filé Mignon com Mostarda 
• Ingredientes
• Modo de Preparo
• 2 medalhões de filé mignon (150g
cada) 
• ½ colher (sopa) de manteiga
clarificada/ghee ou banha 
• Sal e pimenta-do-reino moída na
hora a gosto 
• Molho 
• 1 a 3 colheres de sopa de manteiga 
• ¼ a ½ xícara de caldo de carne 
1. Retire o filé mignon da geladeira e
deixe em temperatura ambiente por
alguns minutos – não podem estar
gelados ao ir para frigideira.
2. Tempere os medalhões com sal e
pimenta-do-reino a gosto.
3. Leve uma frigideira ao fogo médio.
Quando a frigideira estiver bem
quente, derreta a manteiga e espalhe
por todo o fundo.
4. Disponha os dois medalhões, um ao
lado do outro, e deixe dourar por 3
minutos de cada lado – a carne vai ficar
dourada por fora e mal passada no centro.
5. Transfira os medalhões para um prato
e cubra com papel alumínio para não
esfriar enquanto prepara o molho.
6. Na mesma frigideira em que os
medalhões foram dourados, coloque a
manteiga e leve ao fogo médio. Atenção:
não lave a frigideira, os queimadinhos da
carne dão sabor ao molho.
7. Ao derreter, acrescente o caldo de
carne, raspando o fundo da frigideira com
a espátula para dissolver os
queimadinhos.
8. Deixe reduzir um pouco e adicione
uma a duas colheres de sopa de manteiga
bem gelada e mexa até derreter.
9. Prove e ajuste temperos. 
10.Sirva a seguir sobre os medalhões.
11.Junte 1 a 2 colheres de sopa de
mostarda Dijon ao fim para um molho de
mostarda. (opcional). 14
Bife Ancho na Manteiga 
• Ingredientes
• Modo de Preparo
• Bife ancho (entrecôte ou filé de costela) 
• 1 a 2 colheres de sopa de manteiga clarificada ou ghee ou banha 
• Sal a gosto 
• Pimenta a gosto
1. Coloque a manteiga em uma frigideira antiaderente e leve ao fogo baixo.
Deixe derreter e mexa delicadamente até que as partes brancas e sólidas
escureçam e fiquem em um tom de dourado ou castanho. Reserve em outro
recipiente. 
2. Na mesma frigideira antiaderente, suja de manteiga e aquecida, disponha o
bife. Doure cada lado por dois minutos e meio. Regue generosamente, os
dois lados do bife com a manteiga reservada. 
3. Retire do fogo e polvilhe com flor de sal ou sal comum. Antes de servir,
deixe a carne descansar por 2 minutos para que os sucos se acomodem e não
escapem durante o corte.
15
Prime Rib 
• Ingredientes
• Modo de Preparo
• 1 peça de 700g a 1kg de prime rib 
• 1 colher de sopa de manteiga em temperatura ambiente 
• Sal e pimenta-do-reino moída na hora a gosto
1. Deixe a peça em temperatura ambiente por 1 hora. 
2. Pré-aqueça o forno a 200°C. 
3. Tempere com Sal e pimenta e espalhe a manteiga por toda a peça. 
4. Aqueça bem uma frigideira pesada (de preferência de ferro fundido ou
fundo triplo) e coloque a carne. 
5. Deixe que doure por 2 minutos em todos os lados, inclusive as laterais.
Mexa e apoie a peça com a ajuda de uma pegador para carne. 
6. Coloque a carne em uma forma e leve ao forno pré-aquecido. 
7. Deixe por cerca de 12 minutos. 
8. Retire e deixe descansar por 5 min. Sirva.
16
Almôndegas ao Creme 
• Ingredientes
• Modo de Preparo
Almôndegas 
• 400g de carne moída 
• 1 ovo 
• 30g de farinha de frango ou de
torresmo 
• 40g de queijo ralado 
• 1 colher de sopa de banha 
• 60ml de caldo de frango ou carne (ou
vinho branco seco) 
Creme 
• 300g de iogurte natural 
• 1 ovo 
• 1 gema 
• Sal e pimenta-do-reino a gosto
1. Faça bolinhas de carne com um
diâmetro de cerca de 4cm. 
2. Unte uma travessa com
manteiga. 3. Disponha as
almôndegas sobre a travessa e
regue com o caldo. 
4. Asse em forno pré-aquecido a
200°C por 25 a 30 minutos, virando
as bolinhas na metade do tempo. 
5. Prepare um creme com o
iogurte, um ovo e a gema.
Tempere a gosto. 
6. Retire as almôndegas do forno e
despeje o creme sobre elas. 
7. Retorne com a travessa para o
forno e asse por mais 10 minutos,
até o creme de iogurte ficar mais
encorpado.
17
Carne Seca 
• Ingredientes
• Modo de Preparo
• 500g de carne-seca 
• 2 colheres de sopa de manteiga (de
preferência, de garrafa) 
• Sal a gosto 
• 1 cebola grande (opcional) 
1. Corte a carne-seca em cubos de
7cm - este tamanho é ideal para
dessalgar a carne, sem tirar
completamente o sal, e também
desfiar de um tamanho uniforme.
Coloque numa tigela e lave bem em
água corrente. 
2. Cubra os cubos de carne com água
fria e deixe na geladeira durante 24
horas. 
3. Escorra a água e transfira a carne
para a panela de pressão. Complete
com água até a metade da panela,
tampe e leve ao fogo médio. Assim
que a panela começar a apitar, 
diminua o fogo e deixe cozinhar por 10
minutos. Desligue o fogo e espere toda a
pressão sair antes de abrir a panela.
4. Despreze a água do cozimento e repita
novamente o passo anterior, mas dessa vez
deixe cozinhar por 20 minutos. Depois que
toda a pressão da panela sair, abra e
verifique. Se a carne não estiver macia deixe
cozinhar por mais 5 minutos.
5. Retire os cubos de carne da panela,
transfira para uma travessa e desfie com dois
garfos (se preferir, coloque os pedaços numa
batedeira e bata em velocidade baixa até
desfiar). Descarte a gordura.
6. Descasque e fatie a cebola em meias-luas
finas. Leve ao fogo médio uma frigideira
antiaderente, junte 1 colher (sopa) de
manteiga e refogue a cebola por 2 minutos
ou até começar a dourar (opcional). 
7. Adicione a manteiga restante, junte a
carne-seca e mexa com uma espátula, por 3
minutos, apenas para aquecer. Desligue o
fogo, prove e, se necessário, tempere com
sal a gosto.
18
Peito Bovino na Pressão 
• Ingredientes
• Modo de Preparo
• 1 peça de peito bovino de 1kg 
• ½ xícara de água (ou vinho tinto) 
• ½ colher chá de vinagre 
• 2 colheres de sopa de manteiga ou
banha 
• 2 colheres chá de sal 
• Dry rub, mistura de temperos secos
em pó com sal, ervas e especiarias
(opcional) 
1. Limpe a carne, se necessário,
retirando membranas, etc. 
2. Corte a peça ao meio. 
3. Passe o sal e/ou dry rub em toda a
superfície da carne e reserve. Caso
queira mais sabor, deixe a carne
marinando por, no mínimo, 2h.
4. Caso use o vinho, acrescente na
marinada. Retire as peças da marinada
e reserve o líquido.
5. Na panela de pressão, doure os lados
de todas as peças. (etapa opcional –
confere mais sabor). 
6. Coloque a água (ou líquido da
marinada), vinagre e manteiga/banha na
panela. Em seguida, os pedaços de carne
um acima do outro. 
7. Cozinhe na pressão por cerca de 90
min. 
8. Depois que toda a pressão da panela
sair, abra e verifique. Se a carne não
estiver macia, cozinhe por mais tempo. 
9. Retire a carne da panela, transfira para
uma travessa e desfie. 
10. Aqueça o molho restante na panela
em fogo médio até apurar o sabor ao seu
gosto. Prove e adicione sal, se necessário.
19
Costela de Cordeiro 
• Ingredientes
• Modo de Preparo
• 1 peça de costela de cordeiro 
• Sal 
• Pimenta-do-reino a gosto 
• Temperos a gosto – sugestões: alecrim, páprica, sumac, canela
1. Tempere a costela. Deixe marinar por, no mínimo, 1 hora. 
2. Adicione 1 xícara de caldo de carne ou vinho seco a marinada. 
3. Embrulhe a costela com 3 folhas de papel alumínio. 
4. Leve ao forno a 180°C por cerca de 1:30-2 horas. 
5. Abra o papel alumínio e suba a temperatura do forno para 250°C e coloque
a costela na primeira prateleira do forno ou use o grill. Deixe até dourar. 
6. Retire do forno e deixe descansar por 10 a 15 minutos antes de servir.
20
Paleta de Cordeiro 
• Ingredientes
• Modo de Preparo
• 1 paleta de cordeiro com osso (cerca
de 1kg) 
• 5 ramos de alecrim 
• 1 a 2 colheres (sopa) de manteiga 
• Sal de parrilha • Pimenta-do-reino
moída na hora 
1. Pré-aqueça o forno a 160°C
(temperatura baixa). 
2. Numa assadeira, faça uma cama com
os ramos de alecrim. 
3. Espalhe manteiga por toda a peça com
as mãos. 
4. Tempere toda a peça com sal e
pimenta. 
5. Disponha o cordeiro sobre o alecrim. 
6. Cubra a assadeira com papel-alumínio
e leve ao forno por cerca de 3 horas até
que a carne fique bem macia. 
 7. Retire a assadeira do forno e
aumente a temperatura para 200°C
(temperatura média).
8. Remova o papel-alumínio e regue
a paleta com o caldo que se formou
na assadeira. 
9. Volte ao forno para assar por
cerca de 40 minutos ou até dourar. 
10.Retire do forno e deixe descansar
cerca de 10 minutos antes de servir.
21
Farofa de Bacon e Ovos 
• Ingredientes
• Modo de Preparo
• 100g de bacon em cubos pequenos 
• 3 ovos 
• 1 xícara de farinha de frango 
• 1 colher de sopa de manteiga • Sal e temperos a gosto 
• Cebola picada (opcional)
1. Aqueça a frigideira em fogo médio-alto e coloque o bacon. Deixe fritar até
ficar bem crocante, acrescente a cebola (opcional) e refogue até dourar. 
2. Quebre os 3 ovos dentro da panela e tempere. Cuidado com o sal, já que o
bacon é salgado. Mexa até que o ovo cozinhe. 
3. Acrescente a farinha de frango e continue mexendo por cerca de 2
minutos. 
4. Finalize com uma colher de sopa de manteiga, mexendo até derreter e ser
incorporada a farofa. 
Observação: bacon e ovos é uma sugestão. Aproveite a mesma base da farofa
para outros ingredientes: carne seca, linguiça, entre outros tipos de carne.
22
Costela Suína na Brasa 
• Ingredientes
• Modo de Preparo
• Costela suína 
• Sal de parrilha 
Dry rub (opcional): 
• ¼ xícara páprica doce 
• 3 colheres de sopa de sal 
• 1 colher de sopa de cebola em pó 
• 1 colher de sopa de alho em pó 
• ½ colher de sopa de pimenta caiena 
• 1 colher de sopa de mostarda em pó 
• 1 colher chá de cominho
1. Misture os ingredientes do dry rub
em uma tigela. Espalhe com as mãos
por toda a costela e deixe marinar por,
no mínimo, 2 horas (opcional).
2. Embrulhe com 3 ou 4 folhas de
alumínio, dobrando bem as bordas para
não escapar vapor.
3. Coloque no segundo andar da
churrasqueira. Após estufar, conte
cerca de 50 minutos.
4. Após esse tempo, abra o papel
alumínio e recolha o líquido.
5. Coloque a peça no primeiro andar e
doure ambos os lados. Cerca de 4-5
minutos de cada lado. Pincele com o
líquido recolhido ou manteiga
derretida.
6. Retire da brasa e deixe descansar
por cerca de 5 minutos antes de servir.
23
Prime Rib Suíno 
• Ingredientes
• Modo de Preparo
• Peça de prime pib suíno 
• Sal em escamas ou sal grosso
1. Acenda o fogo uns 20 a 30 minutos antes de começar a grelhar a carne,
que de preferência deve estar em temperatura ambiente (retire-a da geladeira
antes). 
2. Salgue. O ideal é fazer isso uns 5 a 10 minutos antes de colocar a peça no
fogo. 
3. Sele a carne com a grelha posicionada a 15 centímetros da brasa forte.
Depois disso, suba a grelha para 35 a 40cm e asse o seu prime rib até o ponto
de sua preferência. 
4. Retire do fogo. Para que fique mais suculenta, deixe-a descansando por
alguns minutos. E para que ela não perca a temperatura, você pode transfirá-
la para uma forma pré-aquecida ou cobri-la com papel alumínio.
24
Torresmo na Pressão 
• Ingredientes
• Modo de Preparo
• 500g de barriga de porco 
• Sal a gosto • 1 colher de sopa de
banha de porco 
• 30 a 50ml de bebida destilada como
cachaça ou vodka (opcional) 
1. Corte a barriga em pedaços do
tamanho que desejar. 
2. Tempere com sal a gosto. 
3. Para deixar mais crocante, regue
com a bebida destilada e deixe
marinar por uns minutos. 
4. Derreta na panela de pressão a
banha de porco em fogo médio.
5. Despeje a barriga cortada na panela
de pressão. Mexa até o torresmo
começar a desgrudar da panela.
Importante: retire a borracha da
panela de pressão e tampe a panela. 
6. Aumente para fogo alto e deixe por
cerca de 20 minutos. Durante este
período, mexa sacudindo a panela por
várias vezes para não queimar. 
7. O torresmo vai começar a estourar
parecendo pipoca. Quando parar de
fazer barulho, está pronto. 
Observação: apesar de ser preparado
em uma panela de pressão, o
torresmo não é preparado na pressão.
A dica é utilizar a panela apenas para
evitar que a gordura suje toda a
cozinha.
25
Coxa de Frango com Parmesão 
• Ingredientes
• Modo de Preparo
• 6 coxas de frango 
• 1 xícara de queijo parmesão ralado 
• ½ xícara de manteiga derretida 
• 1 colher de sopa de salsinha desidratada (opcional) 
• Orégano (opcional) 
• 1 colher de sopa de páprica (opcional) 
• ½ colher de sopa de pimenta-do-reino moída (opcional)
1. Retire as coxas de frango da geladeira por cerca de 10 minutos. 
2. Misture o queijo e especiarias. 
3. Derreta a manteiga. 
4. Mergulhe o frango na manteiga e empane bem com a mistura de queijo. 
5. Coloque em uma travessa e leve ao forno a 180°C por 45 a 60 minutos.
26
Farinha de Frango 
• Ingredientes
• Modo de Preparo
• Frango – 1kg rende aproximadamente 2 xícaras (25 a 40% de rendimento) 
1. Corte o frango em cubos e disponha em um tabuleiro preferencialmente
com bordas altas. 
2. Leve ao forno a 220°C até cozinhar (30-40 minutos). Retire o excesso de
líquido após cozido, se necessário, e deixe esfriar.
3. Processe bem o frango cozido. O liquidificador pode ser usado, realizando
esta etapa em pequenas porções. 
4. Espalhe a massa no tabuleiro (evite ultrapassar 2cm de altura) e leve ao
forno a 250°C até secar bem, dourar e ficar soltinha, retirando e mexendo a
cada 15 minutos aproximadamente (quando dourar a superfície). Esta etapa
dura de 30 a 50 minutos – depende da quantidade e umidade do frango. 
5. Retire e deixe esfriar completamente.
27
Almôndegas de Frango 
• Ingredientes
• Modo de Preparo
• 450g de frango cru em cubos 
• 1 ovo 
• 80 gde muçarela ralada 
• 85 gde queijo parmesão ralado 
• 1 colheres de sopa de manteiga derretida 
• Sal e temperos a gosto
1. Processe todos os ingredientes até obter uma massa. 
2. Enrole em bolas de 30g. 
3. Disponha em uma assadeira antiaderente ou untada e leve ao forno pré-
aquecido a 220°C por cerca de 15 a 20 minutos, até dourar levemente. 
4. Caso use uma air fryer, cozinhe a 200°C por 10 min, virando na metade do
tempo.
28
Chip de Pele de Frango 
• Ingredientes
• Modo de Preparo
• Pele de Frango 
• Sal e temperos a gosto
1. Retire toda a pele do frango, limpe, lave e seque completamente. 
2. Corte a pele em formato de chips. 
3. Coloque a pele em um tabuleiro antiaderente e/ou untado e tempere. 
4. Leve ao forno a 210°C por cerca de 20 minutos até ficar crocante.
29
Salmão Grelhado 
• Ingredientes
• Modo de Preparo
• Salmão 
• Flor-de-sal a gosto 
• Pimenta-do-reino branca a gosto
1. Corte o salmão em filés de cerca de 2 a 3 dedos de espessura, mantendo a
pele. 
2. Pressione um pouco os filés nas extremidades, facilitando três cortes
paralelos na pele (opcional). 
3. Tempere com sal e pimenta. 
4. Leve os filés a uma frigideira em fogo médio, deixando a pele do para baixo
5. Após cerca de 2 minutos, vire as peças de salmão. Grelhe por mais 1,5 a 2
minutos. 
6. Finalize com flor-de-sal e/ou sirva com molho de sua preferência.
30
Ceviche de Tilápia 
• Ingredientes
• Modo de Preparo
• 500g de filé de tilápia 
• 5 limões (usamos o taiti) 
• ½ cebola roxa 
• 1 tomate 
• 1 pimenta dedo de moça 
• Folhas de coentro (ou salsa) 
• Sal a gosto
1. Faça pequenos cubos do filé. 
2. Fatie a cebola bem fina. 
3. Descarte as sementes da pimenta, fatie bem fina. 
4. Coloque o peixe, a cebola e a pimenta em um recipiente, acrescente o sal e
misture. 
5. Acrescente o suco dos limões e leve para a geladeira por 1 hora. 
6. Ao servir, acrescente o tomate cortado em cubinhos e o coentro (ou salsa).
31
Poke de Salmão com Bacon 
• Ingredientes
• Modo de Preparo
• Salmão fresco 
• Bacon em cubos pequenos 
• 2 gemas (opcional) 
• Flor-de-sal (ou sal marinho) 
• Gelo
1. Coloque uma vasilha com gelo por baixo da travessa que vai preparar o
poke. 
2. Corte o salmão em cubos de cerca de 2cm, colocando-o na travessa. Limpe
e reserve a pele (opcional). 
3. Doure o bacon em uma frigideira e reserve em um prato com papel toalha
para esfriar e ficar mais crocante. 
4. Aproveite a gordura do bacon e grelhe a pele de salmão em fogo médio até
ficar crocante. 
5. Junte os ingredientes na travessa, misture e finalize com flor-de-sal. 
6. Junte 1 gema aos ingredientes na travessa e misture, finalize com flor-de-
sal e componha o prat
32
Bacalhau Gratinado 
• Ingredientes
• Modo de Preparo
• 450g de bacalhau dessalgado e cozido 
• 4 ovos 
• 150g de cream cheese 
• 1 colher de sopa de manteiga clarificada ou ghee 
• Queijo parmesão ralado 
11. Pré-aqueça o forno a 180°C. 
2. Refogue o bacalhau na manteiga até desmanchar um pouco.
3. Separe os ovos em claras e gemas. 
4. Misture as gemas e o cream cheese até obter um creme homogêneo. 
5. Acrescente o bacalhau e mexa um pouco mais. 
6. Bata as claras em neve. 
7. Incorpore as claras aos poucos e delicadamente a mistura com bacalhau. 
8. Transfira para uma travessa refratária e polvilhe com parmesão, cobrindo
toda a superfície. 
9. Leve ao forno pré-aquecido por 20 a 25 minutos, até dourar.
33

35
