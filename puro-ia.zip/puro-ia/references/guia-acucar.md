# Guia Definitivo do Açúcar Escondido e Fim do Vício

SEMANA 4
SEMANA 4
ANTONIO KRAYCHETE
ANTONIO KRAYCHETE
Por que Açúcar
e Carboidratos
Viciam
Por que Açúcar
e Carboidratos
Viciam
CAPÍTULO 1
CAPÍTULO 1
RESET METABÓLICO

3 
 
CAPÍTULO 1 
Por que Açúcar e Carboidratos Viciam 
A Armadilha do Açúcar: Por Que Você Está Preso Nesse Ciclo? 
Você já parou para pensar por que é tão difícil largar o açúcar? Por que, mesmo 
sabendo que faz mal, você ainda se rende àquela sobremesa? Por que é tão difícil 
dizer "não" para um pão quentinho ou um pedaço de bolo? 
Eu também já estive preso nessa armadilha. Um ciclo interminável de prazer 
momentâneo seguido de culpa e cansaço. E por muito tempo, eu achei que era só falta 
de força de vontade... 
Mas não é tão simples assim. 
Vamos direto ao ponto: açúcar vicia. E não é um vício qualquer. É um vício químico, 
poderoso e silencioso. Ele se infiltra na sua rotina e domina sua mente sem que você 
perceba. 
O Ciclo Vicioso da Dopamina 
Quando você consome açúcar, seu cérebro libera dopamina. É aquele "barato" 
instantâneo que faz você se sentir bem por alguns minutos. A sensação é prazerosa... 
é reconfortante. 
O problema é que o cérebro não está nem aí para sua saúde. Ele só quer mais daquela 
sensação boa. E, como todo vício, o efeito vai diminuindo... Você come uma barra de 
chocolate hoje e se sente bem. Amanhã, aquela mesma barra não dá mais o mesmo 
efeito... E assim, você aumenta a dose... sem nem perceber. 
Isso é bioquímico. Não é só uma questão de escolha ou força de vontade. O açúcar 
age diretamente no sistema de recompensa do cérebro, da mesma forma que drogas 
pesadas. Isso não é exagero. Estudos mostram que o açúcar ativa as mesmas regiões 
do cérebro que a cocaína. Isso significa que seu corpo e sua mente estão sendo 
manipulados... Você acha que está no controle, mas na verdade está sendo controlado. 

4 
 
Por Que Carboidratos Têm o Mesmo Efeito 
Não se engane... Não é só o açúcar puro que vicia. Carboidratos refinados — como 
pão branco, massas, bolos e doces industrializados — têm o mesmo efeito. Por quê? 
Porque eles se transformam rapidamente em glicose no sangue. O resultado? A 
mesma explosão de dopamina. 
Mas o pior não é só isso... Depois do pico de glicose, vem a queda abrupta. E com ela, 
vem o cansaço, a irritação e a fome novamente. É o corpo desesperado pedindo mais 
daquilo que acabou de consumir. E você se pega pensando: "Por que estou com fome 
de novo? Acabei de comer!" O ciclo continua, e você segue preso numa montanha-
russa emocional e física. 
O Corpo Começa a Reagir 
Com o tempo, seu corpo se adapta a essa rotina de picos e quedas. Ele começa a 
pedir cada vez mais, e você perde o controle. O seu paladar muda, e alimentos 
naturais parecem sem graça. Só o ultraprocessado e açucarado trazem prazer... Mas a 
que preço? 
O preço é alto. 
É resistência à insulina. 
É acúmulo de gordura visceral. 
É diabetes tipo 2. 
É ansiedade e depressão. 
É a perda do controle sobre a sua própria vida. 

5 
 
 A Normalização do Açúcar na Sociedade 
Desde crianças, fomos ensinados a acreditar que açúcar é sinônimo de alegria, 
celebração e recompensa. Seja o bolo no aniversário, o brigadeiro na festa, o 
refrigerante no almoço de domingo... O açúcar sempre esteve lá, disfarçado de carinho, 
de cuidado, de momento especial. 
A indústria alimentícia soube como ninguém explorar essa fraqueza. Com propagandas 
recheadas de sorrisos, famílias felizes e momentos inesquecíveis... O açúcar ganhou o 
status de "necessidade" na vida moderna. A verdade é que estamos sendo 
condicionados desde cedo a ver o açúcar como algo bom, inofensivo. 
E assim, crescemos com essa mentalidade: Se estamos tristes, um chocolate resolve. 
Se estamos comemorando, um bolo não pode faltar. Se queremos relaxar, um sorvete 
cai bem. 
Isso se tornou tão normal que ninguém questiona. Está enraizado na cultura, nas 
tradições, nas receitas de família. Pior: quando alguém decide parar, é visto como 
exagerado, como radical. As pessoas ao redor dizem: "Só um docinho não faz mal..." 
Mas não percebem que é justamente esse "só um" que perpetua o vício. 
Você já parou para refletir o quanto somos manipulados? 
O quanto a normalização do açúcar nos fez reféns de uma química que destrói nossa 
saúde lentamente? Estamos presos nesse ciclo... E, por mais que a sociedade aplauda 
o doce, a realidade é amarga. 
É difícil admitir que aquilo que parecia inofensivo, na verdade, é o que nos prende... 
Mas é necessário. Porque só assim conseguimos abrir os olhos e enxergar a realidade. 
O açúcar virou um vilão disfarçado de amigo. E enquanto não reconhecermos isso, 
vamos continuar nessa montanha-russa emocional e física. Despertar para essa 
verdade é o primeiro passo para recuperar o controle. 
E pra te ajudar a analisar o que tem açúcar ou não, botarei uma lista abaixo com todos 
os nomes ESCONDIDOS que as empresas usam para o açúcar. 

a
NOMES DO
açúcar
Saiba como as empresas
estão te enganando.
 Inventam dezenas de
diferentes nomes para o
açúcar com o mesmo
intuito: continuar te
deixando viciado.
terminam com "ose"
Glicose
Frutose
Sacarose
Lactose
Maltose
Dextrose
Galactose
Ribose
Xilose
Trehalose
Pentose
terminam com "ol"
Sorbitol
Manitol
Xilitol
Maltitol
Eritritol
Lactitol
Isomalte
Xaropes e Néctares
Xarope de milho
Xarope de alta
frutose (HFCS)
Xarope de bordo
Xarope simples
Xarope de cana
Xarope de agave
Xarope de yacon
Xarope de coco
Xarope de beterraba
Néctar de agave
Néctar de coco
Néctar de frutas
Açúcares "naturais"
Mel
Melado
Açúcar mascavo
Açúcar de coco
Açúcar de palma
Açúcar turbinado
Açúcar bruto
Açúcar demerara
Açúcar de beterraba
Caldo de cana
Néctar de coco
Melado de uva
Melado de maçã
Melado de tâmara
“concentrados”
Suco de cana
concentrado
Suco de maçã
concentrado
Suco de uva
concentrado
Suco de laranja
concentrado
Suco de frutas
concentrado
Suco de pêssego
concentrado
Suco de pera
concentrado
Suco de abacaxi
concentrado
Suco de limão
concentrado
Suco de frutas
variadas
concentrado
Melado concentrado
Xarope de bordo
concentrado
 Ingredientes
processados
Dextrina
Maltodextrina
Maltose
Melado
Concentrado de
frutas
Sumo de frutas
Frutose extraída
Extrato de malte
Amido modificado
Calda de frutas
adoçantes
Aspartame
Sucralose
Estévia
Acesulfame-K
Sacarina
Neotame
Advantame
Tagatose
Alulose
Glicerol
Polidextrose
PROTOCOLO 
ZERO FOME

A Luz no Fim do
Túnel
A Luz no Fim do
Túnel
CAPÍTULO 2
CAPÍTULO 2
RESET METABÓLICO

8 
 
CAPÍTULO 2 
A Luz no Fim do Túnel 
 A Liberdade Que Você Nunca Imaginou 
Imagine acordar de manhã com energia real. Sem precisar daquela dose de café para 
funcionar. Sem a sensação de cansaço arrastado. Apenas disposição natural, pronta 
para encarar o dia. 
Parece distante? Pois é totalmente possível. Quando você decide se libertar dos 
carboidratos refinados e do açúcar, algo incrível acontece. Seu corpo deixa de ser 
escravo de picos e quedas glicêmicas. Ele para de depender da dopamina rápida para 
se sentir bem. 
E sabe qual é o resultado disso? Uma mente mais clara, emoções mais estáveis e um 
corpo que funciona do jeito que deveria. 
Não é mágica. É biologia pura. Você sai de um estado de sobrevivência para um 
estado de estabilidade. Sai do modo "viciado" para o modo "autossuficiente". 
 
O Renascimento do Seu Cérebro: Como Tudo Muda por Dentro 
Você sabia que seu cérebro literalmente muda quando você quebra o ciclo de 
compulsão alimentar? 
Isso mesmo. Não é só uma sensação de liberdade... 
É uma mudança física e química na sua mente. 
Quando você está preso ao açúcar e aos carboidratos refinados, seu cérebro vive em 
estado de caos. 
A dopamina rápida te faz sentir bem por segundos, mas depois te joga no chão. 
É uma montanha-russa emocional e física. 
Quantas vezes você se viu preso naquele ciclo de compulsão, se sentindo fraco e 
derrotado? 
Achando que nunca teria controle? 
Já parou para pensar no preço que está pagando por esse vício silencioso? 
Mas quando você quebra esse ciclo, algo extraordinário acontece. 
 
9 
 
A Regulação da Dopamina 
O cérebro para de buscar aquelas doses rápidas e começa a equilibrar seus níveis de 
dopamina. Isso significa que você não precisa mais de estímulos constantes para se 
sentir bem. A felicidade deixa de ser passageira e se torna algo estável. 
Neuroplasticidade: Seu Cérebro se Reconecta 
O cérebro tem uma capacidade incrível de se adaptar, chamada neuroplasticidade. 
Quando você deixa de alimentar o vício, ele cria novas conexões que favorecem 
hábitos saudáveis. Aqueles caminhos antigos — que ligavam estresse com comida — 
vão sendo apagados. 
O Sistema de Recompensa Volta ao Normal 
Você recupera o controle. A comida deixa de ser uma obsessão e volta a ser apenas 
alimento. Seu cérebro aprende a valorizar prazeres mais profundos e duradouros, 
como um treino intenso, uma conversa significativa ou simplesmente o bem-estar de 
estar presente. 
 
Energia Constante: Sem Picos e Quedas 
Lembra daquele ciclo interminável de fome, cansaço e irritação? Ele desaparece. 
Quando seu corpo para de depender da glicose como fonte principal de energia, ele 
começa a usar gordura como combustível. E a gordura, meu amigo, é uma fonte 
poderosa e duradoura. 
Você não precisa mais comer a cada duas horas para evitar a fadiga. Sua energia não 
despenca no meio da tarde. O corpo se adapta e aprende a usar o que tem de melhor: 
as reservas de gordura. 
É como trocar uma moto barulhenta por um carro híbrido silencioso e eficiente. A 
máquina continua funcionando, mas de maneira equilibrada e contínua. 

10 
 
Clareza Mental: A Mente Sem Neblina 
Se livrar do açúcar é se libertar de uma mente confusa. 
Quando você corta a dopamina rápida, o cérebro passa por um processo de ajuste. No 
começo, pode parecer difícil, mas logo a clareza aparece. 
Você começa a pensar com mais nitidez, se concentrar com mais facilidade e tomar 
decisões com mais segurança. Não há mais aquela oscilação entre euforia e apatia. 
Sua mente se alinha ao seu corpo e tudo parece mais calmo. 
É como abrir uma janela em um quarto abafado e finalmente sentir o ar fresco entrar. 
Você percebe que estava preso e não sabia. 
 
Controle Emocional: Sem Altos e Baixos 
Sabe aquele humor que oscilava junto com a glicose? 
Ele desaparece. Você não fica mais irritado por besteira, nem deprimido quando o doce 
acaba. 
É uma sensação de equilíbrio emocional que você nem sabia que existia. Sem o 
açúcar controlando sua química cerebral, você começa a ser dono das suas emoções. 
O mundo lá fora não muda, mas sua percepção dele muda. Você se sente mais forte, 
mais estável e mais resistente às adversidades. Não é que os problemas 
desaparecem... é que você fica maior que eles. 
 
Autonomia Emocional: Você no Controle 
Mais do que equilibrar o humor, vencer a compulsão alimentar traz algo ainda mais 
poderoso: a autonomia emocional. Não é só sobre parar de oscilar entre altos e 
baixos... 
É sobre assumir o controle das suas reações. 
Você desenvolve uma resiliência emocional que antes parecia impossível. 
Isso significa que suas reações a estresse, frustrações e desafios não são mais 
impulsivas. 
Você não busca conforto imediato na comida ou em outros vícios. 
É como se sua mente ganhasse músculos: mais forte, mais resistente, mais firme 
diante das adversidades. 
 
11 
 
Você aprende a sentir e processar as emoções em vez de abafá-las com prazer 
imediato. 
Isso muda tudo. 
Você finalmente percebe que as emoções não te controlam... 
Você controla as emoções. 
 
Corpo Desinflamado: Você Vai Se Sentir Mais Leve 
O açúcar não só destrói sua energia e sua mente... ele também inflama seu corpo. 
Quando você elimina os carboidratos refinados, percebe que a dor nas articulações 
diminui, que o inchaço desaparece e que aquela sensação de peso no estômago some. 
É um alívio. Parece que você está carregando menos peso, mesmo antes de perder os 
quilos extras. Seu corpo respira aliviado, sem precisar combater toxinas 
constantemente. 
Além disso, sua pele melhora. A acne que te incomodava começa a sumir, as olheiras 
diminuem e o rosto ganha uma aparência mais saudável. Sem inflamação, seu corpo 
trabalha em paz. 
 
Autonomia Alimentar: O Controle é Seu 
Você não precisa mais correr atrás do próximo lanche. Não fica mais obcecado com o 
que vai comer a seguir. Quando o corpo se adapta ao estado de cetose ou 
simplesmente se livra dos picos de glicose, você descobre algo novo: a fome real. 
E ela não é desesperadora. Não é aquela urgência que faz você devorar o que 
aparecer pela frente. A fome natural vem com calma, como um aviso respeitoso de que 
é hora de abastecer. 
Isso traz uma sensação de poder. Você não é mais um escravo da comida. Você 
escolhe o que vai comer, na hora que faz sentido. Não há compulsão, só liberdade. 

A Paz de Espírito: A Vitória Contra a Dopamina Rápida 
 
12 
 
Imagine viver sem precisar de pequenas recompensas o tempo todo. Sem precisar 
daquela gratificação instantânea que o açúcar te dava. Viver assim é ter uma paz 
interna que antes parecia inalcançável. 
Você não está mais em busca de prazeres rápidos e efêmeros. Você está construindo 
algo sólido, duradouro, profundo. Isso muda sua perspectiva sobretudo: trabalho, 
relacionamentos, autocuidado. 
O que antes parecia impossível agora faz sentido. Você não precisa mais daquela 
barra de chocolate para se sentir bem. Você se sente bem porque está no controle, 
porque seu corpo não está em guerra contra si mesmo. 
 
Conclusão: A Vida Sem Açúcar é Mais Doce 
Você merece experimentar isso. 
Merece sair do ciclo de dopamina rápida e viver de maneira plena. 
É claro que o processo de adaptação não é fácil. 
No começo, o corpo vai reclamar, a mente vai pedir por aquele prazer imediato. 
Mas quando você atravessa essa barreira, descobre uma realidade nova, leve e 
poderosa. 
Se libertar do açúcar não é só uma mudança alimentar. 
É uma transformação profunda de como você vive, pensa e sente. 
É sair da escuridão e finalmente enxergar a luz no fim do túnel. 
Essa jornada é sua. 
E ela começa quando você decide que não vai mais viver refém de um vício que te 
puxa para baixo. 
Você é capaz de vencer. 
E quando vencer, vai olhar para trás e se perguntar: 
"Como eu consegui viver tanto tempo preso naquela ilusão?" 
Viver sem açúcar é viver livre. 
A escolha está nas suas mãos. 

A Importância
Vital de Lembrar
do Seu "Porquê"
A Importância
Vital de Lembrar
do Seu "Porquê"
CAPÍTULO 3
CAPÍTULO 3
RESET METABÓLICO

14 
 
CAPÍTULO 3 A Importância Vital de 
Lembrar do Seu "Porquê" 
 
Você já se perguntou por que algumas pessoas conseguem superar desafios que 
parecem impossíveis? 
Por que alguém decide correr uma maratona, largar um vício ou mudar radicalmente de 
vida — e consegue? 
A resposta está em uma coisa simples, mas poderosa: o "Porquê". 
O motivo que te move. A razão que faz você levantar quando o mundo está te 
derrubando. 
Sem isso, qualquer mudança vira só mais uma tentativa frustrada. 
Mas quando o seu "Porquê" é forte o suficiente, nada consegue te parar. 
 
O Que é o Seu "Porquê"? 
O "Porquê" não é só uma meta. 
Não é apenas um desejo. 
É aquilo que te faz agir quando tudo parece difícil. 
É o motivo que queima no peito quando o cansaço bate. 
Pode ser um sonho antigo. 
Pode ser uma promessa que você fez para si mesmo. 
Pode ser a vontade de provar para o mundo que você é capaz. 
É pessoal. 
É único. 
E só você sabe qual é. 
 
Quando o Desejo de Desistir Bater 
Vamos ser honestos: mudar não é fácil. 
Vai ter dias em que tudo o que você vai querer é jogar tudo pro alto e voltar aos velhos 
hábitos. 
Dias em que a vontade de ceder vai parecer insuportável. 
E é aí que entra o seu "Porquê". 
Quando você lembra do motivo real pelo qual começou, o desejo imediato perde força. 
 
15 
 
Você olha para a vontade passageira e pensa: "Isso não é maior do que o meu 
propósito." 
 
Como Usar Seu "Porquê" Para Resistir aos Desejos Imediatos 
1. Ancore o Seu Propósito 
Escreva o seu "Porquê" em um lugar visível. 
Leia toda vez que a tentação aparecer. 
Isso vai te ajudar a manter o foco no que realmente importa. 
2. Visualize a Vitória 
Feche os olhos e imagine-se vencendo. 
Imagine como vai se sentir quando conquistar aquilo que parece tão distante 
agora. 
Use essa sensação como combustível. 
3. Questione o Desejo Imediato 
Pergunte a si mesmo: "Essa escolha está me aproximando ou afastando do meu 
objetivo?" 
Essa reflexão simples já basta para quebrar o impulso de ceder. 
4. Lembre-se do Preço a Pagar 
Toda vez que você cede, você dá um passo para trás. 
Você sabe que o arrependimento vai vir. 
Então escolha o que traz orgulho, não o que traz culpa. 
 
Seu "Porquê" Tem Que Ser Forte o Suficiente 
Se ele não for poderoso, qualquer desejo pequeno vai te derrubar. 
Você precisa de um propósito que faça seu coração bater mais forte. 
Algo que te faça levantar da cama mesmo quando tudo parece contra. 
É por isso que você tem que lembrar dele todos os dias. 
Coloque ele na sua cabeça e no seu coração. 
Deixe ele guiar suas escolhas, especialmente quando tudo parecer difícil. 

16 
 
A Vitória é Sua Quando o Seu "Porquê" é Inabalável 
No fim das contas, quem vence não é o mais forte ou o mais talentoso. 
É aquele que resiste. 
Que não cede ao impulso fácil. 
Que escolhe o propósito em vez do prazer imediato. 
Então, da próxima vez que a vontade de desistir bater, pergunte a si mesmo: 
"Isso está me levando para mais perto do meu propósito?" 
A resposta certa está dentro de você. 
E ela é a chave para não cair nas armadilhas do momento. 
Lembre-se: quem tem um "Porquê" inabalável nunca perde o foco. 
E você sabe por que começou. 
Não deixe que o desejo do agora destrua seu sonho de amanhã. 
Vamos juntos. 
Rumo à vitória.
