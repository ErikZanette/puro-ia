# Lista Completa de Compras Econômicas

Lista de Compras Econômica: O Guia Essencial Para Comer 
Carne Gastando Menos 
O nome diz tudo. 
Aqui eu te mostro exatamente como encher o carrinho gastando menos do que numa dieta 
tradicional. 
Cortes baratos. Estratégias inteligentes. Substituições estratégicas. 
Você vai entender que comer carne pode sair mais barato do que viver de ultraprocessado. 
Eu sei o que você pensa: 
“Dieta carnívora é cara.” 
Mas aqui eu vou te mostrar que ela não só pode ser mais barata… 
como o custo-benefício a longo prazo simplesmente vai destruir qualquer discussão sobre 
dinheiro. 
Você já entendeu que a carnívora para a saúde tem inúmeros benefícios: 
Imunidade lá em cima. 
Disposição. 
Libido. 
Hormônios regulados. 
Tireoide funcionando. 
Nutrição e saciedade absurda. 
Redução — e muitas vezes fim — da ansiedade. 
Energia constante. 
Fim do inchaço. 
Clareza mental. 
Pele, cabelo e unhas fortes. 
Potência e fertilidade a mil. 
Ou seja… o valor já está mais do que pago. 
Mas calma. 
Eu entendo que, às vezes, você está em um momento em que precisa economizar. 
Ou quer reduzir gastos. 
Ou tem filhos, responsabilidades, contas… 
E é aqui que a maioria se engana. 
Porque quando você entra na carnívora de forma estratégica… 
o seu custo total de vida começa a cair. 
Menos remédio. 
Menos médico. 
Menos gripe que te derruba. 
Menos produto de beleza tentando corrigir o que vem de dentro. 
Menos suplemento que você comprava achando que estava se nutrindo. 
 
Sua vida fica mais simples. 
Seu carrinho fica mais simples. 
E seu corpo começa a funcionar como você nunca viu antes. 
Agora vamos pra base: 
A dieta carnívora gira em torno de alimentos de origem animal: 
• ovos 
• manteiga 
• carne de boi 
• porco 
• frango 
• bode 
• caça (dependendo da região) 
• Frutos do mar 
E tudo que vem desses animais: 
• sebo bovino 
• banha suína 
• ossos 
• cartilagem 
• vísceras 
Tudo isso não só é permitido… 
como é estratégico. 
 
Uma coisa importante: 
Os preços variam dependendo da região onde você mora. 
Então não se prenda a números exatos. 
Nossa escala aqui será: muito barato, barato, médio e acessível. 
Onde muito barato é o menor custo possível e acessível é um custo relativamente porém 
ainda justo! 
O que eu não vou te ensinar: decorar preço. 
O que eu vou te ensinar: entender a lógica e escolher as melhores opções. 
Porque quando você entende a lógica… 
você consegue comer bem em qualquer lugar — gastando menos. 

Agora é simples: 
o que você coloca no carrinho? 
A maioria das pessoas trava aqui. 
Entende o conceito… mas na hora do mercado, não sabe o que fazer. 
E aí volta pro padrão antigo. 
Isso não vai acontecer com você. 
 
A Regra de Ouro 
Seu carrinho precisa ter 3 coisas: 
• proteína (constrói e sustenta) 
• gordura (energia e saciedade) 
• base simples (volume/qualidade) 
Só isso. 
Se você seguir essa lógica, 
não tem como errar. Vou deixar a sua vida fácil, e abaixo vou te mostrar os melhores cortes 
econômicos dividido em: Carne Bovina, frango, porco, peixes, laticínios e gordura para 
cozinhar. 
 
Carne Bovina 
Os cortes mais baratos do boi vêm, em geral, de regiões mais trabalhadas do animal. Isso 
significa mais colágeno, mais sabor… e preparo diferente. 
Acém 
• Preço médio: um dos mais baratos do boi 
• Por que é barato: músculo muito utilizado → mais fibras duras 
• Melhor preparo: 
o panela de pressão 
o carne desfiada 
o cozidos longos 
Estratégia: perfeito para fazer marmita. Fica extremamente macio quando bem cozido. 
Paleta 
• Preço médio: semelhante ao acém (às vezes até mais barato) 
• Por que é barato: corte dianteiro, com bastante tecido conjuntivo 
 
• Melhor preparo: 
o cozidos 
o ensopados 
o moída 
 Diferencial: mais saborosa que o acém quando bem preparada. 
 
Músculo 
• Preço médio: muito barato 
• Por que é barato: altíssimo teor de colágeno 
• Melhor preparo: 
o caldos 
o sopas 
o panela de pressão 
Aqui está o ouro: 
Esse é um dos mais nutritivos que existem. Rico em colágeno → pele, articulações e intestino 
agradecem. 
 
Peito 
• Preço médio: barato 
• Por que é barato: corte grande, com gordura e fibras rígidas 
• Melhor preparo: 
o cozimento lento 
o forno baixo por várias horas 
o estilo “carne de panela” 
 Resumo: é o “brisket brasileiro”. Quando bem feito, vira uma das carnes mais saborosas. 
 
Costela 
• Preço médio: varia, mas geralmente acessível 
• Por que é barato: muito osso + preparo demorado 
• Melhor preparo: 
o forno lento (4–6h) 
 
o panela de pressão 
o fogo baixo por longo tempo 
Regra de ouro: 
Tempo transforma esse corte. Quem tem paciência come melhor e mais barato 
 
Obs.: todas formas de preparo estão disponíveis no curso. 
 
Fígado — o alimento mais nutritivo do açougue 
• Preço médio: muito barato 
• extremamente rico em nutrientes 
• pouco consumido (por isso o preço baixo) 
• Melhor preparo: 
o Frito/grelhado 
Ele entrega: 
✔ vitaminas do complexo B 
✔ ferro altamente absorvível 
✔ nutrientes essenciais para energia 
 
Carne Moída — O verdadeiro coringa do açougue 
Se existe um alimento que resolve a vida de quem quer economizar sem renunciar a nutrição, 
é a carne moída. 
Ela não é um corte específico — e é exatamente isso que faz dela tão estratégica. 
Preço médio 
• Geralmente mais barato que cortes “de vitrine” 
• Pode variar bastante dependendo do açougue 
• Quando bem escolhida → melhor custo-benefício do açougue inteiro 
Por que ela é mais barata? 
A carne moída costuma ser feita a partir de cortes menos valorizados ou sobras de cortes 
maiores. 
Isso significa: 
• menos “apelo comercial” 
• mais aproveitamento do animal 
 
• menor preço final 
E aqui está o ponto importante: 
isso não significa pior qualidade — significa apenas menor marketing. 
 
O detalhe que quase ninguém sabe 
Dependendo do açougue, a carne moída pode vir de: 
• acém 
• paleta 
• músculo 
• misturas de cortes 
Ou seja: você pode estar comendo exatamente os cortes baratos… só que já prontos. 
 
Melhor estratégia de compra (isso muda o jogo) 
Sempre que possível, peça: 
 “moer na hora” 
 escolha o corte (acém ou paleta são os melhores) 
Isso te dá: 
• controle da qualidade 
• controle da gordura 
• mais segurança alimentar 
ou um açougue de confiança que tem carne moída de retalhos (essa chega a ser 22 reais o Kg) 
 
 Melhor preparo 
A carne moída é extremamente versátil: 
• refogada simples (base de qualquer dieta) 
• hambúrguer caseiro 
• carne com ovos 
• recheios 
• marmitas 
Dica prática: 
Faça em quantidade grande e deixe pronto na geladeira → vira base de várias refeições. 

Gordura e Carne Moída: não cometa esse erro 
Muita gente pede carne moída “magra”. 
Erro. 
 Um pouco de gordura: 
• melhora o sabor 
• aumenta a saciedade 
• facilita o preparo 
 
Cortes Subestimados do Boi 
Aqui estão cortes que muita gente evita — mas quem entende usa como base da alimentação. 
 São baratos, extremamente nutritivos e, quando bem preparados, ficam absurdamente 
saborosos. 
Mocotó 
• Preço médio: muito barato 
• Por que é barato: basicamente pé do boi → pouca procura 
• Melhor preparo: 
o panela de pressão 
o caldos e gelatinas naturais 
o cozimento longo 
Aqui está o diferencial: 
Riquíssimo em colágeno. 
• pele 
• articulações 
• intestino 
Resultado: forma um caldo espesso (quase uma “gelatina”) — isso é nutrição de verdade. 
Peito com osso 
• Preço médio: barato 
• Por que é barato: muito osso + preparo demorado 
• Melhor preparo: 
o cozimento lento 
 
o panela de pressão 
o forno baixo por horas 
Diferencial: 
O osso libera minerais e colágeno → muito mais nutritivo que carne “limpa”. 
 
Rabo (Rabada) 
• Preço médio: barato a moderado (ainda assim ótimo custo-benefício) 
• Por que é barato: preparo demorado + menos popular 
• Melhor preparo: 
o panela de pressão 
o cozidos longos 
Resultado: 
Carne extremamente macia + caldo rico e encorpado. 
Resumo: sabor intenso e nutrição alta. 
 
Ossobuco 
• Preço médio: acessível 
• Por que é barato: corte com osso e tutano 
• Melhor preparo: 
o cozimento lento 
o panela de pressão 
o ensopados 
Aqui tem outro “segredo”: 
O tutano (parte interna do osso) é extremamente nutritivo e energético. 
 
O padrão por trás de tudo isso 
Se você reparar, todos esses cortes têm algo em comum: 
• osso 
• colágeno 
• preparo lento 
 
E é exatamente por isso que são baratos. 

O que a maioria faz vs. o que funciona 
A maioria: 
• compra carne “limpa” 
• paga caro 
• perde nutrientes 
Quem entende: 
• compra cortes com osso 
• usa tempo como aliado 
• extrai mais nutrição pagando menos 
 
Regra prática 
Se tiver: 
• osso 
• cartilagem 
• gordura 
provavelmente é mais barato e mais nutritivo. 
 
Estratégia inteligente 
Esses cortes são perfeitos para: 
• fazer grandes quantidades 
• preparar marmitas 
• produzir caldos base 
 Um preparo → várias refeições 

Frango 
A maioria das pessoas compra peito de frango achando que está economizando. 
Não está. 
 
Coxa e Sobrecoxa 
• Preço médio: mais barato que peito 
• Por que é barato: menor demanda (as pessoas têm preconceito com gordura) 
• Melhor preparo: 
o forno 
o air fryer 
o frigideira 
o ensopados 
 Por que são melhores que peito: 
• mais sabor 
• mais gordura (saciedade) 
• mais difícil de errar no preparo 
• menos ressecadas 
Resumo direto: 
Mais barato, mais gostoso e mais nutritivo. 
 
Asinha 
• Preço médio: barato a moderado (depende da região) 
• Por que é barato: menor quantidade de carne por peça 
• Melhor preparo: 
o air fryer 
o forno 
o frita 
Diferencial: 
Muito sabor por conta da gordura e da pele. 
 
Coxinha da Asa (Drumette) 
• Preço médio: semelhante à asinha ou mais barato em alguns lugares 
• Por que é barato: menos “nobre” que outros cortes 
• Melhor preparo: 
o forno 
o air fryer 
o frita 
 Vantagem: 
Mais carnuda que a asinha e muito prática. 
Coxa e Sobrecoxa (com osso) 
• Preço médio: um dos melhores custo-benefício do frango 
• Por que é barato: menor demanda que peito 
• Melhor preparo: 
o forno 
o frigideira 
o air fryer 
o ensopados 
 Por que com osso é melhor: 
• mais barato 
• mais sabor 
• mais nutrientes (colágeno do osso) 
• menos risco de ressecar 
 Resumo direto: 
É um dos cortes mais inteligentes que você pode comprar. 
Frango Inteiro 
• Preço médio: o mais barato por quilo 
• Por que é barato: menos praticidade → menos procura 
• Melhor uso: 
o cortar em partes 
o assar inteiro 
o usar carcaça para caldo 
 
Aqui está o maior “hack”: 
Comprando o frango inteiro você consegue: 
• coxa 
• sobrecoxa 
• peito 
• asa 
• carcaça (para caldo) 
 Ou seja: você paga mais barato e aproveita 100% do alimento. 
 
Ovos — Um dos alimentos mais completos que existem 
• Preço médio: geralmente acessível 
• Por que é barato: produção em larga escala 
• Melhor preparo: 
o cozido 
o mexido 
o frito 
o omelete 
Obs.: Procure um produtor local para ovos de quintal. Te garanto que o sabor é bem melhor 
e qualidade nutricional também. Se não tema acesso a ovos de quintal ou não pode investir 
no momento compre ovos comuns e siga. O bom não é inimigo do ótimo. 
 
Vísceras de Frango 
Dentro das opções mais econômicas, as vísceras de frango são imbatíveis. 
 
Moela 
• Preço médio: extremamente barato 
• Por que é barato: textura mais firme → menos popular 
• Melhor preparo: 
o panela de pressão (essencial) 
o ensopados 
o cozimento longo 
 
Importante: 
Se fizer rápido, fica dura. 
Se fizer do jeito certo, fica macia e muito saborosa. 
Estratégia: 
Perfeita para marmita barata e volumosa. 
Coração de Frango 
• Preço médio: médio 
• Por que é barato: menor demanda fora de churrasco 
• Melhor preparo: 
o frigideira 
o air fryer 
o espetinho 
 
Diferencial: 
Rico em nutrientes e com ótima quantidade de gordura → dá muita saciedade. 
 
Fígado de Frango 
• Preço médio: muito barato 
• Por que é barato: sabor mais forte → menos aceitação 
• Melhor preparo: 
o frigideira rápida 
o com cebola 
o não cozinhar demais 
o Fazer patês temperados 
 Aqui está um dos maiores “hacks” nutricionais: 
• extremamente rico em vitaminas (principalmente do complexo B) 
• ajuda em energia, disposição e recuperação 

Porco 
O porco é uma máquina de custo-benefício — e quase ninguém aproveita. 
Pernil 
• Preço médio: muito barato 
• Por que é barato: corte grande → pouca praticidade 
• Melhor preparo: 
o assado 
o desfiado 
o cubos para marmita 
Estratégia: 
Compra grande → prepara tudo → come a semana inteira. 
 
Costela Suína 
• Preço médio: barato a moderado 
• Por que é barato: preparo mais demorado 
• Melhor preparo: 
o forno lento 
o churrasqueira 
o panela de pressão + finalização 
Resultado: 
Carne macia, suculenta e muito mais barata que cortes “gourmet”. 
Sarapatel (miúdos suínos) 
• Preço médio: muito barato 
• Por que é barato: feito com vísceras → baixa demanda 
• Melhor preparo: 
o cozimento longo 
o ensopados 
o bem temperado 
Diferencial: 
Altamente nutritivo, rico em ferro e vitaminas. 
 
Resumo: 
É o equivalente às vísceras do frango — barato e potente. 
Barriga Suína (Panceta) 
• Preço médio: acessível 
• Por que é barato: alto teor de gordura 
• Melhor preparo: 
o forno 
o pururuca 
o frigideira 
Diferencial: 
Extremamente energética → dá muita saciedade. 
Picanha Suína 
• Preço médio: mais barato que a picanha bovina 
• Por que é barato: menor valorização comparado ao boi 
• Melhor preparo: 
o forno 
o churrasqueira 
o frigideira 
Resumo: 
Entrega experiência de “corte nobre” com custo muito menor. 
 
Lombo 
• Preço médio: barato a moderado 
• Por que é barato: carne mais magra → menos valorizada 
• Melhor preparo: 
o assado 
o em bifes 
o com gordura adicionada 
Ponto importante: 
Pode ressecar fácil → precisa de atenção no preparo. 

Copa Lombo 
• Preço médio: acessível 
• Por que é barato: pouco conhecido pela maioria 
• Melhor preparo: 
o grelhado 
o assado 
o bifes 
Diferencial: 
Mais marmorizado que o lombo → mais sabor e suculência. 
 
Bacon 
• Preço médio: varia, mas rende bem 
• Por que é estratégico: alta densidade energética 
• Melhor preparo: 
o frigideira 
o forno 
o air fryer 
prefira: 
• menos ingredientes 
• menos aditivos 
• versões mais simples 
 
Combinação poderosa 
O clássico não é à toa: 
 ovos + bacon 
Você tem: 
✔ proteína completa 
✔ gordura suficiente 
✔ saciedade alta 
 e tudo isso com preparo simples. 

O padrão do porco 
O porco tem uma vantagem enorme: 
✔ cortes grandes 
✔ boa quantidade de gordura 
✔ ótimo aproveitamento 
 Isso permite comprar barato e render várias refeições. 
 
 Estratégia inteligente 
• comprar peças maiores (pernil, barriga, lombo) 
• preparar tudo de uma vez 
• dividir ao longo da semana 
isso reduz custo e tempo. 
 
 Resumo direto 
O porco entrega: 
✔ preço baixo 
✔ alta saciedade 
✔ versatilidade 
É um dos pilares de uma alimentação econômica de verdade. 
 
Regra de ouro 
Se você quer economizar de verdade: 
• não ignore o porco 
• não tenha medo da gordura 
• aprenda a preparar 

Peixes 
Diferente do boi, frango e porco, o peixe tem uma variável importante: 
região influencia totalmente o preço 
O que é barato no litoral pode ser caro no interior — e vice-versa. 
Por isso, mais importante do que decorar nomes, é entender o padrão. 
Regra de ouro do peixe barato 
Se você lembrar disso, nunca paga caro sem necessidade: 
peixe da região → mais barato 
peixe da safra → mais barato 
peixe menos “famoso” → mais barato 
peixe inteiro → mais barato 
 
Peixes geralmente mais acessíveis no Brasil 
Esses são comuns em várias regiões e costumam ter bom custo-benefício: 
 
Sardinha 
• Preço médio: muito barato 
• Por que é barato: abundante e pouco valorizado 
• Melhor preparo: 
o grelhada 
o assada 
o frita 
Diferencial: 
• rica em gordura boa 
• extremamente nutritiva 
 Resumo: 
Um dos melhores alimentos custo-benefício que existem. 
 
Tilápia 
• Preço médio: acessível 
• Por que é barato: criação em larga escala 
• Melhor preparo: 
 
o grelhada 
o frita 
o assada 
Ponto importante: 
Mais magra → pode precisar de gordura no preparo. 
Comprar inteiro e mais barato que file e mais saboroso. 
 
Merluza (filé congelado) 
• Preço médio: barato 
• Por que é barato: importado e congelado 
• Melhor preparo: 
o empanado 
o forno 
o frigideira 
Estratégia: 
Boa opção para praticidade e preço. 
 
Cavalinha 
• Preço médio: muito barato 
• Por que é barato: menos popular 
• Melhor preparo: 
o grelhada 
o assada 
Diferencial: 
Parecida com sardinha → nutritiva e sabor forte 
 
Estratégia que muda o jogo 
Em vez de procurar um peixe específico, faça isso: 
 vá ao mercado ou peixaria 
 pergunte: 
“qual peixe está mais barato hoje?” 

 Peixe inteiro vs. filé 
Sempre que possível: 
 compre inteiro 
Porque: 
✔ é mais barato 
✔ vem com mais nutrientes 
✔ dá para usar tudo (inclusive espinha para caldo) 
 
Dica prática (pouca gente faz) 
Use: 
• cabeça 
• espinha 
• restos 
para fazer caldo de peixe 
Isso aumenta MUITO o aproveitamento e reduz custo. 
 
Erro comum 
Comprar só: 
• salmão 
• atum fresco 
• peixes “gourmet” 
Resultado: alimentação cara e desnecessariamente limitada. 

Abaixo segue tabelas resumidas das opções de cortes: 

Laticínios 
 
Queijo pode ser tanto um vilão do orçamento… quanto um 
aliado poderoso. 
O queijo se encaixa como: gordura + complemento proteico. 
• tem proteína sim 
• MAS não em quantidade ideal para ser base (densidade nutricional) 
 exemplo: 
• 100g de carne → alta proteína e base densa de nutrientes 
• 100g de queijo → proteína e gordura só que menos base densa de nutrientes 
 
LEMBRANDO: 
Densidade nutricional é: 
quantos nutrientes você recebe por quantidade de alimento. 
Ou seja: 
• vitaminas 
• minerais 
• aminoácidos 
• gorduras importantes 
 
Erro comum 
Muita gente faz isso: 
“vou comer queijo como fonte de proteína” 
Resultado: 
• proteína insuficiente 
• calorias altas 
• dieta desbalanceada em densidade nutricional 
Use queijo para: 
✔ complementar refeições 
✔ aumentar saciedade 
✔ melhorar sabor 
 
NÃO para substituir a carne. 
Cuidado com os queijos de hoje — nem tudo é queijo de 
verdade 
Antigamente, queijo era basicamente: 
 leite + fermentação + tempo 
Hoje, muitos produtos que parecem queijo são, na prática: 
misturas industriais com aditivos 
Muitos queijos mais baratos ou ultraprocessados contêm: 
• amido (para dar volume e textura) 
• espessantes 
• estabilizantes 
• gorduras modificadas 
Resultado: 
Você acha que está comendo queijo… 
mas está consumindo um produto adulterado 
 
Como identificar 
Antes de comprar, olhe o rótulo. 
Evite produtos com: 
• “amido” 
• “fécula” 
• “produto lácteo” (em vez de queijo) 
• lista de ingredientes muito longa 
Regra simples: 
quanto mais ingredientes → menos é queijo de verdade 
 
Sobre muçarela, prato e similares de mercado 
Vamos ser diretos: 
muitos desses queijos de mercado eu não confiaria. 
Por quê? 
Porque, na prática, muitos deles: 
• passam por alto nível de processamento 
 
• recebem aditivos 
• podem conter amido e estabilizantes 
• têm qualidade variável (depende muito da marca) 
Resultado: 
você consome algo que parece queijo… 
mas não tem a mesma qualidade nutricional. 
O cenário ideal 
Se você mora em uma região que tem: 
✔ queijos artesanais 
✔ produção local 
✔ fermentação real 
✔ leite + fermento + tempo 
aí você está em outro nível. 
O que define um queijo de verdade: 
• poucos ingredientes 
• processo tradicional 
• maturação (quando aplicável) 
• ausência de “enchimentos” 
Isso sim é alimento de verdade. 
 
Aqui vão alguns exemplos de queijos que você pode encontrar com facilidade. 
Mas atenção: 
o nome do queijo não garante qualidade. 
O que importa é como ele foi feito 
Muçarela, queijo prato, queijo coalho, curados (parmesão, meia cura, minas curado) 
 
Queijos Curados — Mais qualidade, mais densidade, menos 
interferência 
Se você quer consumir queijo de forma mais estratégica, precisa entender isso: 
queijos curados são, na maioria das vezes, superiores. 

Resumo direto 
Você pode até comprar: 
• muçarela 
• prato 
• minas 
• coalho 
 desde que respeite os critérios de queijo de verdade. 

Gorduras 
Principais gorduras para usar no dia a dia: 
 
Manteiga 
• fácil de encontrar 
• sabor excelente 
• boa opção para preparo 
 Melhor uso: 
• ovos 
• frigideira 
• finalização de pratos 
 
Sebo (gordura bovina) 
• extremamente estável 
• muito nutritivo 
• barato (muitas vezes você consegue no açougue) 
Melhor uso: 
• frituras 
• carnes 
• alta temperatura 
Diferencial: 
uma das melhores gorduras para cozinhar 
 
Banha de porco 
• acessível 
• tradicional 
• ótima estabilidade 
Melhor uso: 
• frituras 
• refogados 
 
• uso geral 
Resumo: 
uma das opções mais práticas e baratas 
 
Dica prática 
Quando fizer carne: 
aproveite a própria gordura da carne 
Isso já resolve grande parte do preparo.
