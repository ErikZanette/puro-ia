# Curso Introdução à Carnívora: Bloco 4 (estudos)

Bloco 4 - Estudos
Bloco 4 - Estudos 

4.1 Entendendo Estudos 
Antes de comentar sobre os estudos específicos da dieta carnívora, é importante entender como a ciência funciona e por que nem toda evidência tem o mesmo valor.
Existe uma hierarquia dos estudos, que vai dos mais fracos aos mais confiáveis. A base dessa pirâmide inclui estudos de caso e relatos individuais. Um pouco acima estão os estudos observacionais, que representam a maior parte das pesquisas em nutrição. No topo da pirâmide estão os ensaios clínicos randomizados (RCTs) e, acima deles, as meta-análises de vários estudos controlados, que são o padrão-ouro da ciência.
Mas aqui está o problema: a esmagadora maioria dos estudos que tentam associar comida a doenças não são ensaios clínicos randomizados, mas sim estudos observacionais.
E estudos observacionais não provam nada. Eles servem como uma porta de entrada. Ou pelo menos deveriam

O Problema dos Estudos Observacionais
Um estudo observacional funciona assim: pesquisadores coletam dados sobre os hábitos alimentares de um grande grupo de pessoas e, depois de alguns anos, analisam se há alguma relação entre o que elas comeram e o desenvolvimento de doenças. Parece confiável à primeira vista, mas tem um problema gigantesco: associação não é causalidade.
Um exemplo clássico disso são os estudos que dizem que carne vermelha está associada a doenças cardíacas. Como eles chegam a essa conclusão? Eles simplesmente perguntam para as pessoas o que elas comeram nos últimos anos e depois tentam encontrar padrões nas respostas.
Agora me diz: você lembra exatamente o que comeu na terça-feira passada? E no mês passado? Pois é. Os dados desses estudos vêm de questionários completamente falhos, onde as pessoas chutam respostas baseadas na memória.
E o problema não para por aí. Quem come mais carne vermelha, normalmente, também pode come mais fast food, frituras, pão de hambúrguer e batata frita. Por outro lado, quem evita carne vermelha geralmente está mais preocupado com a saúde, faz mais exercícios, fuma menos e bebe menos álcool.
Como você separa esses fatores? Você não separa.
Esses estudos não têm como isolar a carne vermelha do estilo de vida da pessoa. Eles apenas identificam padrões, mas não conseguem dizer o que está causando o quê. Ou seja, existe uma associação, mas não existe causa.

Associação Não É Causalidade
Vamos fazer um exercício mental. Imagine que um estudo descobre que pessoas que compram mais isqueiros têm uma taxa maior de câncer de pulmão. Podemos concluir que isqueiros causam câncer?
Claro que não. O que está acontecendo aqui é que isqueiros estão associados ao fumo, e é o cigarro que realmente causa o câncer.
Mais um se não ficou na cara:Num verão na Austrália, foi descoberto que ataques de tubarão na praia estavam associados com a venda de sorvete. Quanto mais sorvete vendia, mais ataques de tubarão aconteciam. Podemos concluir que a venda dos sorvetes estavam causando os ataques de tubarão? 
Claro que não. Provavelmente, já que era verão, mais pessoas compravam sorvete por causa do calor, e também mais pessoas decidiam ir pra praia, o que aumentaria a incidência dos ataques de tubarão.
Isso é exatamente o que acontece na maioria dos estudos nutricionais. Eles encontram associações entre certos alimentos e doenças, mas essas associações podem estar sendo causadas por dezenas de outros fatores invisíveis.
E tem um detalhe que ninguém comenta: existe um critério para considerar uma associação forte o suficiente para justificar estudos mais controlados. Na epidemiologia, um risco relativo acima de 2.0 (ou seja, um aumento de 100% no risco) já é um bom indicativo de que talvez valha a pena investigar mais a fundo. Mas o que acontece na nutrição? A maioria dos estudos que tentam associar carne a doenças apresenta riscos relativos entre 1.1 e 1.3 (ou seja, um aumento de apenas 10% a 30%)—valores estatisticamente irrelevantes que poderiam ser explicados por erro, viés ou fatores de confusão. Não vamos entrar em detalhes em como calcular o risco relativo nesse curso.
E o pior? Esses estudos fracos, que mal deveriam ser levados a sério, acabam virando manchete de jornal como se fossem verdades absolutas. Você já viu algo como “Comer carne aumenta o risco de câncer em 20%”? Esse número parece alto, mas não significa nada em termos de causalidade—e, mesmo se fosse real, ainda seria um risco absolutamente insignificante na prática. E não aumenta realmente, “está associado” seria a palavra certa.Só pra vocês terem uma ideia, o risco relativo para fumantes pode chegar a 25 vezes maior (ou seja, 2.500% de aumento no risco). Esse é um risco enorme e indiscutível, validado por inúmeros estudos de alta qualidade, incluindo ensaios clínicos e meta-análises.
E tem mais: estudos observacionais são perfeitos para manipulação de dados. Como os pesquisadores já sabem o que querem encontrar, eles podem ajustar estatísticas, ignorar fatores e escolher subgrupos de dados até conseguirem um resultado que confirme sua hipótese.
É exatamente assim que a carne vermelha foi demonizada ao longo das últimas décadas.
John Ioannidis, um dos epidemiologistas mais respeitados do mundo, e professor da faculdade de Stanford, publicou um artigo afirmando que quase todas as diretrizes nutricionais que seguimos hoje foram baseadas em estudos observacionais de baixa qualidade e não possuem nenhuma evidência real de causa e efeito.
📌 Referência: Ioannidis, J. (2013) – Implausible Results in Nutritional Epidemiology Link: Implausible results in human nutrition research | The BMJ
Então, quando você ouve que "carne está relacionada ao câncer" ou "gordura saturada aumenta o risco de doenças cardíacas", agora você entende que essa “relação” não significa nada em termos de causalidade e pode ser extremamente fraca.

4.2 Como Podemos Ter Causalidade na Nutrição?
Agora voce deve estar se perguntando: Se estudos observacionais não podem provar causa e efeito, então como poderíamos realmente demonstrar que um alimento específico causa ou previne uma doença?
A única forma de estabelecer causalidade absoluta na nutrição seria através de um ensaio clínico randomizado (RCT) altamente controlado e de longa duração.
Mas pensa na complexidade disso. Para fazer um estudo nutricional perfeito, teríamos que pegar gêmeos idênticos e trancá-los em um laboratório, sob total controle, por décadas. Eles não poderiam escolher o que comer, e cada refeição teria que ser cuidadosamente controlada, garantindo que houvesse apenas uma única diferença entre as dietas, para que qualquer efeito observado pudesse ser atribuído exclusivamente a essa variação. Além disso, não poderiam sair para interagir com o mundo exterior e teriam que viver exatamente nas mesmas condições—o mesmo nível de atividade física, o mesmo sono, o mesmo nível de estresse, os mesmos horários de refeição, sem álcool, sem cigarro e sem qualquer outro fator que pudesse interferir nos resultados.
E mesmo se conseguíssemos fazer isso, essa certeza só valeria para os anos do estudo. No momento em que os participantes saíssem do ambiente controlado, qualquer fator externo poderia mudar completamente os resultados.
Agora me diz: quem financiaria um estudo assim? Quem aceitaria viver trancado por anos?
A resposta é óbvia: isso nunca vai acontecer.
E é por isso que estudos de nutrição são, na maioria das vezes, cheios de falhas e incertezas. O que temos são estudos curtos, mal controlados e com inúmeras variáveis não consideradas, que depois são usados para criar diretrizes alimentares que afetam milhões de pessoas.
O Que Realmente Podemos Considerar?
Se estudos observacionais não provam nada, o que podemos considerar para entender qual é a alimentação ideal para o ser humano?
A resposta está em três áreas principais:
✅ Evolução – O que comemos durante a maior parte da história humana? O que nossos ancestrais consumiam quando éramos caçadores-coletores?
✅ Anatomia – Como nosso corpo está estruturado? Nosso sistema digestivo é mais parecido com o de um herbívoro, um onívoro ou um carnívoro?
✅ Fisiologia – Como nosso metabolismo responde a diferentes tipos de alimentos? O que realmente precisamos para sobreviver?
E aqui está um ponto essencial: diferente dos estudos observacionais em nutrição, que são cheios de variáveis não controladas, os estudos sobre fisiologia são diretos e objetivos. Podemos medir exatamente como um alimento afeta a insulina, como o fígado responde à ingestão de gordura ou proteína, e como o corpo gera energia na ausência de carboidratos. Esses estudos não dependem de questionários falhos ou associações estatísticas—eles mostram o que realmente acontece dentro do corpo humano. Dai eh so usar a lógica para perceber o que é ideal ou não.
Além disso, estudos de isótopos estáveis mostram como um fato o tipo de alimentação que tivemos por milhões de anos, confirmando que nossa dieta foi predominantemente baseada em carne.
E as meta-análises de estudos nutricionais? Sim, as famosas meta-análises, que são consideradas o padrão-ouro da ciência. O problema é que uma meta-análise é apenas uma análise estatística de estudos pré-existentes—e se esses estudos forem ruins, a meta-análise também será. Se um estudo observacional isolado já é pouco confiável, então uma meta-análise de 80 estudos observacionais será exponencialmente menos confiável. É como tentar obter um resultado preciso somando um monte de dados imprecisos. No fim das contas, não importa quantos estudos ruins você empilhe, você nunca terá uma verdade científica sólida.
Quando olhamos para essas evidências, a resposta fica clara: nosso corpo foi otimizado para consumir carne e gordura como fonte principal de energia.
Agora que já entendemos sobre os estudos nutricionais, vamos analisar alguns que talvez mostrem os beneficios de uma dieta carnivora. 
se quiser que eu te ajude mais de perto nessa jornada, pode me mandar mensagem no meu Instagram [contato removido] ou no meu e-mail: [contato removido].

4.3 O primeiro experimento documentado
Agora que entendemos sobre os estudos de nutrição, a partir de agora vamos analisar alguns realmente relevantes—e que obviamente não são observacionais!
E o mais antigo e bem documentado de todos não tem nada a ver com perda de peso ou saúde metabólica—mas sim com o tratamento de uma condição neurológica grave: a epilepsia.
Muito antes de existirem medicamentos anticonvulsivantes, médicos já sabiam que havia algo na ausência de carboidratos que reduzia drasticamente as crises epilépticas. E o mais interessante? Isso não foi descoberto por acaso—foi baseado em algo que a humanidade já conhecia há milhares de anos: o jejum.
O melhor de tudo? Quando você faz uma dieta carnívora, você entra no mesmo estado metabólico que o jejum proporciona: a cetose.
Mas como isso começou?
O Primeiro Grande Estudo: Dieta Cetogênica e Epilepsia
A relação entre jejum e epilepsia é registrada há pelo menos 2.500 anos. Textos da Grécia Antiga mencionam que o jejum podia interromper convulsões. Mas foi apenas no início do século XX que essa observação passou a ser estudada sistematicamente.
Em 1921, o Dr. Russell Wilder, da Mayo Clinic, formulou a hipótese de que os benefícios do jejum para epilepsia estavam relacionados à cetose—e que, portanto, seria possível replicar esse estado metabólico sem precisar parar de comer. Foi assim que ele criou a dieta cetogênica, uma estratégia alimentar que reduz os carboidratos ao mínimo e força o corpo a usar gordura como combustível.
📌 Referência: Wilder RM. (1921) – The Effects of Ketoanemia on the course of Epilepsy → O estudo que introduziu a dieta cetogênica como tratamento clínico para epilepsia.
History of dietary treatment from Wilder's hypothesis to the first open studies in the 1920s - Epilepsy & Behavior
Deixa eu te contar a história de como esse estudo foi conduzido?
Na década de 1920, a medicina ainda não tinha respostas para a epilepsia severa. Pacientes, muitos deles crianças, passavam a vida inteira sofrendo crises constantes, sem qualquer esperança de melhora. Mas então, um médico chamado H. R. Geyelin fez uma descoberta surpreendente: ao submeter 26 pacientes epilépticos a um período de dez dias de jejum absoluto, 22 deles apresentaram melhora significativa, e alguns permaneceram sem convulsões por mais de um ano. Isso foi revolucionário, mas havia um problema—jejuar por longos períodos não era sustentável.
Foi aí que entrou o Dr. Russell Wilder, da Mayo Clinic. Ele se perguntou: e se pudéssemos imitar os efeitos do jejum sem precisar parar de comer? Wilder desenvolveu uma abordagem inovadora: uma dieta rica em gordura e extremamente baixa em carboidratos, que manteria o corpo no mesmo estado metabólico do jejum—ou seja, em cetose.
Os resultados foram impressionantes. Pacientes que antes tinham crises diárias viram suas convulsões reduzirem drasticamente, e em muitos casos, elas desapareceram completamente. Além disso, houve melhora no humor, na clareza mental e nos níveis de energia. Pela primeira vez, um tratamento real para a epilepsia estava nascendo—e ele não envolvia nenhum medicamento.
E o mais incrível? Esse tratamento ainda é usado hoje, mais de 100 anos depois, especialmente para casos de epilepsia refratária—situações em que nem os medicamentos mais modernos conseguem controlar as convulsões.
Mas por que isso funciona?
A ciência moderna sugere que as cetonas não são apenas uma fonte de energia alternativa—elas também têm propriedades neuroprotetoras. Elas estabilizam a atividade elétrica no cérebro, reduzem inflamação e fornecem um combustível mais eficiente do que a glicose.
Uma pergunta pra você se fazer: Se a cetose vem de diminuir os carboidratos, e tem essas propriedades terapêuticas, porque diminuir carbo seria ruim?
E aqui está a grande sacada: se a cetose pode proteger o cérebro contra algo tão grave como a epilepsia, quais outros benefícios ela pode oferecer? Vamos ver nos proximos videos.

4.4 Transtorno Bipolar, Esquizofrenia e Cetose
Pesquisas recentes mostram que transtornos como bipolaridade e esquizofrenia podem estar ligados a falhas no metabolismo energético do cérebro. Neurônios nessas condições lutam para gerar energia a partir da glicose, o que pode causar desregulação extrema da atividade cerebral.
A cetose fornece um combustível alternativo mais eficiente para o cérebro, estabilizando a função neuronal. Isso não é apenas teoria—os primeiros ensaios clínicos já confirmam esse efeito na prática.
📌 Estudo Clínico: A Dra. Shebani Sethi, da Universidade de Stanford, conduziu o primeiro ensaio clínico randomizado testando a dieta cetogênica em 21 pacientes com bipolaridade e esquizofrenia ao longo de 4 meses. Estudos nutricionais são extremamente difíceis de conduzir, mas os resultados foram impressionantes:
✅ 31% de melhora geral na gravidade da doença✅ 43% dos pacientes atingiram recuperação completa (50% entre os que seguiram a dieta corretamente)✅ Entre os bipolares, 81% entraram em estado de recuperação✅ Entre os esquizofrênicos, houve uma redução de 32% nos sintomas psiquiátricos✅ Melhoras significativas na qualidade de vida, função cognitiva e qualidade do sono
Além dos dados clínicos, os relatos dos pacientes revelam transformações profundas:
"Desde que comecei a dieta, minha ansiedade desapareceu. Pela primeira vez, consigo enfrentar qualquer situação sem entrar em pânico."
"Se eu não tivesse feito essa mudança, não sei se ainda estaria aqui. A cetose salvou minha vida."
"Minha bipolaridade foi colocada em remissão. Meu humor se estabilizou, minha energia voltou e minha vida mudou completamente."
"Eu já tomei diversos estabilizadores de humor ao longo dos anos, mas nenhum funcionou tão bem quanto a cetose."
Os efeitos colaterais foram mínimos e transitórios, com pequenas queixas de fadiga e constipação nas primeiras semanas, que desapareceram rapidamente.
Este estudo é uma das evidências mais fortes até agora de que transtornos mentais podem ser profundamente influenciados pelo metabolismo—e que a cetose pode ser uma alternativa real e poderosa aos tratamentos tradicionais.
Ketogenic Diet Intervention on Metabolic and Psychiatric Health in Bipolar and Schizophrenia: A Pilot Trial - PubMed
Mechanisms of insulin resistance, mitochondrial dysfunction and the action of the ketogenic diet in bipolar disorder. Focus on the PI3K/AKT/HIF1-a pathway - PubMed

4.5 Depressão e Cetose
A depressão maior não é apenas um distúrbio emocional—ela está diretamente ligada a inflamação no cérebro e disfunção no metabolismo energético dos neurônios. Estudos mostram que o cérebro de pessoas com depressão frequentemente apresenta resistência à insulina, dificultando o uso da glicose como combustível.
A cetose pode ajudar ao fornecer uma fonte de energia alternativa (corpos cetônicos) e reduzir a inflamação cerebral, promovendo um ambiente mais estável para o funcionamento neuronal.
📌 Estudo Clínico: Em 2022, a Virta Health, uma clínica inovadora de cuidados para diabetes nos EUA, conduziu um estudo com 36 pacientes diagnosticados com depressão leve. Eles seguiram uma versão modificada da dieta Atkins por 10 semanas, atingindo níveis médios de cetonas de 0.6 mM.
Os resultados foram notáveis:
✅ Mais da metade dos participantes deixaram de atender aos critérios clínicos para depressão.✅ Quanto mais tempo passaram em cetose (acima de 0.5 mM), maior foi a melhora no humor.
Esse estudo reforça a teoria de que a depressão não é apenas um problema químico, mas também um problema metabólico e inflamatório—e que mudanças na alimentação podem desempenhar um papel crucial na recuperação.
Link: Depressive symptoms improve over 2 years of type 2 diabetes treatment via a digital continuous remote care intervention focused on carbohydrate restriction | Journal of Behavioral Medicine
Num estudo de Morris de 2020, foi demonstrado que a cetose desloca a microglia (as células de vigilância imunológica do cérebro) de um estado pró-inflamatório para um estado anti-inflamatório. Link: The role of microglia in neuroprogressive disorders: mechanisms and possible neurotherapeutic effects of induced ketosis - ScienceDirect

4.6 Autismo e Cetose
O transtorno do espectro autista (TEA) afeta cerca de 1% das crianças em todo o mundo e está associado a alterações na forma como o cérebro processa energia. Link: Global prevalence of autism: A systematic review update - Zeidan - 2022 - Autism Research - Wiley Online Library
Estudos indicam que as mitocôndrias de pessoas autistas apresentam dificuldades em transformar glicose em energia, principalmente devido a um defeito no Complexo I da cadeia de transporte de elétrons. 
A cetose pode ajudar ao fornecer uma rota alternativa de produção de energia, permitindo que o cérebro use Complexo II, contornando essa falha mitocondrial. Link: Mitochondrial Dysfunction in Autism Spectrum Disorder: Unique Abnormalities and Targeted Treatments - ScienceDirect
Além disso, dietas cetogênicas podem estimular a produção de novas mitocôndrias e melhorar a função das existentes, o que pode contribuir para um desenvolvimento neurológico mais estável.
📌 Estudo Clínico:
Um ensaio clínico randomizado de 6 meses no Egito analisou 45 crianças autistas, divididas em três grupos - um grupo de 15 crianças, considerado controle, fazia uma dieta balanceada, um grupo de 15 crianças fazia uma dieta sem glúten/caseína e um grupo de 15 fazia uma dieta cetogênica. Os resultados estão abaixo :
1️⃣ Grupo dieta balanceada → Nenhuma melhora2️⃣ Grupo dieta sem glúten/caseína → Melhora nos sintomas comportamentais3️⃣ Grupo dieta cetogênica → Melhora significativa na fala, cognição e interação social
Link: Ketogenic diet versus gluten free casein free diet in autistic children: a case-control study - PubMed
📌 Conclusão:
A dieta cetogênica pode ajudar a regular o metabolismo cerebral e promover melhores conexões neurais, oferecendo benefícios que vão além dos tratamentos convencionais.

4.7 Compulsão Alimentar, Vício em Comida e Cetose
Se lembram no módulo 1, quando falei que com a dieta carnívora os hormônios da grelina e leptina vão se regular? Então, existem alguns estudos que estão mostrando isso na prática.
A compulsão alimentar e o vício em comida são problemas devastadores que afetam a autoestima, o peso e a saúde mental, deixando muitas pessoas presas em um ciclo de culpa e descontrole. Diferente do que muitos acreditam, essas condições não são apenas questões psicológicas. Alimentos ultraprocessados são deliberadamente projetados para serem viciantes, estimulando excessivamente os centros de recompensa do cérebro e desregulando os hormônios da fome e da saciedade.
A dieta cetogênica pode ser uma das soluções mais poderosas para esse problema. Ao estabilizar os níveis de glicose e insulina, ela reduz os picos e quedas de energia que levam a desejos incontroláveis por comida. Isso significa menos fome, menos vontade de comer fora de hora e, principalmente, o fim do ciclo de compulsão alimentar.
Um estudo mostrou exatamente isso. Esse estudo é um estudo de caso, não é controlado, mas é bem interessante. Três pacientes diagnosticados com compulsão alimentar severa seguiram uma versão moderada da dieta cetogênica (máximo de 30g de carboidratos por dia) por seis meses. Os resultados foram impressionantes:
Os episódios de compulsão alimentar foram de uma ou duas vezes por dia para quase zero episódios por semana. Seis meses depois, os sintomas ainda estavam em remissão e os participantes haviam perdido entre 10% e 24% do seu peso corporal. Link: Treating binge eating and food addiction symptoms with low-carbohydrate Ketogenic diets: a case series | Journal of Eating Disorders | Full Text
Agora, esses números são impressionantes, mas vamos para um caso real, que mostra o impacto dessa mudança na vida de uma pessoa.
A Dra. Georgia Ede acompanhou uma paciente chamada Deanna (nome fictício), que sofria há 40 anos com compulsão alimentar, depressão e ansiedade severas. Sua rotina era sempre a mesma: começava a beliscar alimentos no final da tarde e, antes que percebesse, passava a noite inteira comendo compulsivamente.
Ela já havia tentado diversos medicamentos para controlar seu apetite, incluindo antidepressivos, estimulantes e bloqueadores de receptores opioides, mas nenhum funcionou a longo prazo. Quando chegou até a Dra. Ede, Deanna já não tinha mais esperança.
No primeiro dia da consulta, ela listou seus sintomas:
Irritabilidade extrema
Depressão profunda
Falta de energia
Dificuldade de concentração
Desejo de dormir o dia todo
Vontade de se isolar
Articulações doloridas
Ganho de peso incontrolável
Ela foi avaliada em várias escalas psiquiátricas e o diagnóstico foi alarmante. Deanna marcou 11/11 na escala de vício em comida, 19/21 na escala de ansiedade e seu quadro depressivo foi classificado como severo.
Deanna achava que nunca conseguiria seguir uma dieta cetogênica, então a Dra. Ede simplificou ao máximo: "Apenas coma carne, ovos, peixe e frango. Sem contar nada, sem pesar nada."
Os resultados foram chocantes.
Em apenas 12 dias, Deanna entrou em cetose com 2.1 mM de corpos cetônicos e todos os seus sintomas psiquiátricos desapareceram.
Ela passou de um quadro de ansiedade e depressão severas para uma saúde mental completamente normal em menos de duas semanas.
Ela descreveu essa mudança como uma libertação total do seu vício alimentar:
"Depois de apenas uma semana sem carboidratos, minha vida mudou. Minha mente ficou clara, minha ansiedade desapareceu, minha compulsão sumiu. Não acredito que sofri tanto tempo sem saber disso."
Essa história não é um caso isolado. Cada vez mais relatos mostram que a compulsão alimentar não é uma falha moral—é um problema metabólico. E eu também entendo que esses estudos são com poucas pessoas e não muito longos. Mas eu acho bem interessante as coisas acontecendo na prática.
Quando estabelecemos nossos hormônios de fome e saciedade, o cérebro volta a funcionar como deveria. A cetose faz exatamente isso.

4.8 Esclerose Múltipla e a Dieta Carnívora
A esclerose múltipla (EM) é uma doença autoimune onde o sistema imunológico ataca a mielina, a camada protetora dos nervos, causando inflamação, dor, fadiga extrema e perda progressiva de funções motoras e cognitivas.
Atualmente, não existe cura para a EM, e os tratamentos convencionais envolvem medicamentos imunossupressores que apenas retardam a progressão da doença, mas não impedem totalmente o avanço dos sintomas.
Mas e se a chave para controlar a esclerose múltipla estivesse na alimentação?
O Dr. Anthony Chaffee, médico especializado em neurocirurgia expert em nutrição e doenças crônicas, está conduzindo um estudo clínico para analisar os efeitos da dieta carnívora em pacientes com esclerose múltipla. Os primeiros relatos já sugerem que os pacientes estão apresentando melhoras significativas—sem o uso de medicamentos.
E eu tive a oportunidade de ver isso pessoalmente.
Conheci uma mulher chamada Dianne, que está participando desse estudo. Antes de adotar a dieta carnívora, ela estava lutando contra a progressão da esclerose múltipla há anos. Seus médicos lhe disseram que a doença era inevitável e progressiva, e a única solução era o uso contínuo de medicamentos imunossupressores.
Dianne tomava múltiplas medicações, incluindo esteroides e imunomoduladores, para tentar reduzir a inflamação e retardar os danos no sistema nervoso. No entanto, os efeitos colaterais eram severos, e sua qualidade de vida continuava a piorar.
Foi então que ela descobriu a dieta carnívora. Exatamente 1 ano atras.
Ela decidiu testar essa abordagem e, para sua surpresa, os resultados foram quase imediatos. Em poucos dias, sua fadiga extrema começou a diminuir. Dentro de algumas semanas, seus níveis de energia aumentaram significativamente, e ela percebeu que sua clareza mental estava voltando.
Mas o impacto mais surpreendente veio com seus exames médicos.
Após meses na dieta carnívora, Dianne fez uma nova ressonância magnética para avaliar suas lesões cerebrais causadas pela EM. O resultado? Nenhuma nova lesão havia se formado. Mais do que isso, algumas das lesões antigas pareciam ter reduzido. Algo que, segundo seus médicos, não deveria acontecer.
Além disso, ela conseguiu interromper o uso de todas as medicações. O que antes parecia uma sentença de vida inteira com tratamentos agressivos agora se tornou uma condição sob controle, apenas com mudanças na alimentação. Obviamente ela trabalhou junto com o médico dela, e não parou de vez.
Dianne não é a única. O estudo conduzido pelo Dr. Chaffee está acompanhando diversos pacientes que relataram estabilização da doença e, em alguns casos, até mesmo a reversão parcial dos sintomas. Vamos ver os resultados.Eu tive o prazer de conversar com Dianne pessoalmente e estou muito feliz de como ela esta se saindo. é incrivel né gente. Como uma abordagem alimentar pode ter um impacto tão profundo em uma doença autoimune grave como a esclerose múltipla.

4.9 Colesterol: O Medo Que Não Faz Sentido
Claro que você vai ter um amigo que vai falar: “Cuidado com o colesterol!” Talvez até você esteja pensando nisso agora.
Muita gente acredita que comer carne e gordura vai aumentar o colesterol, e que isso automaticamente significa um maior risco de doenças cardíacas. Mas será que isso faz sentido?
O Verdadeiro Processo das Doenças Cardíacas
Sim, é verdade que colesterol LDL é encontrado nas artérias de pessoas com doenças cardíacas. Mas isso não significa que ele seja a causa do problema.
As doenças cardiovasculares ocorrem quando há inflamação e danos na parede das artérias. Quando isso acontece, o corpo tenta reparar essas áreas, e é aí que partículas de LDL podem se acumular no local do dano.
Mas será que o LDL causa esse problema ou ele apenas aparece lá como um “band aid biológico”, tentando consertar um dano pré-existente?
Se colesterol fosse a causa primária das doenças cardíacas, então esperaríamos ver estudos que provam essa relação. Nenhum estudo clínico randomizado jamais conseguiu provar que colesterol LDL causa doenças cardíacas.
O que temos são estudos observacionais, que apenas encontram correlações, e não causalidade.
 E tem mais: se alguns estudos mostram que pessoas com colesterol alto têm mais doenças cardíacas, outros mostram que pessoas com colesterol mais alto vivem mais.
Um estudo que apoia essa ideia é essa pesquisa publicada em 2016:
📌 "Lack of an association or an inverse association between low-density-lipoprotein cholesterol and mortality in the elderly: a systematic review" (Ravnskov et al., 2016).
🔹 Revisou 19 estudos, com 30 coortes e um total de 68.094 idosos.🔹 16 coortes (92% dos indivíduos) mostraram associação inversa entre LDL alto e mortalidade, sendo estatisticamente significativa em 14 delas.
🔹No restante dos estudos, não houve associação entre LDL e mortalidade geral.🔹 Nenhuma evidência clara de que LDL elevado fosse um fator de risco para mortalidade geral em idosos.
Link: Lack of an association or an inverse association between low-density-lipoprotein cholesterol and mortality in the elderly: a systematic review - PubMed
Se o colesterol LDL fosse a causa primária das doenças cardíacas, esperaríamos que ele estivesse consistentemente associado a uma maior mortalidade e com um risco relativo pelo menos maior do que 2. Mas esse estudo mostra justamente o contrário.
E aqui está o ponto crucial: se alguns estudos mostram que LDL alto NÃO está associado a mais mortes, então ele não pode ser a causa direta das doenças cardiovasculares. Causalidade exige consistência—e esses dados quebram a hipótese de que o LDL, por si só, seja o vilão. 
Para responder a pergunta que fizemos mais cedo sobre o band aid biologico, imagine que a doença cardíaca é sua casa pegando fogo. O colesterol é o bombeiro que chega para tentar apagar o fogo, e acaba morrendo junto com a casa. 
E a sociedade está falando que os bombeiros que causaram o fogo.
Na verdade o que realmente pode estar causando esses problemas são a ruim qualidade de vida: alimentação de ultraprocessados e carboidratos refinados (constantemente aumentando a insulina e inflamação),  álcool, cigarro, sono ruim, sedentarismo. entre outros.
Nem Todo LDL é Igual: O Verdadeiro Problema
Enquanto é verdade que o colesterol LDL é encontrado nas placas arteriais, o que ninguém te conta é que existem diferentes tipos de partículas de LDL.
👉 LDL pequeno e denso – Essas partículas são menores, mais compactas e mais propensas a ficarem presas nas artérias. São elas que estão associadas ao risco cardiovascular aumentado.
👉 LDL grande e esponjoso – Essas partículas são inofensivas. Elas circulam no sangue sem se acumular nas artérias e são predominantes em pessoas metabolicamente saudáveis.
E adivinha qual tipo de LDL está sempre presente em pessoas com doenças cardiovasculares? O pequeno e denso.
E aqui está a parte mais importante: esse LDL pequeno e denso é mais comum em pessoas metabolicamente doentes, que consomem dietas ricas em açúcar e ultraprocessados—não em quem come carne e gordura natural.
Ou seja, não é o LDL em si o problema—e sim o estado metabolicamente doente que leva ao aumento do LDL pequeno e denso.O cardiologista Dr Phillip Ovadia sempre indica seus pacientes a pedir um exame detalhado sobre as partículas de colesterol antes de pular para qualquer conclusão.
E vamos finalizar com outro ponto importante, mas Como o Colesterol Seria Ruim?
Pense comigo: se colesterol fosse um veneno, por que o nosso próprio corpo o produziria? E mais:
💡 Todas as nossas células contêm colesterol na membrana celular. Sem ele, elas literalmente não poderiam existir.
💡 Nosso cérebro é composto por cerca de 25% de colesterol do corpo inteiro. Colesterol é essencial para a função cerebral e está envolvido na proteção dos neurônios e na comunicação entre eles.
💡 A produção de hormônios como testosterona, estrogênio e cortisol e também de vitamina D depende do colesterol. Sem ele, você não teria equilíbrio hormonal adequado.
Então, antes de se preocupar com o colesterol da carne, faça a pergunta certa: o problema é mesmo o colesterol ou é a síndrome metabólica causada por uma dieta rica em carboidratos refinados, industrializados e sedentarismo?
Agora que esclarecemos isso, podemos voltar ao que realmente importa: como estruturar uma dieta carnívora para otimizar a saúde.

4.10 Bônus: Como Saber Se Você Tem Síndrome Metabólica?
De acordo com a Dra. Georgia Ede, médica psiquiatra formada em Harvard e especialista em nutrição e metabolismo, a síndrome metabólica é um conjunto de condições que geralmente andam de mãos dadas com a resistência à insulina e a inflamação crônica. Aumento da gordura abdominal, glicose em jejum ligeiramente elevada, pressão arterial alta, triglicerídeos elevados (gordura no sangue) e colesterol HDL baixo. Pessoas com essa condição têm maior probabilidade de ter um perfil de LDL pequeno e denso, que é o verdadeiro fator de risco para doenças cardíacas.
Os critérios mais comuns para o diagnóstico de síndrome metabólica incluem cinco fatores principais. 
O primeiro é a circunferência da cintura, que deve ser menor que 102 cm para homens e 88 cm para mulheres. 
O segundo é a glicose em jejum elevada, sendo considerada preocupante quando está entre 111 e 125 mg/dL, ou se a pessoa já faz uso de medicação para controle do açúcar no sangue. Acima de 125 mg/dL já se considera um quadro de diabetes tipo 2.
O terceiro critério é a pressão arterial elevada. Se a pressão estiver acima de 13 por 8,5,  já pode indicar um problema metabólico, especialmente se a pessoa precisar de medicamentos para controlar a pressão.
 O quarto fator é o nível de triglicerídeos no sangue, que deve estar abaixo de 150 mg/dL. 
O quinto e último critério é o colesterol HDL, também chamado de colesterol "bom". Para homens, ele deve estar acima de 40 mg/dL, e para mulheres, acima de 50 mg/dL.Perceba que o LDL nem entra no cálculo. 
Se uma pessoa apresenta três ou mais desses fatores, ela se enquadra no diagnóstico de síndrome metabólica. Mas mesmo se tiver apenas um ou dois, isso já pode ser um sinal de alerta de que a saúde metabólica não está ideal.
A boa notícia é que a síndrome metabólica pode ser revertida. A Dra. Georgia Ede explica que dietas de baixo carboidrato, como a dieta carnívora, podem melhorar a sensibilidade à insulina, reduzir a inflamação e transformar o perfil lipídico do corpo. 

4.11 Recapitulando

Chegamos ao final deste módulo, onde vimos os diferentes tipos de estudos cientificos.4.1 Entendendo Estudos
🟧 Existem diferentes tipos de estudos científicos, e a maioria dos estudos em nutrição são observacionais, que não provam causa, apenas identificam associações.🟧 Vimos que um risco relativo menor do que 2 não é interessante nesses estudos. E uma das coisas mais importantes: correlação não é causa.
4.2 Como Podemos Ter Causalidade na Nutrição?
🟧 Para provar causalidade, seria necessário um estudo altamente controlado e de longa duração, o que é quase impossível na nutrição.🟧 O que realmente podemos considerar? Evolução, anatomia, fisiologia e estudos de isótopos estáveis, que mostram que sempre fomos consumidores de carne.
4.3 O Primeiro Experimento Documentado
🟧 O jejum tem sido usado há milhares de anos para tratar epilepsia, e, na década de 1920, a ciência descobriu que a cetose poderia imitar seus efeitos.🟧 A dieta cetogênica reduziu drasticamente as crises epilépticas, tornando-se um tratamento eficaz até hoje para casos de epilepsia refratária.
4.4 Transtorno Bipolar, Esquizofrenia e Cetose
🟧 Doenças psiquiátricas como bipolaridade e esquizofrenia podem estar ligadas a falhas no metabolismo energético do cérebro.🟧 Um estudo clínico mostrou que a cetose melhorou sintomas em até 81% dos bipolares e reduziu crises psicóticas em esquizofrênicos.
4.5 Depressão e Cetose
🟧 A depressão está associada à inflamação cerebral e resistência à insulina, dificultando o uso da glicose como energia.🟧 Estudos indicam que a cetose reduz a inflamação no cérebro e estabiliza a atividade neuronal, melhorando os sintomas depressivos.
4.6 Autismo e Cetose
🟧 Crianças autistas apresentam dificuldade em gerar energia a partir da glicose, o que pode afetar o desenvolvimento cerebral.🟧 Um estudo mostrou que a dieta cetogênica trouxe melhora significativa na fala, cognição e interação social.
4.7 Compulsão Alimentar, Vício em Comida e Cetose
🟧 A dieta cetogênica pode ajudar na regulação dos hormônios da fome, reduzindo a compulsão alimentar.🟧 Estudos de caso mostram remissão completa da compulsão e melhora no humor e na clareza mental.
4.8 Esclerose Múltipla e a Dieta Carnívora
🟧 A esclerose múltipla é uma doença autoimune sem cura, mas a dieta carnívora pode estabilizar e até reverter sintomas.🟧 O estudo do Dr. Anthony Chaffee acompanha pacientes que tiveram redução de lesões cerebrais e interrupção da progressão da doença.
4.9 Colesterol: O Medo Que Não Faz Sentido
🟧 Estudos mostram que LDL alto não está associado a maior mortalidade, e, em idosos, está associado a maior longevidade.🟧 O verdadeiro risco cardiovascular está na inflamação e no LDL pequeno e denso, que é agravado pelo consumo de carboidratos refinados.
4.10 Bônus: Como Saber Se Você Tem Síndrome Metabólica?
🟧 A síndrome metabólica inclui cintura abdominal aumentada, glicose elevada, hipertensão, triglicerídeos altos e HDL baixo.🟧 Ela não envolve diretamente o LDL e pode ser revertida com uma dieta de baixo carboidrato, como a carnívora.
Estamos indo super bem ate aqui. Agora que já vimos que antropologicamente, anatomicamente, fisiologicamente e praticamente a dieta carnívora faz sentido, acho que você está pronto para começar.
No próximo capítulo, vamos falar sobre o passo a passo antes de iniciar a dieta carnívora—como se preparar, o que esperar nas primeiras semanas e como garantir a melhor adaptação possível.
