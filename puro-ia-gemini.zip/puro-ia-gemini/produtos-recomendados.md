# Produtos Recomendados (marcas de higiene e beleza)

Protocolo Superhumano | Página 1 

Produtos Recomendados 
Protocolo Superhumano | Página 1 
 
PROTOCOLO SUPERHUMANO 
Produtos Recomendados 
 
Sobre esta lista 
Aqui estão as marcas de produtos de beleza e higiene em que confiamos e que recomendamos, 
categoria por categoria. 
Para entender o que está por trás dessa escolha, o que evitamos e por quê, assista à aula 
gravada sobre a indústria da beleza. 
Como princípio geral, damos preferência a alternativas naturais e de composição simples: óleos 
vegetais, manteigas naturais (karité, cacau), cera de abelha, argila e outros ingredientes com 
histórico de uso e função clara na fórmula, no lugar de derivados sintéticos de petróleo, conservantes 
controversos e fragrâncias artificiais. 
Vale lembrar: não fique refém de marcas, porque elas podem mudar de fórmula. No arquivo da 
Indústria da Beleza temos a tabela dos insumos que é bom evitar, para que você tenha mais 
autonomia de escolher em qualquer lugar que estiver. Menos ingredientes é melhor. Menos químicos 
é melhor. O bom não precisa ser inimigo do ótimo: um shampoo sem petrolato e sem perfume, mas 
que ainda tem um conservante, já é melhor que um que tem tudo isso. Comece com alguma coisa 
e vá mudando aos poucos. Com o tempo, você vai perceber que sua pele e seu cabelo precisam de 
muito menos do que dizem que precisamos. 
Mas você, mulher que gosta de cuidar do cabelo com produtos mais pesados, a gente entende. E 
se você cuidar da alimentação e dos hábitos de vida, você já estará na frente de muita gente que 
usa muito produto, come mal e tem hábitos destrutivos. Tudo pesa n a balança da saúde. Busque 
reduzir de todos os lados: vá diminuindo produtos como desodorante, hidratante e maquiagem, que 
geralmente são usados todos os dias. O pouquinho de todo dia intoxica a longo prazo, somando à 
alimentação ruim, ao sono sem qualidade, a não ver a luz do dia. Tudo isso conta. 

Produtos Recomendados 
Protocolo Superhumano | Página 2 
Protetor Labial 
 
https://balmibiocosmeticos.com.br/produtos/lip-balm-hidratante-labial/ 

https://www.biotie.com.br/hidratante-labial-natural-manteigadecacau-
menta?utm_source=Site&utm_medium=GoogleMerchant&utm_campaign=GoogleMerchant&gad_source=1&gad_camp
aignid=23324709783&gbraid=0AAAAABeuVpHxEL11KIgOavEuZWNih3Fz4&gclid=CjwKCAjwvNfSBhBiEiwAya
GMCWUmD7qxqXHdD3JcdIcAwjDRPWMc8EwDUYmLzEvsEuOoXjIFWHrHsBoCFK0QAvD_BwE 

Produtos Recomendados 
Protocolo Superhumano | Página 3 
 
https://produto.mercadolivre.com.br/MLB-3862707799-manteiga-de-cacau-balm-labial-korui-
_JM?matt_tool=71570980&matt_word=&matt_source=google&matt_campaign_id=22090353998&matt_ad_group_id=
189038011890&matt_match_type=&matt_network=g&matt_device=c&matt_creati ve=799032780397&matt_keyword=
&matt_ad_position=&matt_ad_type=pla&matt_merchant_id=5729120820&matt_product_id=MLB3862707799&matt_
product_partition_id=2468340239267&matt_target_id=aud-2477697932399%3Apla-
2468340239267&cq_src=google_ads&cq_cmp=22090353998&cq_net=g&cq_plt=gp&cq_med=pla&gad_source=1&ga
d_campaignid=22090353998&gbraid=0AAAAAD93qcBoZsX-
CGG0TitlB17L8NNiX&gclid=CjwKCAjwvNfSBhBiEiwAyaGMCeEsqSDvf33yS8fh08ETglNgeozzcwzysmSWtzs6O9
qoUqW57vaouxoC00AQAvD_BwE 

https://www.mercadolivre.com.br/manteiga-labial-hidratante-natural-karite-vegano-sem-
fragrn/p/MLB2079014898?pdp_filters=item_id%3AMLB6545363400&from=gshop&matt_tool=51266944&matt_word
=&matt_source=google&matt_campaign_id=22090354289&matt_ad_group_id=197094 197211&matt_match_type=&m
att_network=g&matt_device=c&matt_creative=792396419413&matt_keyword=&matt_ad_position=&matt_ad_type=pl
a&matt_merchant_id=735128761&matt_product_id=MLB2079014898 -
product&matt_product_partition_id=2469306701001&matt_target_id=aud-2477697932399:pla-
2469306701001&cq_src=google_ads&cq_cmp=22090354289&cq_net=g&cq_plt=gp&cq_med=pla&gad_source=1&ga
d_campaignid=22090354289&gbraid=0AAAAAD93qcB5M6u8L6Nn3qRg01FC876Rh&gclid=CjwKCAjwvNfSBhBiE
iwAyaGMCdB3-A9po4Neh66sTc67dDF7tpSbkS42Ka_LEXx2CWE4khSVRtKFAhoC9uwQAvD_BwE 

Produtos Recomendados 
Protocolo Superhumano | Página 4 
Óleos vegetais, como o óleo de coco e o óleo de rícino, funcionam muito bem como hidratantes e podem ser usados de 
dia ou ao dormir. Usar de dia um produto mais leve para mulheres, por exemplo, e à noite usar um óleo vegetal para 
dormir. 

Shampoo 

ESSA MARCA TEM VÁRIAS OPÇÕES 
 
https://www.biotie.com.br/xampu-nutritivo-alecrim-pracaxi-e-algas-
marinhas?utm_source=Site&utm_medium=GoogleMerchant&utm_campaign=Google
Merchant&gad_source=1&gad_campaignid=23324709783&gbraid=0AAAAABeuVpHx
EL11KIgOavEuZWNih3Fz4&gclid=CjwKCAjwvNfSBhBiEiwAyaGMCf5yiCeVnYKmTGP
jGO-UHjgq-iaJ8KQ-3uMpzAETjySaK9cCqEB3tBoCW10QAvD_BwE 

Produtos Recomendados 
Protocolo Superhumano | Página 5 
 
https://www.mercadolivre.com.br/shampoo-natural-neutro-sem-perfume-250ml--
organific/up/MLBU4234531699?pdp_filters=item_id%3AMLB7118168046&from=gsho
p&matt_tool=71570980&matt_word=&matt_source=google&matt_campaign_id=2209
0353998&matt_ad_group_id=173090501756&matt_match_type=&matt_network=g&m
att_device=c&matt_creative=727882725066&matt_keyword=&matt_ad_position=&ma
tt_ad_type=pla&matt_merchant_id=125899428&matt_product_id=MLBU4234531699&
matt_product_partition_id=2386779786220&matt_target_id=aud-2477697932399:pla-
2386779786220&cq_src=google_ads&cq_cmp=22090353998&cq_net=g&cq_plt=gp&c
q_med=pla&gad_source=1&gad_campaignid=22090353998&gbraid=0AAAAAD93qcB
oZsX-
CGG0TitlB17L8NNiX&gclid=CjwKCAjwvNfSBhBiEiwAyaGMCVazsRcGBzAroTIfbu3z5
7oElb37lPGTDKmcVrbLKfucJaj16Zv9TxoCYuUQAvD_BwE 

Produtos Recomendados 
Protocolo Superhumano | Página 6 

https://www.mercadolivre.com.br/shampoo-neutro-para-personalizar-natural-e-
vegano-500-
ml/p/MLB23658653?pdp_filters=item_id%3AMLB3694251598&from=gshop&matt_tool
=71570980&matt_word=&matt_source=google&matt_campaign_id=22090353998&ma
tt_ad_group_id=173090501756&matt_match_type=&matt_network=g&matt_device=c
&matt_creative=727882725066&matt_keyword=&matt_ad_position=&matt_ad_type=p
la&matt_merchant_id=735098660&matt_product_id=MLB23658653-
product&matt_product_partition_id=2469305797121&matt_target_id=aud-
2477697932399:pla-
2469305797121&cq_src=google_ads&cq_cmp=22090353998&cq_net=g&cq_plt=gp&c
q_med=pla&gad_source=1&gad_campaignid=22090353998&gbraid=0AAAAAD93qcB
oZsX-
CGG0TitlB17L8NNiX&gclid=CjwKCAjwvNfSBhBiEiwAyaGMCWaBh6jJCKGls4yHjwFd
ZCOaqb_Yz0YPWchHkilnLqZMbm2ywl9IIBoCLxIQAvD_BwE 

Produtos Recomendados 
Protocolo Superhumano | Página 7 
Sabonete 
 
https://www.biotie.com.br/sabonetes-naturais-presente 
 
https://www.mercadolivre.com.br/sabonete-com-oleos-vegetais-artesanal-laranja-
doce/p/MLB2069190420?pdp_filters=item_id:MLB1828479786#is_advertising=true&searchVariation=MLB206919042
0&backend_model=search-
backend&be_origin=backend&position=1&search_layout=grid&type=pad&tracking_id=dbedebf1-ecd4-494c-b64b-
a3a059f9ce6f&ad_domain=VQCATCORE_LST&ad_position=1&ad_click_id=M2JiZTQ0MTAtMTQ2Zi00NTA3LWI
4NWQtZDczMDViODM1MTRk 
 
Observação: sabonetes à base de glicerina podem não ser interessantes para 
questões relacionadas à psoríase e dermatite. Então avalie o uso. 
Lembre-se: não fique refém de marcas. Leia o rótulo, veja se você reconhece os 
ingredientes. 

Produtos Recomendados 
Protocolo Superhumano | Página 8 
Desodorante 
 
https://balmibiocosmeticos.com.br/produtos/desodorante-creme-gel/ 
https://www.biotie.com.br/desodorante-natural-
melaleuca?utm_source=Site&utm_medium=GoogleMerchant&utm_campaign=GoogleMerchant&gad_source=1&gad_c
ampaignid=23324709783&gbraid=0AAAAABeuVpHxEL11KIgOavEuZWNih3Fz4&gclid=CjwKCAjwvNfSBhBiEiw
AyaGMCYZ5aqeSArzcNQzcSwM3pN8mx0ytgNZjpjz6rFsKZ_cYAWPdZj2MXBoCIMUQAvD_BwE 

Produtos Recomendados 
Protocolo Superhumano | Página 9 
 
https://truepaleo.com.br/products/desodorante-natural-tallow-e-
coco?variant=43609740705894&country=BR&currency=BRL&utm_medium=product_sync&utm_source=google&utm
_content=sag_organic&utm_campaign=sag_organic&srsltid=AfmBOopLUuAwF1adgnHs5TuNHCVUtpmsVQNCT2V
bE19RSnySu1gbOoSUJVM 
 
 Leite de magnésia funciona como desodorante, basta apenas 
aplicar nas axilas. 

Produtos Recomendados 
Protocolo Superhumano | Página 10 
Pasta de Dente 

Produtos Recomendados 
Protocolo Superhumano | Página 11 
Skincare de Tratamento 
Top 1 é sebo bovino. O sebo bovino (ou tallow) é rico em ácidos graxos e vitaminas A, D, E e K, 
sendo usado na pele como um hidratante natural intenso. Compatível com a barreira cutânea, ele 
ajuda a reter a umidade. Para algumas pessoas pode dar acne, então é preciso avaliar o estado da 
pele atual. Para psoríase e outras questões de pele que precisam regenerar, é excelente. O processo 
de purificação é importante para não dar alergias. 
Na plataforma tem um ebook de como fazer; você pode comprar pronto ou comprar a base e fazer 
o processo, que é só bater na batedeira com um óleo vegetal e um óleo essencial, se quiser. 

https://www.mercadolivre.com.br/tallow-hidratante-70g-artesanal-de-sebo-bovino-
purificado/up/MLBU3481023451?pdp_filters=item_id%3AMLB5786701860&from=gshop&matt_tool=71570980&mat
t_word=&matt_source=google&matt_campaign_id=22090353998&matt_ad_group_id=189038 011850&matt_match_ty
pe=&matt_network=g&matt_device=c&matt_creative=799032780394&matt_keyword=&matt_ad_position=&matt_ad_
type=pla&matt_merchant_id=5773688438&matt_product_id=MLBU3481023451&matt_product_partition_id=2455988
249400&matt_target_id=aud-2477697932399:pla-
2455988249400&cq_src=google_ads&cq_cmp=22090353998&cq_net=g&cq_plt=gp&cq_med=pla&gad_source=1&ga
d_campaignid=22090353998&gbraid=0AAAAAD93qcBoZsX-
CGG0TitlB17L8NNiX&gclid=CjwKCAjwvNfSBhBiEiwAyaGMCanytBCYdvMfZhwa65V6og5hyTAyOly_gIirF4ghsz
rlLh1MjZCnnBoCLrIQAvD_BwE 
 
Tallow pronto já limpo (BASE): 
 https://www.mercadolivre.com.br/sebo-de-rim-bovino-para-
hidratante-500g-frete-
gratis/up/MLBU3193694195?pdp_filters=item_id:MLB4074633261#is_advertising=true&searchVariation=MLBU3193
694195&backend_model=search-
backend&be_origin=backend&position=7&search_layout=grid&type=pad&tracking_id=9a3a6a9c-7c08-44ab-af05-
fae00f0435f5&ad_domain=VQCATCORE_LST&ad_position=7&ad_click_id=OTA2MzViMWUtOTkzYi00N2FiLTk3
ZGItN2JhZTc1OWZhMzIx 

Produtos Recomendados 
Protocolo Superhumano | Página 12 
 
Existem marcas que possuem produtos de skincare mais natural, como hidratantes, argilas e 
limpadores de pele. 
 
biotie.com.br 
 
https://balmibiocosmeticos.com.br/tratamentos-inovadores-faciais/ 
https://www.aludracosmeticos.com.br/ 
 
A Ozon Care é uma marca mais limpa de produtos de pele em geral, com uso de ozônio como 
base. 
https://www.ozoncare.com.br/miniatura-espuma-de-limpeza-harmonizacao-facial-50ml 
 
Abaixo estão descritos os principais achados da literatura médica e científica atual: 
Mecanismos biológicos estudados 
• Via Nrf2: Estudos moleculares apontam que o ozônio ativa a via de transcrição Nrf2, 
responsável por estimular a produção de enzimas antioxidantes endógenas do organismo 
— um mecanismo associado à proteção celular contra estresse oxidativo e envelhecimento 
precoce. 
• Microcirculação: Revisões científicas relatam melhora na microcirculação sanguínea 
cutânea associada ao uso do ozônio, com aumento do aporte de oxigênio e da proliferação 
celular no tecido lesado. 
• Ação antimicrobiana: Ensaios clínicos indicam que óleos vegetais ozonizados atuam 
sobre as membranas de bactérias, fungos e vírus, sugerindo eficácia na redução 
antimicrobiana tópica, com baixo potencial de gerar resistência bacteriana. 
 
Demais produtos ozonizados são muito bons de serem usados, como os óleos vegetais com 
ozônio: óleo de girassol, óleo de oliva. Podem ser usados no rosto, em peles com dermatite, 
manchas na pele... 
 
https://www.mercadolivre.com.br/oleos-de-girassol-ozonizado-oleozon-30ml--2-
unidades/up/MLBU1397157925?pdp_filters=item_id:MLB1037485114#is_advertising=true&searchVariation=MLBU1
397157925&backend_model=search-
backend&be_origin=backend&position=1&search_layout=grid&type=pad&tracking_id=f6ae6848-41a7-4494-b36c-
1168087a5131&ad_domain=VQCATCORE_LST&ad_position=1&ad_click_id=ZDZlM2JjNmMtMDcyOC00MzJlLTk
4N2UtNDEwNTM1ZDE1ZDZk 

Produtos Recomendados 
Protocolo Superhumano | Página 13 
 https://www.mercadolivre.com.br/oleo-de-girassol-ozonizado--melhor-
cicatrizacao-
germicida/up/MLBU1314375132?pdp_filters=item_id:MLB2136534016#is_advertising=true&searchVariation=MLBU
1314375132&backend_model=search-
backend&be_origin=backend&position=13&search_layout=grid&type=pad&tracking_id=5ec0697a-1dce-4d8c-aa94-
59a515a76d3d&ad_domain=VQCATCORE_LST&ad_position=13&ad_click_id=MzI0Y2RiZWUtYzIyMS00ZWU0L
WJkMWUtYmY3NTA5ZjM5YTY4 

Produtos Recomendados 
Protocolo Superhumano | Página 14 
OLEOS VEGETAIS: 
 
Os óleos vegetais podem ser usados na pele, na mucosa da boca, como hidratante e como 
demaquilante. Aqui vão algumas sugestões e formas de usar: 
Óleo de coco: hidratante de corpo, rosto e demaquilante. Pode ser usado para hidratar o cabelo 
antes da lavagem. 
Óleo de rícino: hidratante de pele, corpo e boca. Ótimo para psoríase (pode piorar antes de 
melhorar). Pode ser usado no couro cabeludo e nas sobrancelhas, estimulando o crescimento. 
Óleo vegetal de rosa mosqueta: antioxidante, reparador da derme. Bom para cicatrização, 
eczemas e envelhecimento da pele do rosto. Bom para a área dos olhos. 
Óleo vegetal de semente de uva: use no rosto, corpo e cabelos. Excelente regenerador celular e 
antioxidante. Textura de fácil absorção, muito indicado para peles oleosas. Melhora a elasticidade 
da pele. Estimula o colágeno da pele, prevenindo rugas. Rico em ômega 6, proporciona 
hidratação. Restaura a barreira da pele, diminuindo a perda de água. Previne o envelhecimento 
precoce e a formação de celulites e estrias. Incentiva o crescimento capilar. 
Óleo vegetal de calêndula: possui ácidos graxos, bisabolol e antioxidantes naturais que auxiliam 
na regeneração e reparação da pele, proporcionando ação calmante e suavizante. Além disso, 
ajuda no combate aos radicais livres e na prevenção do envelhecimento precoce. É um excelente 
óleo carreador natural, ideal para quem prefere o uso de óleos vegetais em massagens, hidratação 
corporal e cuidados faciais. 
Óleo vegetal de argan: possui ômega 6, ômega 9, vitamina E, fenóis e esqualeno, que 
contribuem para a elasticidade da pele e reforçam sua barreira de proteção. Além disso, auxilia no 
fortalecimento das unhas frágeis e na restauração dos cabelos quebradiços e sem vida. Também 
atua no combate aos radicais livres, sendo um excelente óleo carreador natural para quem prefere 
o uso de óleos vegetais em massagens, hidratação corporal, cuidados faciais ou capilares. 
Existem muitos óleos vegetais. Cuidado para não confundir com óleo essencial, que é outra coisa. 
Pode variar o uso, a pele gosta disso. 
 
© Protocolo Super Humano™
