# A Indústria da Beleza (lista antitóxica; listas Vermelha, Amarela e Verde)

A Indústria da Beleza
Como a indústria da beleza sequestrou a infância (e a sua pele)
Um material de referência sobre o que está dentro da embalagem, o que isso faz no corpo — e por que a pele bonita começa muito antes do potinho. Inclui as listas Vermelha, Amarela e Verde de ingredientes.

Reprodução, distribuição ou uso não autorizado deste material é expressamente proibido.

Introdução — A Fábrica de Consumidores
Entra numa farmácia. Numa loja de conveniência. No corredor de beleza de qualquer supermercado do Brasil. Rosa, roxo, personagem de desenho animado estampado na embalagem, cheiro de morango, de melancia, de algodão doce. Tudo brilhante, tudo redondinho, tudo comunicando a mesma mensagem silenciosa: “pega isso aqui, é uma delícia, é uma gracinha”.
E funciona. Tão bem que o fenômeno já tem nome no mercado internacional: “Sephora Kids” — crianças e pré-adolescentes formando fila em lojas de cosmético voltadas a público adulto, consumindo produtos de tratamento formulados para peles muito mais maduras que a delas.
US$ 4,7 bilhõesTamanho estimado do mercado de beleza voltado a crianças e adolescentes em 2023, segundo levantamento da consultoria de mercado AYTM.

Meninas de 8 a 12 anos gastando em sérum de retinol e ácido esfoliante — produto formulado para pele de quarenta anos, aplicado em pele de dez. E o mais importante: a criança não escolhe o produto pela função. Ela escolhe o personagem da embalagem. O efeito cosmético vem de brinde.
Honestidade científica: os números de mercado citados neste documento (AYTM, 2023) referem-se a levantamentos setoriais amplamente divulgados pela imprensa especializada em beleza e consumo.
Parte 1 — O Modelo de Negócio Por Trás da Embalagem Bonita
A indústria de beleza infantil não está interessada em vender beleza. Está interessada em vender a ideia de que a criança, ainda pequena, precisa de algum produto para reforçar aquilo que já era natural nela. É assim que se cria um adulto consumista e insatisfeito — alguém que vai comprar cada vez mais, numa busca por algo que nunca esteve faltando, mas que foi ensinado a acreditar que, quanto mais produto, mais a beleza seria realçada.
Modelo de negócio documentado:
Influenciadoras com filhos pequenos lançam marcas próprias de cosmético infantil e faturam milhões já no primeiro mês.
Farmacêuticas grandes estampam protetor labial com personagem licenciado — para o filho pedir igual pediu o brinquedo.
No Brasil, publicidade dirigida à criança já é considerada abusiva pelo Estatuto da Criança e do Adolescente (ECA) e pelo Código de Defesa do Consumidor — só que ninguém precisa “anunciar” quando a própria embalagem já é o anúncio.
E os reguladores já perceberam:
Itália: investigação formal contra marcas globais por usar microinfluenciadoras crianças para promover produto de tratamento adulto a menores de idade. (https://www.bbc.com/news/articles/c3dlk93m7jyo)
Califórnia (EUA): projeto de lei para proibir a venda de cosmético anti-idade — retinol, ácido glicólico — a menores de 18 anos. (https://www.latimes.com/business/story/2025-02-18/antiaging-skincare-ban-kids)
Pesquisadores já cunharam um termo para o que estão observando: “cosmeticorexia” — obsessão precoce com a própria pele, criada artificialmente pelo consumo cosmético. (https://www.bbc.com/portuguese/articles/ckg7137pdeno)
Parte 2 — O Que Sua Pele Realmente Absorve
Sua pele é um órgão vivo — o maior do seu corpo, inclusive. E como todo órgão, ela absorve. Quando você passa um produto na pele, parte relevante daquilo entra na corrente sanguínea — não precisa ser engolido para virar exposição sistêmica. É o mesmo princípio por trás do remédio em adesivo transdérmico: a pele deixa passar.
Três camadas, uma via de entrada
A pele é formada por três camadas, e cada uma tem um papel na história da absorção:
Epiderme — a camada mais externa, onde fica o estrato córneo: células mortas e queratina compactadas que funcionam como a primeira barreira contra perda de água e entrada de microrganismos. É também a principal porta de entrada de moléculas aplicadas topicamente.
Derme — camada intermediária, rica em colágeno, elastina, vasos sanguíneos, terminações nervosas, folículos pilosos e glândulas sebáceas e sudoríparas. É aqui que uma substância absorvida encontra a circulação sanguínea.
Hipoderme — camada mais profunda, de tecido adiposo; funciona como isolante térmico e reserva de energia, e também acumula substâncias lipossolúveis (que se dissolvem em gordura) por longos períodos.
Os folículos pilosos e as glândulas sebáceas funcionam como “atalhos” de absorção — a chamada via transfolicular. É por isso que couro cabeludo, rosto e áreas com mais glândulas sebáceas costumam absorver mais rápido do que uma área de pele mais espessa, como a sola do pé.
Além de barreira e via de absorção, a pele exerce outras funções que a rotina de cosmético raramente considera: termorregulação (controle da temperatura corporal via suor), síntese de vitamina D a partir da luz solar, função sensorial (tato, dor, temperatura) e função imunológica — a pele abriga células de defesa e participa ativamente da resposta inflamatória local.

FONTE: https://blog.bcmed.com.br/camadas-da-pele/
10+ produtosMédia de itens de higiene e beleza usados por um adulto todos os dias — cada um carregando uma dezena ou mais de ingredientes diferentes. Multiplicado pelos anos, isso deixa de ser uma exposição pontual e passa a ser carga química acumulada ao longo da vida.

Na criança, essa conta é ainda mais grave — não porque ela usa mais produto, mas porque a pele dela é mais fina, mais permeável e ainda em formação. É a variável tempo que pesa: começar uma rotina de tratamento (retinol, ácidos) aos 5 anos de idade significa acumular décadas de exposição, todos os dias.
Disruptor endócrino: o inimigo invisível
Disruptor endócrino é uma molécula pequena o suficiente para encaixar no mesmo receptor de um hormônio do corpo — podendo mimetizar, bloquear ou alterar a produção, o transporte e a eliminação de hormônios essenciais ao organismo. Essa disrupção pode gerar efeitos adversos, especialmente no desenvolvimento fetal, no crescimento, no metabolismo e na reprodução [1] [6].
“O corpo não sabe diferenciar a origem. Ele responde ao encaixe da molécula no receptor — não a se ela veio de um creme, de uma garrafa ou de uma fruta.”
Outras portas de entrada
O disruptor endócrino não mora só no potinho de creme. Está no plástico da garrafa (BPA, ftalatos), no resíduo de agrotóxico da fruta, no aditivo do ultraprocessado, até na água da torneira. O cosmético é uma das portas de entrada — e a única que se aplica direto na pele, todos os dias, várias vezes ao dia.
Boa parte desses disruptores nasce de uma mesma origem: petróleo, sintetizado em laboratório para imitar textura, brilho ou conservação. O corpo humano evoluiu por milênios reconhecendo gordura animal, cera e óleo vegetal aplicados topicamente — não evoluiu reconhecendo petroquímico.
Também vem do remédio e do anticoncepcional
O cosmético é apenas uma das fontes de carga hormonal do dia a dia. O anticoncepcional hormonal, por desenho farmacológico, introduz no corpo hormônios sintéticos — como etinilestradiol e progestinas — em dose controlada, com indicação e acompanhamento médico. É uma exposição intencional e regulada, diferente do disruptor ambiental que entra sem que a pessoa perceba. Mas, do ponto de vista da carga hormonal total que o corpo processa todos os dias, as duas exposições se somam.
Além do próprio hormônio do anticoncepcional, muitos medicamentos de uso comum — comprimidos revestidos, cápsulas, adesivos transdérmicos — usam excipientes (a parte “inerte” da fórmula, que carrega o princípio ativo) derivados de petróleo: petrolatos, PEGs, corantes sintéticos semelhantes aos encontrados em cosmético. Eles não aparecem na bula com destaque, porque a atenção regulatória recai sobre o princípio ativo — não sobre o veículo.
“Imagine a mulher que começa a tomar anticoncepcional ainda adolescente. Soma maquiagem todos os dias. Creme hidratante de manhã, protetor solar, base, batom, perfume à noite. Sozinho, cada item parece inofensivo. Somado — e repetido por anos, todos os dias, ao mesmo tempo — é uma carga hormonal e química diária que raramente alguém para para contabilizar como um todo.”
Honestidade científica: isso não é uma recomendação para interromper anticoncepcional ou qualquer medicamento prescrito — essa decisão é sempre médica, individual, e deve pesar riscos e benefícios reais. Mas é importante ser claro: do ponto de vista biológico, existe, sim, um impacto relevante da carga hormonal total — e ignorar isso não faz sentido. Estamos falando do somatório de todas as fontes, intencionais e não intencionais, que o corpo precisa metabolizar.
Por isso, mesmo sem qualquer mudança por conta própria, vale — e muito — conversar com seu médico sobre o tema. Entender alternativas, avaliar necessidade real e, principalmente, reduzir exposições desnecessárias onde for possível, sem comprometer um tratamento que seja necessário. Esse é o caminho mais responsável e inteligente.
Os vilões mais comuns têm nome:
Ingrediente | Onde aparece / preocupação
Parabenos (metilparabeno, propilparabeno...) | Conservante amplamente usado; atividade estrogênica já demonstrada em estudos laboratoriais.
Benzofenona (oxibenzona e derivados) | Filtro químico de protetor solar; associado a interferência hormonal em estudos experimentais.
BHT (Hidroxitolueno Butilado) | Conservante/antioxidante sintético; evidência mista em estudos animais, com debate em curso sobre potencial desregulador endócrino. Menos estudado e menos preocupante que o BHA (ver Parte 3).
Octocrileno | Filtro solar sintético presente na maioria dos protetores convencionais; monitorado por estabilidade e formação de subprodutos.
Ftalatos (DEP, DBP, DEHP) | Plastificantes usados para fixar fragrância e dar flexibilidade a embalagens; frequentemente escondidos atrás da palavra genérica “Fragrance/Parfum” no rótulo. Associados a alterações no desenvolvimento reprodutivo em estudos experimentais.
Liberadores de formaldeído (DMDM Hydantoin, Imidazolidinyl Urea, Quaternium-15, Diazolidinyl Urea) | Conservantes que liberam pequenas quantidades de formaldeído ao longo do tempo; o formaldeído é classificado como carcinógeno humano (Grupo 1) pela IARC, sobretudo por via inalatória, e é alergênico de contato documentado.
Siloxanos (Cyclotetrasiloxane/D4, Cyclopentasiloxane/D5, Cyclohexasiloxane/D6) | Silicones voláteis usados para textura “sedosa”; bioacumulativos no ambiente. O D4 foi classificado pela União Europeia como tóxico para a reprodução e teve seu uso restringido em produtos enxaguáveis.
PFAS — “substâncias eternas” (PTFE e variantes com “fluoro” no nome) | Usadas em maquiagem à prova d’água e alguns fios dentais pelo efeito repelente de água e óleo; não se degradam no ambiente nem no corpo, por isso o apelido “forever chemicals”.
Homosalato e Octinoxato | Filtros solares químicos presentes na maioria dos protetores convencionais; penetram a pele com facilidade e têm atividade hormonal já demonstrada em estudos experimentais.

Honestidade científica: “associado a” e “demonstrado em laboratório” não são sinônimos de causalidade estabelecida em humanos. Boa parte dessas evidências vem de estudos in vitro ou em modelo animal, com dose muito acima da exposição cosmética típica. Reconhecer o padrão e reduzir exposição desnecessária, aplicando o princípio da precaução, é o objetivo aqui. Na parte 5 você entenderá mais.
PFAS: o exemplo mais estudado hoje
Entre todos os itens da tabela acima, o PFAS é o que acumulou o corpo de evidência mais robusto nos últimos anos — e por isso merece um destaque à parte. Um monograma do National Toxicology Program dos EUA concluiu que dois PFAS (PFOA e PFOS) devem ser considerados um risco à imunidade humana, com nível de evidência alto em estudos animais e moderado em estudos humanos [2]. Um estudo prospectivo com mulheres nos EUA encontrou associação entre concentração plasmática de PFAS e maior risco de diabetes tipo 2 [4]. Outro estudo, com adolescentes e adultos jovens acompanhados ao longo do tempo, encontrou associação entre exposição a PFAS e mudanças na densidade mineral óssea [3].
Em novembro de 2023, a IARC (agência de pesquisa em câncer da OMS) reclassificou o PFOA como “carcinogênico para humanos” (Grupo 1), com evidência limitada em humanos para câncer renal e câncer de testículo, e evidência mecanística forte, incluindo alterações epigenéticas e efeitos sobre o sistema imunológico. O PFOS foi classificado como “possivelmente carcinogênico” (Grupo 2B) [5]. PFAS também está entre os grupos químicos mais estudados quanto a efeitos sobre o fígado — alteração de enzimas hepáticas é um dos achados mais consistentes em populações expostas.
Honestidade científica: a classificação da IARC mede força de evidência de que uma substância pode causar câncer (perigo/hazard), não o tamanho do risco individual em uma pessoa com exposição cosmética cotidiana — que costuma ser muito menor do que a de populações estudadas por contaminação ambiental ou ocupacional próxima a fábricas. Ainda assim, a reclassificação de 2023 é um marco: reforça por que reduzir exposição desnecessária, quando possível, faz sentido mesmo sem alarmismo.
Ele não sai do corpo em poucos dias
Por muito tempo, a ciência acreditou que esses compostos eram eliminados em poucos dias — que bastava parar de usar hoje para que amanhã já tivesse saído. Pesquisas mais recentes mudaram essa conta: parte deles se acumula no organismo, inclusive no tecido cerebral.
E atravessa a placenta
Durante muito tempo, a placenta foi tratada como uma barreira quase perfeita, capaz de proteger o bebê de qualquer substância nociva que circulasse no sangue da mãe. Essa ideia não se sustenta mais. BPA, ftalatos e resíduos de agrotóxico já foram encontrados em líquido amniótico — ou seja, a exposição pode começar antes do parto, dentro do próprio útero.
O levantamento mais citado sobre o tema é o da Environmental Working Group (EWG), publicado em 2005: pesquisadores testaram o sangue do cordão umbilical de 10 recém-nascidos americanos, coletado no momento do parto, e encontraram 287 substâncias químicas industriais diferentes no grupo — uma média de 200 por bebê, entre elas praguicida, retardante de chama, mercúrio e subproduto industrial que, em teoria, nunca deveria ter chegado ali [7].
O que isso faz na tireoide
Um disruptor pode bloquear o receptor do hormônio tireoidiano, reduzir o T4 circulante e atrapalhar a conversão de T4 em T3 — a forma ativa do hormônio, a que de fato comanda o metabolismo. O triclosan, o mesmo ingrediente usado em sabonetes “antibacterianos”, é um exemplo prático desse mecanismo: um estudo com 439 gestantes em Boston encontrou associação entre a concentração urinária de triclosan e TSH mais alto nas mães — sinal de que a tireoide estava sendo forçada a trabalhar mais para compensar [8]. Cansaço, ganho de peso sem explicação aparente e queda de cabelo costumam ser investigados apenas pela alimentação — o rótulo do cosmético raramente entra na lista de suspeitos.
Parte 3 — Seis Produtos, Um Padrão
A seguir, os seis produtos mais comuns na rotina de higiene e beleza — do bebê ao adulto — com os ingredientes que mais aparecem nas fórmulas convencionais e o motivo específico de cada preocupação. A ideia aqui é entender o padrão que se repete em quase todas as embalagens do corredor de beleza, sem pânico e sem lista de nomes difíceis para decorar. A lista completa, para consulta, está no final do material.
1. Protetor Labial
O mais “inofensivo” de todos, na percepção do consumidor. Sabor de fruta, personagem licenciado, formato de bala. A criança usa oito, dez vezes por dia — porque lambe o próprio lábio, porque gosta do gosto, porque virou ritual.
Ingrediente | Por que preocupa
Petrolatum (derivado de petróleo) | Não é inerte como o marketing sugere: forma uma película oclusiva que pode entupir poro e represar sujeira e bactéria na pele da região, além de ser ingerido cronicamente no lábio. Preocupação real da EFSA com MOAH (contaminantes de refino com potencial genotóxico) — o rótulo não revela o grau de refino, então não dá para saber o quanto de contaminante vem junto.
Parfum, Limonene, Linalool | Fragrância e seus componentes; alergênicos de contato mais documentados em cosméticos. Quando oxidados, são causa conhecida de dermatite alérgica — e a criança tem pele mais fina e barreira menos madura.
CI 19140 (Tartrazina) | Corante puramente estético, sem função de cuidado. Histórico de reações de hipersensibilidade; na União Europeia, alimentos com esse corante carregam advertência obrigatória sobre efeitos na atenção de crianças.
Sucralose, Sacarina, Aroma doce | Não é inofensivo só porque tem “zero caloria”: o sabor doce ativa a mesma resposta de recompensa e sinalização de insulina que o açúcar de verdade, treinando o paladar da criança a associar cuidado pessoal a gosto doce desde cedo — o mesmo padrão que depois puxa para o ultraprocessado. Na prática, é o que faz a criança lamber e reaplicar o produto oito, dez vezes por dia, aumentando a exposição a todos os outros ingredientes da fórmula.
Lanolina | Alergênico de contato conhecido; lotes mal purificados já registraram resíduo de agrotóxico. O grau farmacêutico moderno é mais limpo, mas nem sempre é o usado.
BHA (Hidroxianisol Butilado) | Conservante antioxidante; classificado pelo National Toxicology Program (EUA) como “razoavelmente antecipado” como carcinógeno humano, com base em estudos animais. Em lábio, é ingerido de forma repetida ao longo do dia.
Óleo mineral / Mineral Oil (grau cosmético não refinado) | Derivado de petróleo usado como emoliente; quando não passa por refino completo, pode carregar hidrocarbonetos aromáticos (MOAH), a mesma classe de contaminante que preocupa a EFSA no petrolato.

Alternativa de verdade: manteiga de cacau, manteiga de karité, cera de abelha, óleo de coco ou sebo bovino (beef tallow).
2. Shampoo
Ingrediente | Por que preocupa
Sodium Laureth Sulfate (SLES) | Tensoativo irritante e etoxilado; pode carregar resíduo de 1,4-dioxano (provável carcinógeno) que não aparece no rótulo, por ser contaminante de processo e não ingrediente adicionado.
Dióxido de titânio | Já banido como aditivo alimentar: a União Europeia proibiu seu uso em alimentos (E171) em 2022, porque a EFSA não conseguiu descartar genotoxicidade das nanopartículas quando ingeridas.
Parfum + Hexyl Cinnamal + Limonene + Linalool | Pacote de fragrância — causa nº1 de dermatite de contato em cosméticos. Os componentes aparecem separados no rótulo porque a lei europeia obriga a declaração quando o alergênico ultrapassa o limite.
Cocamidopropyl Betaine | Apesar do nome “de coco”, é alergênico de contato bem documentado — eleito “alérgeno do ano” pela sociedade americana de dermatite de contato. O problema são impurezas do processo de síntese, não o coco em si.
PEG-80 / PEG-150 | Derivados de petróleo; podem vir contaminados com 1,4-dioxano, resíduo de fabricação classificado como provável carcinógeno. Por ser contaminante, não precisa aparecer no rótulo.
Methylisothiazolinone (MIT) / Methylchloroisothiazolinone (CMIT) | Conservantes de amplo espectro; a dermatologia elegeu a MIT “alérgeno do ano” em anos recentes por seu papel numa verdadeira epidemia de dermatite de contato ligada a produtos de enxágue rápido, como shampoo.
Dimethicone e outros silicones de cadeia longa | Criam a sensação de “cabelo liso e sedoso” revestindo o fio, mas acumulam-se com o uso repetido e podem exigir xampus “clarificantes” mais agressivos para remover — outro elo do ciclo produto-que-cria-o-próprio-problema.

Alternativa de verdade: tensoativo suave à base de coco, sem sulfato — combinado a menor frequência de lavagem.
3. Sabonete
Durante anos foi vendido como sinônimo de “mais limpo, mais seguro” pela promessa “antibacteriano”. Em 2016, o próprio órgão regulador americano (FDA) retirou o triclosan do sabonete de venda livre nos Estados Unidos.
Ingrediente | Por que preocupa
CI 15985 / CI 19140 (Amarelo 6 e Amarelo 5) | Corantes sintéticos usados só para deixar o produto com cor “bonitinha” — sem função na limpeza. Derivados de petróleo; historicamente, corantes azoicos dessa família já registraram contaminação por benzidina (carcinógeno) no processo de fabricação. Estão entre os corantes associados a hiperatividade em crianças no estudo de Southampton, que gerou alertas obrigatórios na União Europeia.
Propylene Glycol | Solvente e umectante; alergênico de contato documentado em minoria significativa de pessoas (top 10 de alérgenos em patch test dermatológico). Também atua como penetration enhancer, ajudando outros ingredientes a penetrar mais na pele.
Parfum | Causa número 1 de dermatite de contato em cosméticos.
Titanium Dioxide | A IARC classifica o dióxido de titânio como possível carcinógeno por via inalatória — o alerta real é específico para inalação (pó, spray), não para uso tópico enxaguado.
Triclosan / Triclocarban | Antibacterianos sintéticos; a FDA retirou o triclosan de sabonetes de venda livre nos EUA em 2016. Interfere na regulação do hormônio da tireoide e dos hormônios sexuais (ver Parte 2).
Sodium Lauryl Sulfate (SLS) | Tensoativo espumante forte; remove também os lipídios naturais da barreira cutânea, e é um dos irritantes mais usados em teste de irritação dermatológica justamente por sua agressividade.

Alternativa de verdade: sabonete de barra à base de óleo vegetal saponificado (castela, coco) ou syndet suave sem sulfato.
4. Desodorante
O mecanismo mais direto de todos. O antitranspirante convencional usa sais de alumínio para literalmente entupir o poro e bloquear a saída do suor. Não regula — impede. E suar é o corpo trabalhando: uma via de eliminação, não um defeito.
Ingrediente | Por que preocupa
Aluminum Sesquichlorohydrate | Ingrediente ativo antitranspirante; forma um “plug” temporário no duto da glândula sudorípara para bloquear o suor. É o centro do debate mais antigo da categoria — a hipótese de ligação entre sais de alumínio e câncer de mama nunca foi confirmada em estudos populacionais robustos, mas o próprio mecanismo de bloqueio de uma via natural de eliminação é o argumento central de quem prefere desodorantes sem alumínio.
Cyclopentasiloxane | Silicone volátil usado para dar sensação “seca” e escorregadia no spray; é bioacumulativo no ambiente — por isso a União Europeia já restringiu sua concentração em produtos enxaguáveis e, até 2027, também nos que ficam na pele.
Benzyl Salicylate, Eugenol, Limonene, Linalool, Geraniol | Frações do “Parfum” que a legislação europeia obriga a declarar separadamente, por serem os alergênicos de contato mais documentados entre compostos aromáticos — prova de que “Parfum” nunca foi de fato um segredo protegido, e sim uma lacuna regulatória.
Parabenos | Conservante com atividade estrogênica já demonstrada em laboratório (ver Parte 2).
Propylene Glycol | Solvente/umectante; alergênico de contato documentado (top 10 em patch test), também usado como penetration enhancer — facilita a entrada de outros ingredientes da fórmula pela pele da axila, uma área fina e sujeita a microlesões da depilação.
Talco (Talc) | Usado em desodorantes em pó/stick para sensação seca; quando extraído sem controle rigoroso de pureza, pode vir contaminado com fibras de asbesto — motivo de ações judiciais e maior escrutínio regulatório. Em 2024, a IARC classificou o talco como “provavelmente carcinogênico” (Grupo 2A).

Alternativa de verdade: bicarbonato de sódio ou argila — e atacar o odor pela raiz, através da alimentação.
5. Pasta de Dente
A cárie não tem um único fator causal — tem muitos. Fora o flúor, a maioria das pastas convencionais também contém petrolatos, adoçantes sintéticos, corantes e abrasivos.
* Assista à aula sobre flúor na plataforma — lá vai a fundo no mecanismo e você vai entender melhor o mal que ele pode fazer.
Ingrediente | Por que preocupa
Fluoreto de Sódio (concentrações usuais de 0,32% / 1450 ppm) | Em dose alta é tecnicamente uma toxina — por isso a bula de qualquer pasta nessa concentração traz aviso de “não engolir” e contato com centro de intoxicação em caso de ingestão acidental acima do uso normal. Estudos de neurodesenvolvimento (como o NTP monograph nos EUA e a metanálise de Green et al., 2019) associam exposição pré-natal a alto teor de flúor com QI mais baixo em crianças — mas essas pesquisas avaliam principalmente água fluoretada ingerida sistemicamente, não o uso tópico e cuspido de pasta de dente. Ainda assim, a saliva é uma mucosa e absorve. Também há relação com a tireoide: o flúor é um halogênio, da mesma família química do iodo, e compete pelo mesmo receptor — na Europa, chegou a ser usado propositalmente em dose terapêutica para reduzir a função da tireoide em quadros de hipertireoidismo, décadas atrás.
Laurilsulfato de Sódio (SLS) | Tensoativo espumante, o mesmo ingrediente debatido em shampoos; pode irritar a mucosa oral e está associado ao aumento de aftas (úlceras bucais recorrentes) em pessoas predispostas, com literatura odontológica específica sobre o tema.
Sacarina Sódica | Adoçante sintético que recebeu alerta de possível carcinógeno nos anos 1970 (estudos em ratos); foi posteriormente removido da lista de suspeitos pela IARC, ao se entender que o mecanismo era específico da fisiologia da bexiga de rato e não se replica em humanos. Hoje é considerado seguro pelos órgãos regulatórios, mas segue entre os aditivos mais citados por quem prefere evitar sintéticos por princípio.
Eugenol | Mesmo alergênico de contato presente em desodorantes; aqui em concentração de aromatizante, sob mucosa oral — ainda mais permeável que a pele.
Sílica hidratada / abrasivos sintéticos em excesso | Função de polimento é necessária, mas em concentração alta ou partícula muito grosseira pode desgastar o esmalte dentário ao longo dos anos — o efeito é cumulativo e pouco perceptível no curto prazo.
Corantes sintéticos (CI diversos) e Parfum | Mesma lógica dos demais produtos: função puramente estética, sem contribuição para a limpeza, somando mais um alergênico de contato à mucosa oral.

Alternativa de verdade: pasta com hidroxiapatita, argila ou bicarbonato, sem SLS e sem corante, associada a uma alimentação que reduza açúcar e ultraprocessado.
6. Skincare de Tratamento
O produto mais irônico de todos: promete corrigir o problema que a própria rotina de cosmético ajudou a criar.
O ciclo dentro do próprio rótulo:
Peróxido de benzoíla, ácido salicílico forte e retinoide de venda livre ressecam a pele à força.
A pele, ressecada, reage produzindo ainda mais oleosidade para se defender — e “precisa” de mais produto para tratar a oleosidade que o próprio tratamento causou.
Hidroquinona sem supervisão, usada por tempo prolongado, já tem registro do efeito oposto: escurecimento paradoxal (ocronose).
Protetor solar químico é vendido como “correção” para o ressecamento e as manchas — mas alguns filtros (oxibenzona, avobenzona) são penetration enhancers e fotossensibilizantes documentados: a “solução” para o dano solar pode reintroduzir o mesmo tipo de estresse na barreira que se tenta reparar.
Sérum “calmante” chega com nova fragrância, novos conservantes, nova química — para acalmar a pele irritada pelos passos anteriores, somando mais um risco de sensibilização de contato a todos os outros.
Ingredientes desse grupo que merecem atenção redobrada:
Ingrediente | Por que preocupa
Hidroquinona (sem prescrição/supervisão) | Clareador potente; uso prolongado e sem supervisão já tem registro de efeito paradoxal — escurecimento da pele (ocronose exógena). Em muitos países só é vendida com prescrição justamente por esse risco.
Oxibenzona e Avobenzona | Filtros solares químicos com penetração cutânea documentada e efeito fotossensibilizante — podem reintroduzir o mesmo tipo de estresse na barreira que o “tratamento” tenta reparar.
Ácido retinoico de venda livre em alta concentração | Acelera renovação celular, mas em concentração alta e sem adaptação gradual resseca e sensibiliza a barreira, criando o efeito rebote de oleosidade descrito acima.
Álcool desnaturado (Alcohol Denat.) em alta concentração | Comum em produtos “matificantes” e géis de tratamento; resseca a barreira lipídica rapidamente, o que intensifica o ciclo de oleosidade reativa.

A pele não estava com problema. Ela estava reagindo, exatamente como deveria, a uma sequência de agressões químicas que a indústria batizou de “rotina completa”.
Parte 4 — O Ciclo Que Se Fecha Sozinho
Repare no padrão que se repete nos seis produtos anteriores: o item vendido para resolver o problema é, com frequência, o mesmo item que cria as condições para o problema aparecer de novo.
Cada produto existe para corrigir o efeito colateral do produto anterior. É uma cadeia de causa e consequência vendida em etapas separadas, cada uma com preço próprio, cada uma “descobrindo” um problema novo que a etapa anterior criou — bem diferente de uma rotina de cuidado de verdade.
Sabonete resseca → você compra hidratante.
Shampoo resseca o couro cabeludo → você compra condicionador e depois ampola.
Creme de acne resseca → a pele reage com mais oleosidade → você compra mais creme.
Parte 5 — O Sistema de Desintoxicação do Corpo: Por Que Ele Não Dá Conta
O corpo tem seu próprio sistema de limpeza, funcionando todos os dias, sem que a gente precise fazer nada de especial para isso acontecer. Cinco órgãos dividem esse trabalho: fígado, rins, pulmões, intestino e pele. Eles não trabalham mal — o problema é quando a quantidade de toxina que entra é maior do que a capacidade que eles têm de limpar. Aí a toxina fica no organismo, e se instala um quadro de sobrecarga.
Os cinco órgãos que fazem esse trabalho todos os dias
Órgão | O que ele faz
Fígado | Filtra o sangue, neutraliza toxinas e medicamentos, metaboliza gordura, carboidrato e proteína, produz bile e armazena vitaminas lipossolúveis. É o órgão mais multitarefa da lista.
Rins | Filtram o sangue, equilibram água e eletrólitos, e eliminam pela urina os produtos do metabolismo antes que atinjam níveis tóxicos.
Pulmões | Trocam gás carbônico por oxigênio a cada respiração — uma via de eliminação contínua, que também depende de ar limpo para funcionar bem.
Intestino (cólon) | Armazena e elimina resíduos, absorve água e vitaminas, e é onde vive grande parte da microbiota que participa da neutralização de toxinas.
Pele | O maior órgão do corpo; elimina substâncias pelo suor, além de proteger, regular temperatura e participar da imunidade (ver Parte 2).

O fígado: o mais sobrecarregado de todos
Entre os cinco, o fígado carrega a maior parte do trabalho pesado. Ele recebe o sangue vindo do intestino — cheio de nutrientes, mas também de medicamentos e, eventualmente, de toxinas absorvidas — e decide o que segue para o corpo e o que precisa ser neutralizado. Estima-se que o fígado processe algo em torno de 100 litros de sangue por hora.
E o fígado tem outro papel que conecta diretamente com o que já vimos neste material: é ele quem realiza boa parte da conversão do hormônio T4 em T3 — a forma ativa da tireoide, que comanda o metabolismo (ver Parte 2). Um fígado sobrecarregado, ocupado demais neutralizando aditivo de cosmético, resíduo de medicamento e subproduto de ultraprocessado, tem menos capacidade de sobra para essa conversão hormonal. Ou seja: a saúde da tireoide depende, em parte, de quanto trabalho extra o fígado está carregando.
Honestidade científica: a função de conversão hepática de T4 em T3 é fisiologia estabelecida. Já a ideia de que a sobrecarga tóxica cotidiana (cosmético, poluição, alimentação) compromete essa conversão de forma clinicamente relevante em pessoas saudáveis é uma hipótese de medicina funcional, coerente com o mecanismo, mas ainda sem quantificação robusta em estudos populacionais — vale apresentá-la como raciocínio lógico, não como fato estabelecido.
O sistema Pischinger: a “piscina” onde a célula vive
Um conceito da medicina funcional ajuda a visualizar por que a sobrecarga desses órgãos importa tanto: o sistema básico descrito pelo médico austríaco Alfred Pischinger, na década de 1970. Pischinger descreveu o líquido extracelular — o líquido que banha cada célula do corpo — como o verdadeiro palco da vida celular: é ali que acontece a troca de água, oxigênio e eletrólitos, a regulação ácido-básica, e é dali que os resíduos do metabolismo são retirados rumo aos órgãos de limpeza.
“A célula está ‘nadando’ numa piscina de líquido que deveria ser limpo e alcalino — recebendo nutriente e oxigênio, devolvendo resíduo. Quando os órgãos de limpeza saturam, essa piscina começa a se encher de resíduo ácido, e a própria água que sustenta a célula se torna hostil.”
Diante de uma piscina saturada, sem nutriente e sem oxigênio suficiente, a célula tem poucas saídas: entrar em apoptose (morte celular programada); “roubar” cálcio do osso para neutralizar a acidez, o que ao longo dos anos contribui para perda de densidade óssea — efeito já documentado, por exemplo, em estudos associando PFAS a mudanças na densidade mineral óssea [3] —; reter líquido para diluir o excesso de ácido, gerando edema; ou se adaptar para sobreviver naquele ambiente pobre em oxigênio e ácido demais — a qualquer custo.
Honestidade científica: o sistema de Pischinger é um modelo conceitual usado em medicina biológica e funcional para explicar a relação entre matriz extracelular, órgãos de eliminação e sintomas inespecíficos. É útil como estrutura didática para entender por que “desintoxicar” importa — mas não é um exame clínico validado, e a leitura de que a célula “se adapta” a um ambiente ácido e pobre em oxigênio para sobreviver dialoga conceitualmente com hipóteses metabólicas sobre a origem do câncer (efeito Warburg, discutido em outro módulo do Protocolo Superhumano).
Do fígado sobrecarregado ao cérebro
O que o corpo não consegue neutralizar e eliminar, ele guarda. Já vimos na Parte 2 que boa parte dos disruptores endócrinos se acumula no organismo por muito mais tempo do que se pensava — inclusive no tecido cerebral. O estudo de referência sobre isso é da Environmental Working Group (EWG), publicado em 2005: pesquisadores testaram sangue de cordão umbilical de 10 recém-nascidos americanos e encontraram, em média, 200 substâncias químicas industriais por bebê — 287 substâncias diferentes ao todo no grupo [7].
217 de 287 substânciasDo total de substâncias químicas encontradas no sangue de cordão umbilical pelo estudo da EWG (2005), 217 são tóxicas ao cérebro e ao sistema nervoso; 180 causam câncer em humanos ou animais; 208 causam defeitos de nascimento ou alterações no desenvolvimento em testes com animais.

Ou seja: a exposição não começa na infância, nem na vida adulta. Ela começa no útero, atravessa a placenta e chega ao bebê antes do primeiro banho — e o próprio estudo aponta que o sistema de desintoxicação do recém-nascido ainda está imaturo, o que o torna proporcionalmente mais vulnerável do que um adulto ao mesmo tipo de exposição.
O ciclo inteiro entra na conta, não só o produto
O ideal seria que nosso corpo tivesse capacidade de desintoxicar por décadas, sem grandes problemas — e ele até tem esse potencial. Mas quando a intoxicação é constante, dia após dia, ano após ano, a capacidade de resposta vai naturalmente caindo. E essa equação não depende só do que passamos na pele: o ciclo inteiro de vida entra na conta.
Ritmo circadiano desregulado e sono ruim reduzem a janela em que o corpo prioriza reparo e limpeza celular (ver Parte 6 adiante).
Alimentação pobre em nutrientes e rica em ultraprocessado sobrecarrega o fígado com mais trabalho metabólico, sobrando menos capacidade para neutralizar toxina.
Estresse crônico mantém o corpo em estado de alerta, priorizando resposta imediata em vez de reparo e desintoxicação.
Sedentarismo reduz a circulação sanguínea e linfática, dificultando o transporte de resíduo até os órgãos de limpeza.
O próprio ambiente também mudou, além do estilo de vida. A poluição industrial, os resíduos de agrotóxico na lavoura, os plásticos do dia a dia — tudo isso aumenta a quantidade de toxina que entra pela respiração, pela alimentação e pela pele, ao mesmo tempo. As variáveis de hoje são muito maiores do que as de uma geração atrás — o que torna o cuidado com o que se come e o que se passa na pele ainda mais relevante.
Quando você se preocupa com o que come e com o que passa na pele, seu corpo tem uma folga a mais para fazer o trabalho que ele já sabe fazer: limpar, reparar e regular.
Parte 6 — A Saída Que a Indústria Não Vende
Se o corpo já tem um sistema de limpeza — fígado, rins, pulmões, intestino e pele —, a pergunta certa é “como eu dou folga para esse sistema funcionar”, e não “que produto novo eu compro”. Pele bonita começa por dentro. Insulina cronicamente alta, inflamação por ultraprocessado e açúcar em excesso aparecem primeiro na pele — porque ela é o espelho mais rápido do metabolismo.
Quatro alavancas que resolvem pela raiz:
Alavanca | Por que funciona
1. Alimentação | Menos ultraprocessado e menos açúcar reduzem a inflamação que gera oleosidade e acne pela raiz. A pele é o maior órgão do corpo — e também o mais visível: quando o intestino está inflamado e a insulina está nas alturas, a pele avisa antes de qualquer exame de sangue.
2. Sol da manhã | Dez a quinze minutos de luz solar direta nos olhos logo ao acordar ajustam o relógio biológico — e é esse relógio que comanda o ciclo de reparo celular, inclusive da pele, durante a noite. Sem esse sinal, o corpo não sabe direito quando é hora de descansar e reconstruir; o sérum mais caro do mundo não substitui esse comando.
3. Movimento | Trinta minutos por dia melhoram a circulação e reduzem o excesso de cortisol — que, em excesso, gera inflamação. A dose certa é a que se sustenta ao longo do tempo, sem exagero.
4. Sono | É durante o sono que o corpo de fato se repara — nenhum sérum substitui isso. É à noite que a pele realiza o trabalho pesado de reconstrução celular.

Quando você resolve pela raiz, a lista de produtos que você “precisa” usar todo dia despenca.
“Pele bonita, cabelo forte, suor sem cheiro forte, dente saudável — isso tudo é, na maior parte, reflexo do que acontece por dentro. Não do que se passa por fora.”
E é isso que a indústria nunca vai contar, porque não vira produto para vender em potinho: você não precisa de doze produtos. Você precisa parar de alimentar o problema que os doze produtos prometem esconder.

Parte 7 — Ingrediente Por Ingrediente: Entendendo as Listas
No final deste material estão três listas: Vermelha, Amarela e Verde. São mais de 40 grupos de ingredientes, cada um com o nome exato que aparece no rótulo. Parece muito, mas eles se repetem em poucos mecanismos. Esta parte explica esses mecanismos por família. Entendendo a família, você reconhece o ingrediente mesmo quando ele aparece com um nome que não está em lista nenhuma.
Os disruptores endócrinos mais estudados (PFAS, ftalatos, parabenos, triclosan, siloxanos) já foram explicados na Parte 2. Aqui entram as famílias que ainda não tinham sido detalhadas.
Como as cores foram definidas
Cor | O que significa | Critério
Vermelha | Evitar sempre | Já proibido ou restringido em algum lugar, classificado como carcinógeno, disruptor endócrino com evidência consistente, bioacumulativo, ou que esconde outros químicos no rótulo
Amarela | Atenção | Irritante ou alergênico conhecido, risco de contaminação conforme o refino, ou evidência mais fraca. Evitar no uso diário, em criança e na gestação; tolerável de forma pontual
Verde | Pode usar | Baixo risco documentado. São as alternativas de verdade

Como ler o rótulo
A lista de ingredientes segue um padrão internacional chamado INCI e vem quase sempre em inglês ou latim, em ordem decrescente de quantidade. Os primeiros nomes são a maior parte do produto; os últimos, geralmente, estão abaixo de 1%. Por isso as listas trazem o nome exato da embalagem, e não o nome em português.
Três atalhos que pegam a maioria dos vilões:
Terminou em -paraben, começou com PEG- ou tem -eth no meio (laureth, ceteareth, steareth): atenção.
Tem fluoro ou perfluoro no nome: é PFAS, lista vermelha.
CI seguido de 5 números começando com 1 a 7 (ex.: CI 19140, CI 15985) é corante sintético. CI 77xxx (ex.: CI 77491) é pigmento mineral, de menor risco.
Família 1 — Formol e alisantes
O formol (formaldeído) é classificado pela IARC como carcinógeno humano, Grupo 1, a categoria de evidência mais forte. O maior risco vem da inalação: ele é volátil, e o vapor sobe justamente quando o produto é aquecido. Por isso o lugar onde ele mais preocupa no Brasil é a escova progressiva. A chapinha quente faz o formol evaporar perto do nariz de quem recebe e de quem aplica.
A Anvisa só permite o formol em quantidade pequena, como conservante e em endurecedor de unha. Usar como alisante é proibido. Mesmo assim, ele continua aparecendo em salão, em produto sem registro ou adicionado na hora.
Existe ainda um segundo caminho, mais discreto: os liberadores de formol. São conservantes que soltam pequenas quantidades de formol ao longo do tempo, dentro do frasco e na pele. No rótulo não aparece a palavra formol. Aparece DMDM Hydantoin, Imidazolidinyl Urea, Diazolidinyl Urea, Quaternium-15, Bronopol, Sodium Hydroxymethylglycinate ou Methenamine. Estão em shampoo, sabonete líquido e até em produto infantil.
E a progressiva “sem formol”?
Com a proibição, a indústria trocou o formol por outros ativos, principalmente o ácido glioxílico e seus derivados (Glyoxylic Acid, Glyoxyloyl Carbocysteine, Glyoxyloyl Keratin Amino Acids). Em 2024, o New England Journal of Medicine publicou o caso de uma mulher de 26 anos com lesão renal aguda após progressivas com ácido glioxílico. Uma série de casos de Israel descreveu cerca de 26 pacientes com o mesmo quadro, três deles precisando de diálise temporária. O mecanismo proposto: o ativo atravessa o couro cabeludo (que absorve rápido, como vimos na Parte 2), é metabolizado em oxalato e forma cristais no rim. Com o calor da chapinha, esses ativos também podem liberar formol.
Honestidade científica: são relatos de casos, não um estudo que mede quantas pessoas são afetadas entre todas que fazem progressiva. O risco individual parece baixo, mas o desfecho é grave e envolve um órgão de desintoxicação. Por isso o grupo entrou na lista vermelha.
Família 2 — Metais pesados e clareadores
Metal pesado não deveria estar em cosmético nenhum, e no mercado regular em geral não está. O problema aparece em produtos irregulares, que circulam muito pela internet:
Mercúrio em creme clareador importado ou manipulado sem procedência. É neurotóxico e tóxico para o rim, e se acumula. No rótulo pode aparecer como Mercury, Calomel, Mercurous Chloride ou simplesmente não aparecer.
Chumbo em tintura progressiva para cabelo grisalho (Lead Acetate) e em kajal, kohl ou surma tradicional importado. Chumbo não tem dose considerada segura. A FDA revogou a autorização do acetato de chumbo em tintura de cabelo em 2018.
A hidroquinona fica no mesmo grupo porque é o clareador mais vendido sem receita. É proibida em cosméticos na União Europeia e, usada por muito tempo sem supervisão, pode causar o efeito contrário do prometido: a ocronose, um escurecimento da pele difícil de reverter.
Regra prática: clareador “milagroso”, barato, importado ou sem registro na Anvisa não entra em casa.
Família 3 — Fragrância: o ingrediente que esconde outros
“Parfum”, “Fragrance” ou “Aroma” é uma palavra só no rótulo, mas pode representar uma mistura de dezenas de substâncias. A fórmula da fragrância é protegida como segredo industrial, então o fabricante não precisa dizer o que tem dentro. É aí que se escondem os ftalatos (usados para fixar o cheiro) e os almíscares sintéticos, como Galaxolide e Tonalide, que se acumulam na gordura do corpo e já foram encontrados em leite materno.
A fragrância também é a causa número 1 de dermatite de contato em cosméticos. Por isso a União Europeia obriga a declarar separadamente os alérgenos mais comuns quando passam de um limite: Limonene, Linalool, Geraniol, Citronellol, Eugenol, Coumarin, Hexyl Cinnamal, Benzyl Salicylate e outros. Quando eles aparecem no fim da lista, é sinal de que existe uma fragrância ali.
Algumas moléculas de fragrância já foram banidas na Europa: o Lilial (Butylphenyl Methylpropional), tóxico para a reprodução, saiu do mercado europeu em 2022; o Lyral (HICC) foi banido por ser alérgeno forte. Produto importado antigo ou de procedência duvidosa ainda pode ter.
“Sem perfume” e “sem fragrância” são coisas diferentes
“Unscented” ou “sem perfume” quer dizer que o produto não tem cheiro perceptível, e muitas vezes isso é conseguido com uma fragrância que mascara o cheiro da base. O termo que interessa é “fragrance-free”, ou sem fragrância. E vale lembrar: óleo essencial também é fragrância. É natural, mas traz os mesmos alérgenos (limonene, linalool, eugenol) que estão na lista amarela.
Família 4 — Filtro solar: químico ou mineral
Existem dois tipos de filtro. O filtro químico (orgânico) é absorvido pela camada superficial da pele e transforma a radiação em calor. O filtro mineral (óxido de zinco, dióxido de titânio) fica na superfície e reflete e dispersa a radiação.
O problema do filtro químico é que ele não fica só na superfície. Em estudos da própria FDA, publicados no JAMA em 2019 e 2020, uma única aplicação de oxibenzona, avobenzona, octocrileno, homosalato, octisalato e octinoxato levou esses filtros ao sangue em níveis acima do limite a partir do qual a FDA exige estudos de segurança. A oxibenzona continuava detectável dias depois.
Por isso, na lista vermelha estão os filtros com atividade hormonal mais documentada: oxibenzona (Benzophenone-3), octinoxato (Ethylhexyl Methoxycinnamate), homosalato e 4-MBC. A União Europeia proibiu o 4-MBC em 2025 e limitou a concentração de oxibenzona e homosalato. Avobenzona e octocrileno ficaram na amarela; o octocrileno pode se degradar em benzofenona dentro do frasco com o tempo.
Honestidade científica: chegar ao sangue não prova dano. A própria FDA concluiu que faltam dados, não que os filtros sejam perigosos. O que se sabe é que hoje só dois filtros têm reconhecimento de segurança e eficácia pela FDA: óxido de zinco e dióxido de titânio, os minerais.
A escolha verde é o óxido de zinco em creme, de preferência “non-nano”, nunca em spray. E filtro solar entra como complemento: sol da manhã para regular o relógio biológico (Parte 6), sombra e roupa nos horários de sol forte, e filtro quando a exposição for longa.
Família 5 — Pós e partículas: o risco de respirar
Alguns ingredientes são pouco preocupantes num creme e bem mais preocupantes quando viram pó ou spray, porque entram pelo pulmão.
Talco: em 2024 a IARC classificou o talco como “provavelmente carcinogênico” (Grupo 2A). Além disso, quando extraído sem controle, pode vir contaminado com amianto. O talco de bebê é o exemplo mais claro: aplicado em nuvem, perto do rosto de quem ainda está com o pulmão em formação.
Dióxido de titânio (CI 77891) e negro de fumo (Carbon Black, CI 77266, comum em rímel e delineador): ambos são “possivelmente carcinogênicos” (Grupo 2B) por inalação. Em creme e em produto enxaguado, o risco é baixo.
Aerossóis: desodorante, protetor e xampu seco em spray. Além de levar tudo para o pulmão, entre 2021 e 2022 várias marcas foram recolhidas nos EUA por contaminação com benzeno, que vinha dos propelentes.
Microplásticos: polietileno, nylon, glitter plástico e acrilatos em esfoliantes e maquiagem. Não se degradam, e a União Europeia passou a restringir os adicionados de propósito em 2023.
Regra prática: entre pó, spray e creme, escolha o creme. Para bebê, nada de talco.
Família 6 — Contaminantes que não aparecem no rótulo
Este é o ponto que mais surpreende: ler o rótulo não basta. Alguns dos compostos mais preocupantes não são ingredientes, são contaminantes do processo de fabricação. Como não foram adicionados de propósito, a lei não obriga a declarar.
Contaminante | De onde vem | Como evitar
1,4-dioxano (provável carcinógeno) | Processo de etoxilação: PEGs, ingredientes com “-eth” (Laureth, Ceteareth), Polysorbate, SLES | Preferir tensoativos não etoxilados: Coco-Glucoside, Decyl Glucoside, Sodium Cocoyl Isethionate
MOAH (hidrocarbonetos aromáticos de óleo mineral) | Refino incompleto de Petrolatum, Mineral Oil, Paraffinum Liquidum | Trocar por gordura animal ou vegetal: sebo, karité, cacau, cera de abelha
Nitrosaminas (carcinógenas) | Reação de DEA, TEA e MEA com outros ingredientes da fórmula | Evitar Cocamide DEA, Triethanolamine e similares
Benzeno (carcinógeno) | Propelentes de aerossol e degradação de peróxido de benzoíla guardado no calor (alerta de 2024) | Preferir creme e stick a spray; guardar produto de acne longe do calor

A lógica é a mesma da Parte 2: quanto mais etapas de síntese petroquímica um ingrediente tem, mais chance de trazer junto algo que não está no rótulo.
Família 7 — Conservantes: o mal necessário
Todo produto que tem água na fórmula precisa de conservante. Sem ele, cresce fungo e bactéria, e isso também é perigoso. Então a pergunta certa é: qual conservante?
Lista | Conservantes | Por quê
Vermelha | Liberadores de formol, MIT/MCI (Methylisothiazolinone), parabenos de cadeia longa (butil, propil e outros), BHA | Carcinógeno liberado aos poucos, epidemia de dermatite de contato (a MIT foi proibida em produto que fica na pele na Europa), atividade estrogênica, carcinógeno em animal
Amarela | Parabenos de cadeia curta (metil, etil), fenoxietanol, BHT | Atividade hormonal mais fraca ou evidência menos consistente. A agência francesa recomendou não usar fenoxietanol em produto de área de fralda para menores de 3 anos
Verde | Vitamina E (Tocopherol), extrato de alecrim, benzoato de sódio, sorbato de potássio | Menor risco documentado

Produto sem água (bálsamo, manteiga, óleo, sabonete em barra) não precisa de conservante nenhum. É uma das formas mais simples de cortar exposição.
Família 8 — Os agressores da barreira
Aqui entram ingredientes que não são necessariamente tóxicos, mas que alimentam o ciclo da Parte 4: removem a proteção natural da pele, a pele reage, e você compra o próximo produto.
Sulfatos (SLS, SLES, Ammonium Lauryl Sulfate): limpam removendo também a gordura da barreira. O SLS está ligado a aftas em quem tem tendência.
Álcool desnaturado (Alcohol Denat.) em alta concentração: resseca rápido e intensifica a oleosidade reativa.
Retinoides e ácidos fortes (retinol, ácido retinoico, ácido glicólico e salicílico em alta concentração) e peróxido de benzoíla: forçam a renovação da pele e, sem adaptação, sensibilizam a barreira. A União Europeia passou a limitar a concentração de retinol em cosméticos em 2025.
Propilenoglicol: além de alérgeno, ajuda outros ingredientes a entrar mais na pele.
Retinoides e ácidos fortes estão na lista amarela para adultos, mas são VERMELHOS para criança e gestante.
O lado verde: por que menos é mais
A lista verde segue a lógica da Parte 2: o corpo evoluiu reconhecendo gordura animal, cera e óleo vegetal. Sebo, manteigas, cera de abelha e óleos simples hidratam sem precisar de conservante, emulsificante, fragrância e corante. Para limpar, sabão de óleo saponificado e tensoativos suaves de coco e açúcar. Para cor, pigmentos minerais. Para cheiro, nada.
Natural também não é sinônimo de seguro: óleo essencial traz alérgenos, e pele sensível pode reagir a qualquer coisa. Vale testar numa área pequena antes. E nenhuma troca de produto substitui as quatro alavancas da Parte 6.
Como Aplicar Isso no Dia a Dia
As tabelas deste material trazem os ingredientes mais comuns e mais documentados hoje — mas a indústria química está em constante movimento. Um ingrediente pode ser reformulado, renomeado ou substituído por uma molécula “prima” com o mesmo mecanismo de preocupação, só que com um nome novo no rótulo que ainda não está em nenhuma lista.
Regra prática: se o nome do ingrediente for estranho ou desconhecido, pesquise antes de usar — principalmente em produto de uso diário ou infantil.
Pesquise o nome exato do ingrediente no Google, entre aspas, junto com termos como “endocrine disruptor”, “contact allergen” ou “INCI” — isso costuma trazer bases de dados técnicas, não apenas opinião.
Use aplicativos de leitura de rótulo para escanear o código de barras ou fotografar a lista de ingredientes antes de comprar.
Exemplo de aplicativo: 
Observação: mesmo usando o aplicativo, confira as listas Vermelha, Amarela e Verde a seguir.
Honestidade científica: nenhum aplicativo substitui o julgamento — bases de dados de ingredientes variam em critério e rigor entre si. Use como ponto de partida para pesquisa, não como veredito final.
Lembre-se: menos exposição é melhor.

As Listas: Vermelha, Amarela e Verde
Os ingredientes estão separados em três cores, do mais perigoso para o mais seguro, e dentro de cada lista vêm em ordem de gravidade. O critério de cada cor e a explicação de cada família estão na Parte 7. Use estas páginas para consulta na hora da compra.
 Lista Vermelha: evitar sempre
São 20 grupos, do mais grave para o menos grave. Se aparecer no rótulo, não compre, principalmente para criança, gestante e produto que fica na pele.
# | Ingrediente | Como aparece no rótulo | Onde aparece | Por que evitar
1 | Formol (formaldeído) | Formaldehyde, Formalin, Methylene glycol | Escova progressiva, alisante, esmalte endurecedor | Carcinógeno humano (Grupo 1 da IARC). No Brasil o uso como alisante é proibido pela Anvisa, mas ainda aparece em salão
2 | Liberadores de formol | DMDM Hydantoin, Imidazolidinyl Urea, Diazolidinyl Urea, Quaternium-15, Bronopol (2-Bromo-2-Nitropropane-1,3-Diol), Sodium Hydroxymethylglycinate, Methenamine | Shampoo, sabonete líquido, condicionador, produto infantil | Liberam formol aos poucos durante o uso. Alergênico de contato documentado
3 | Ácido glioxílico e derivados em alisante | Glyoxylic Acid, Glyoxyloyl Carbocysteine, Glyoxyloyl Keratin Amino Acids | Progressiva "sem formol" | Casos de lesão renal aguda publicados no NEJM (2024) e em série de casos em Israel. Com a chapinha quente pode liberar formol
4 | Mercúrio | Mercury, Mercurous Chloride, Calomel, Hydrargyri | Creme clareador irregular ou importado sem registro | Neurotóxico e tóxico para o rim. Proibido em cosméticos, mas ainda achado em clareador vendido pela internet
5 | Chumbo | Lead Acetate; kajal, kohl ou surma tradicional | Tintura progressiva para cabelo grisalho, delineador étnico importado | Neurotóxico, sem dose segura. O acetato de chumbo foi retirado das tinturas nos EUA em 2018
6 | Hidroquinona sem prescrição | Hydroquinone | Clareador de manchas | Proibida em cosméticos na União Europeia. Uso prolongado pode causar o efeito oposto: escurecimento paradoxal (ocronose)
7 | PFAS, as "substâncias eternas" | PTFE, Perfluoro-, Polyperfluoro-, qualquer nome com "fluoro" (ex.: Perfluorononyl Dimethicone, Perfluorodecalin, C9-15 Fluoroalcohol Phosphate) | Maquiagem à prova d'água, base de longa duração, rímel, fio dental | PFOA é Grupo 1 da IARC (2023). Associação com imunidade, diabetes tipo 2 e densidade óssea. Não se degradam no corpo nem no ambiente
8 | Ftalatos | Dibutyl Phthalate (DBP), Diethyl Phthalate (DEP), DEHP, BBP, DMP; escondidos atrás de "Fragrance" ou "Parfum" | Perfume, esmalte, spray de cabelo, embalagem plástica | Disruptores endócrinos com efeito no desenvolvimento reprodutivo em estudos. DBP e DEHP são proibidos em cosméticos na União Europeia
9 | Parabenos de cadeia longa | Butylparaben, Propylparaben, Isobutylparaben, Isopropylparaben, Benzylparaben, Phenylparaben, Pentylparaben | Hidratante, protetor solar, maquiagem, desodorante | Atividade estrogênica demonstrada em laboratório. Na União Europeia cinco deles foram proibidos e butil e propil têm limite e veto em produto de área de fralda
10 | Filtros solares químicos hormonais | Benzophenone-3 (Oxybenzone), Ethylhexyl Methoxycinnamate (Octinoxate), Homosalate, 4-Methylbenzylidene Camphor (4-MBC, Enzacamene) | Protetor solar, base com FPS, batom com FPS | Penetram a pele e têm atividade hormonal em estudos. A União Europeia proibiu o 4-MBC (2025) e limitou oxibenzona e homosalato
11 | Triclosan e triclocarban | Triclosan, Triclocarban | Sabonete "antibacteriano", pasta de dente, desodorante | Interfere no hormônio da tireoide (estudo com 439 gestantes: TSH mais alto). A FDA tirou do sabonete de venda livre em 2016
12 | Talco | Talc, Talcum, Magnesium Silicate | Talco de bebê, pó compacto, sombra, desodorante em pó | Classificado como "provavelmente carcinogênico" (Grupo 2A) pela IARC em 2024. Pode vir contaminado com amianto
13 | BHA | Butylated Hydroxyanisole | Batom, protetor labial, hidratante | Carcinógeno "razoavelmente antecipado" pelo NTP (EUA) com base em estudo animal. No lábio é ingerido várias vezes ao dia
14 | Siloxanos cíclicos | Cyclotetrasiloxane (D4), Cyclopentasiloxane (D5), Cyclohexasiloxane (D6), Cyclomethicone | Desodorante, primer, sérum de cabelo, base | D4 é tóxico para a reprodução segundo a UE. Bioacumulativos. Restritos em produto enxaguável e, até 2027, também nos que ficam na pele
15 | Metilisotiazolinona | Methylisothiazolinone (MIT), Methylchloroisothiazolinone (MCI ou CMIT) | Shampoo, lenço umedecido, sabonete líquido | Causou uma epidemia de dermatite de contato. Proibida em produto que fica na pele na União Europeia
16 | Alcatrão de hulha | Coal Tar, Coal Tar Solution, Pix Carbonis | Shampoo anticaspa, tintura de cabelo | Carcinógeno humano. Proibido em cosméticos na União Europeia
17 | Dietanolamina (DEA) | Diethanolamine, Cocamide DEA, Lauramide DEA | Shampoo, sabonete líquido, espuma | Pode formar nitrosaminas (carcinógenas) na fórmula. Proibida em cosméticos na União Europeia
18 | Tolueno | Toluene, Methylbenzene | Esmalte, removedor, tintura | Solvente tóxico para o sistema nervoso e a reprodução. Faz parte do "trio tóxico" do esmalte, junto com formol e DBP
19 | Fragrâncias já banidas | Butylphenyl Methylpropional (Lilial), Hydroxyisohexyl 3-Cyclohexene Carboxaldehyde (Lyral, HICC), Musk Xylene | Perfume, creme perfumado, produto importado antigo | Lilial é tóxico para a reprodução e foi banido na UE em 2022. Lyral é alergênico forte. Almiscares nitrados são bioacumulativos
20 | Fragrância genérica | Parfum, Fragrance, Aroma | Quase tudo: perfume, hidratante, shampoo, produto infantil | Causa número 1 de dermatite de contato em cosméticos e a palavra pode esconder dezenas de químicos, inclusive ftalatos e almiscares sintéticos

Honestidade científica: a classificação da IARC mede a força da evidência de que algo pode causar câncer, não o tamanho do risco no uso cosmético de uma pessoa. A fragrância está aqui menos pelo risco de cada molécula e mais porque o rótulo não deixa saber o que tem dentro.

 Lista Amarela: atenção
São 26 grupos. Não é pânico: é para tirar do uso diário, da rotina da criança e da gestação, e trocar quando existir alternativa. Estão em ordem do que merece mais atenção para o que merece menos.
# | Ingrediente | Como aparece no rótulo | Onde aparece | Por que ter atenção
1 | Retinoides e ácidos fortes | Retinol, Retinoic Acid, Retinyl Palmitate, Glycolic Acid, Salicylic Acid em alta concentração | Sérum anti-idade, creme de acne, peeling | Ressecam e sensibilizam a barreira e criam o efeito rebote de oleosidade. Vermelho para criança e gestante. A UE passou a limitar o retinol em 2025
2 | Peróxido de benzoíla | Benzoyl Peroxide | Gel e sabonete de acne | Resseca forçado e entra no ciclo de rebote. Em 2024 houve alerta de formação de benzeno em produtos guardados no calor
3 | Sais de alumínio | Aluminum Chlorohydrate, Aluminum Sesquichlorohydrate, Aluminum Zirconium Tetrachlorohydrex Gly | Antitranspirante | Bloqueiam a saída do suor, uma via natural de eliminação. A ligação com câncer de mama não foi confirmada
4 | Filtros solares químicos | Avobenzone (Butyl Methoxydibenzoylmethane), Octocrylene, Ethylhexyl Salicylate (Octisalate) | Protetor solar | Penetração na pele e fotossensibilização. O octocrileno pode se degradar em benzofenona com o tempo
5 | Parabenos de cadeia curta | Methylparaben, Ethylparaben | Hidratante, maquiagem, xampu | Atividade estrogênica bem mais fraca que a dos de cadeia longa, mas somam exposição
6 | Fluoreto em pasta de dente | Sodium Fluoride, Sodium Monofluorophosphate, Stannous Fluoride | Pasta de dente, enxaguante | Compete com o iodo na tireoide. A preocupação maior é criança pequena que engole a pasta. O alerta de QI vem de água fluoretada ingerida, não da pasta cuspida
7 | Petrolatos e óleo mineral | Petrolatum, Paraffinum Liquidum, Mineral Oil, Paraffin, Microcrystalline Wax, Ceresin | Protetor labial, hidratante, pomada de assadura, vaselina | Derivados de petróleo. Se o refino for incompleto, podem trazer MOAH (contaminante que preocupa a EFSA). O rótulo não diz o grau de refino
8 | PEGs e etoxilados | PEG-(número), Polysorbate, Ceteareth-, Laureth-, Steareth-, qualquer "-eth" | Creme, shampoo, condicionador, maquiagem | Podem vir contaminados com 1,4-dioxano (provável carcinógeno). Como é contaminante, não aparece no rótulo
9 | Sulfatos | Sodium Lauryl Sulfate (SLS), Sodium Laureth Sulfate (SLES), Ammonium Lauryl Sulfate | Shampoo, sabonete, pasta de dente | Removem a gordura natural da barreira. SLS está ligado a aftas em quem tem tendência. SLES pode trazer 1,4-dioxano
10 | Alérgenos de fragrância | Limonene, Linalool, Geraniol, Citronellol, Eugenol, Isoeugenol, Coumarin, Cinnamal, Hexyl Cinnamal, Benzyl Salicylate, Benzyl Alcohol | Perfume, creme, shampoo, desodorante, óleo essencial | São os alérgenos mais documentados. Oxidados no ar, irritam mais. Aparecem mesmo em produto "natural" com óleo essencial
11 | Almiscares sintéticos | Galaxolide (Hexamethylindanopyran), Tonalide (AHTN) | Perfume, amaciante, sabonete | Acumulam no tecido adiposo e já foram achados em leite materno. Atividade hormonal fraca em laboratório
12 | Fenoxietanol | Phenoxyethanol | Conservante de quase tudo, inclusive "natural" | Limite de 1% na UE. A agência francesa recomendou não usar em produto para área de fralda em menores de 3 anos
13 | Propilenoglicol | Propylene Glycol, Butylene Glycol | Desodorante, hidratante, sérum | Alergênico de contato e "facilitador": ajuda outros ingredientes a entrar mais na pele
14 | Corantes sintéticos | CI 19140 (Tartrazina, Amarelo 5), CI 15985 (Amarelo 6), CI 16035 (Vermelho 40), CI 17200, CI 42090 (Azul 1) | Sabonete, pasta, shampoo infantil, batom | Só estética, sem função de cuidado. Ligados a hiperatividade em crianças (estudo de Southampton) e a reações de hipersensibilidade
15 | Dióxido de titânio em pó ou spray | Titanium Dioxide, CI 77891 | Pó facial, protetor em spray, xampu seco | Possível carcinógeno por inalação (IARC 2B). Proibido como aditivo alimentar na UE (E171). Em creme enxaguado o risco é baixo
16 | Negro de fumo | Carbon Black, CI 77266 | Rímel, delineador | Possível carcinógeno (IARC 2B), principalmente pela inalação de partículas
17 | Microplásticos | Polyethylene, Polypropylene, Nylon-12, Acrylates Copolymer, Polymethyl Methacrylate, glitter plástico | Esfoliante, maquiagem, glitter | Não se degradam. A UE restringiu microplásticos adicionados de propósito a partir de 2023
18 | Tinturas de cabelo oxidativas | p-Phenylenediamine (PPD), Toluene-2,5-Diamine, Resorcinol | Tintura de cabelo, "henna preta" | PPD é alérgeno forte. Em tatuagem de henna preta vem em dose alta e pode causar reação grave. Resorcinol interfere na tireoide em estudo animal
19 | Trietanolamina e MEA | Triethanolamine (TEA), Monoethanolamine (MEA), Cocamide MEA | Creme, sabonete, tintura | Podem formar nitrosaminas na presença de outros ingredientes
20 | BHT | Butylated Hydroxytoluene | Batom, hidratante, maquiagem | Evidência mista em animal e debate sobre disrupção endócrina. Mais fraco que o BHA
21 | Cocamidopropil betaína | Cocamidopropyl Betaine | Shampoo infantil, sabonete líquido "suave" | Apesar de vir do coco, já foi eleito alérgeno do ano. O problema são as impurezas da síntese
22 | Silicones de cadeia longa | Dimethicone, Amodimethicone, Cetearyl Methicone | Condicionador, finalizador, primer | Baixa toxicidade, mas acumulam no fio e pedem xampu "clarificante", o ciclo produto-que-cria-o-problema
23 | Álcool desnaturado em alta concentração | Alcohol Denat., SD Alcohol | Tônico, gel "matificante", perfume | Resseca a barreira e intensifica a oleosidade reativa
24 | Adoçantes | Sucralose, Sodium Saccharin, Aroma doce | Protetor labial infantil, pasta de dente | Treinam o paladar da criança para o doce e fazem ela lamber e reaplicar o produto várias vezes
25 | Lanolina | Lanolin, Lanolin Alcohol | Protetor labial, pomada de mamilo | Alérgeno de contato. Lotes mal purificados já tiveram resíduo de agrotóxico. O grau farmacêutico é mais limpo
26 | Aerossóis | Butane, Isobutane, Propane (propelentes) | Desodorante, protetor e xampu seco em spray | Entram pela respiração. Entre 2021 e 2022 houve recolhimento de várias marcas por contaminação com benzeno

 Lista Verde: pode usar
São as trocas de verdade, organizadas pela função no produto. Verde não quer dizer zero reação: pele sensível pode reagir a qualquer coisa, então vale testar numa área pequena antes.
Função | Ingrediente | Como aparece no rótulo | Observação
Hidratar e nutrir | Sebo bovino, manteiga de karité, manteiga de cacau, cera de abelha, óleo de coco, azeite, óleo de jojoba, esqualano de oliva | Tallow, Butyrospermum Parkii Butter, Theobroma Cacao Seed Butter, Cera Alba (Beeswax), Cocos Nucifera Oil, Olea Europaea Oil, Simmondsia Chinensis Seed Oil, Squalane | Gorduras que a pele reconhece. Substituem petrolato e óleo mineral, inclusive no protetor labial
Umectar | Glicerina vegetal, babosa, ácido hialurônico, pantenol, alantoína, mel | Glycerin, Aloe Barbadensis Leaf Juice, Sodium Hyaluronate, Panthenol, Allantoin, Mel | Puxam e seguram água na pele
Limpar a pele | Sabão de óleo vegetal saponificado (castela, coco) | Sodium Olivate, Sodium Cocoate, Potassium Cocoate | Sabonete em barra simples, sem fragrância
Limpar o cabelo | Tensoativos suaves de coco e açúcar | Coco-Glucoside, Decyl Glucoside, Lauryl Glucoside, Sodium Cocoyl Isethionate | Shampoo sem sulfato, junto com lavar menos vezes
Desodorizar | Bicarbonato, argila, hidróxido de magnésio, óxido de zinco | Sodium Bicarbonate, Kaolin, Bentonite, Magnesium Hydroxide, Zinc Oxide | Bicarbonato pode irritar axila sensível; nesse caso, magnésio. O odor se resolve também pela alimentação
Escovar os dentes | Hidroxiapatita, bicarbonato, argila | Hydroxyapatite, Sodium Bicarbonate, Kaolin | Pasta sem SLS e sem corante
Proteger do sol | Óxido de zinco em creme | Zinc Oxide (de preferência "non-nano") | Filtro mineral que fica na superfície. Sempre creme, nunca spray. Sol da manhã e sombra continuam sendo a base
Conservar | Vitamina E, extrato de alecrim, benzoato de sódio, sorbato de potássio | Tocopherol, Rosmarinus Officinalis Leaf Extract, Sodium Benzoate, Potassium Sorbate | Conservantes e antioxidantes de menor risco. Produto com água precisa de algum conservante
Dar cor | Óxidos de ferro e pigmentos minerais | CI 77491, CI 77492, CI 77499, Iron Oxides | Trocam os corantes sintéticos na maquiagem
Perfumar | Nada | "Fragrance-free" ou "sem fragrância" | "Unscented" ou "sem perfume" pode ter fragrância que mascara o cheiro. Procure "fragrance-free"

Natural não é sinônimo de seguro: óleo essencial também traz limonene, linalool e eugenol (lista amarela). E nada aqui substitui o que vem de dentro: alimentação, sol da manhã, movimento e sono.
Guia rápido por produto
Na hora da compra, procure primeiro estes nomes em cada tipo de produto.
Produto | Vermelho, procure primeiro | Amarelo, prefira evitar | Troca verde
Protetor labial e batom | BHA, Parfum, PFAS | Petrolatum, corantes CI, sucralose, lanolina | Manteiga de cacau, karité, cera de abelha, sebo
Shampoo e condicionador | Liberadores de formol, MIT, DEA, Coal Tar | SLS, SLES, PEGs, cocamidopropil betaína, dimethicone | Coco-Glucoside, Decyl Glucoside
Sabonete | Triclosan, Parfum | SLS, corantes CI, propilenoglicol | Sabão de castela ou coco em barra
Desodorante | Talco, D5, parabenos longos, Parfum | Sais de alumínio, propilenoglicol, aerossol | Bicarbonato, argila, magnésio
Pasta de dente | Triclosan | Flúor (criança pequena), SLS, sacarina, corantes | Hidroxiapatita, bicarbonato, argila
Protetor solar | Oxibenzona, octinoxato, homosalato, 4-MBC | Avobenzona, octocrileno, spray | Óxido de zinco em creme
Hidratante e skincare | Parabenos longos, hidroquinona, Parfum | Retinol e ácidos (vermelho em criança e gestante), PEGs, fenoxietanol | Sebo, karité, glicerina, hialurônico
Maquiagem | PFAS, talco, D4/D5, parabenos longos | Negro de fumo, dióxido de titânio em pó, microplásticos | Pigmentos minerais (CI 77xxx)
Cabelo: alisante e tintura | Formol, ácido glioxílico, acetato de chumbo, Coal Tar | PPD, resorcinol | Sem alisamento químico
Esmalte | Tolueno, formol, DBP | TPHP, solventes fortes | Marcas que declaram "livre de tolueno, formol e DBP"
Produto infantil | Tudo da lista vermelha, mais Parfum | Fenoxietanol em área de fralda, corantes, adoçantes | O mínimo de produto possível

Regra prática: nome estranho que não está aqui, pesquise entre aspas junto com “endocrine disruptor” ou “contact allergen” antes de usar, principalmente em produto diário ou infantil. Menos exposição é melhor.

Referências
Lista organizada por tema, na ordem em que aparecem no material. Estudos e levantamentos citados de forma descritiva — recomenda-se busca pela fonte primária mais atual antes de reutilizar em aula ao vivo, já que órgãos reguladores revisam posições com frequência.
Estudos citados no texto (numeração)
[1] La Merrill MA, Vandenberg LN, Smith MT, et al. “Consensus on the key characteristics of endocrine-disrupting chemicals as a basis for hazard identification.” Nature Reviews Endocrinology, 2020;16(1):45–57.
[2] National Toxicology Program (NTP). “Monograph on Immunotoxicity Associated with Exposure to Perfluorooctanoic Acid (PFOA) and Perfluorooctane Sulfonate (PFOS).” 2016.
[3] Beglarian E, Costello E, Walker DI, et al. “Exposure to perfluoroalkyl substances and longitudinal changes in bone mineral density in adolescents and young adults: A multi-cohort study.” Environmental Research, 2024;244:117611.
[4] Sun Q, Zong G, Valvi D, Nielsen F, Coull B, Grandjean P. “Plasma Concentrations of Perfluoroalkyl Substances and Risk of Type 2 Diabetes: A Prospective Investigation among U.S. Women.” Environmental Health Perspectives, 2018;126(3):037001.
[5] IARC (Agência Internacional de Pesquisa em Câncer, OMS). Monographs Volume 135 — “Perfluorooctanoic acid (PFOA) and perfluorooctanesulfonic acid (PFOS)”, avaliação de carcinogenicidade finalizada em novembro de 2023.
[6] NIEHS (National Institute of Environmental Health Sciences). “Endocrine Disruptors.” Página de tópicos de saúde ambiental.
[7] Environmental Working Group (EWG). “Body Burden: The Pollution in Newborns.” 2005.
Mercado e regulação
AYTM (consultoria de mercado) — levantamento sobre o tamanho do mercado de beleza infantil/adolescente, 2023.
Estatuto da Criança e do Adolescente (ECA) e Código de Defesa do Consumidor — dispositivos brasileiros sobre publicidade dirigida a crianças.
Iniciativas regulatórias da Itália (investigação sobre microinfluenciadoras crianças) e do estado da Califórnia, EUA (projeto de lei sobre cosmético anti-idade para menores).
Disruptores endócrinos e ingredientes
Literatura toxicológica sobre parabenos e atividade estrogênica em modelos laboratoriais.
Estudos sobre benzofenona/oxibenzona e interferência hormonal.
Classificação da IARC para dióxido de titânio (possível carcinógeno por via inalatória) e literatura sobre BHT em estudo animal.
Regulamentação da União Europeia sobre dióxido de titânio como aditivo alimentar (E171, banido em 2022) e sobre declaração obrigatória de alergênicos de fragrância.
Estudo de Southampton sobre corantes alimentares sintéticos e hiperatividade em crianças, base dos alertas obrigatórios da União Europeia.
PFAS (per e polifluoroalquilados) — ver estudos numerados [2], [3], [4] e [5] acima sobre imunidade, densidade óssea, diabetes tipo 2 e classificação de carcinogenicidade.
Fígado e sistema de desintoxicação
Fisiologia hepática geral — funções de filtragem sanguínea, metabolismo de macronutrientes, produção de bile e conversão periférica de T4 em T3.
Pischinger, Alfred (década de 1970) — conceito do “sistema básico” e da matriz extracelular como modelo conceitual de medicina biológica/funcional sobre desintoxicação e sobrecarga celular.
Flúor e neurodesenvolvimento
NTP Monograph (National Toxicology Program, EUA) sobre exposição ao flúor.
Green, R. et al. (2019) — metanálise associando exposição pré-natal a flúor e desfechos de QI em crianças, com foco em água fluoretada ingerida sistemicamente.
Regulação de conservantes e triclosan
FDA (EUA) — retirada do triclosan de sabonetes de venda livre, 2016.
Parte 7 e Listas Vermelha, Amarela e Verde
IARC — classificação do talco como “provavelmente carcinogênico para humanos” (Grupo 2A), julho de 2024. (cosmeticobs.com)
Regulamento (UE) 2024/996 — proibição do 4-MBC e novas condições para retinol, triclosan e outros. (cirs-group.com)
Regulamento (UE) 2024/1328 — restrição de D4, D5 e D6 em cosméticos que ficam na pele. (chemlinked.com)
New England Journal of Medicine (2024) e American Journal of Kidney Diseases — lesão renal aguda associada a alisantes com ácido glioxílico e derivados. (personalcareinsights.com)
Matta MK et al. — estudos da FDA sobre absorção sistêmica de filtros solares químicos. JAMA, 2019 e 2020.
Anvisa — proibição do uso de formol como alisante capilar.
FDA (EUA) — revogação da autorização do acetato de chumbo em tinturas de cabelo, 2018.
Regulamento Cosmético da União Europeia — lista de substâncias proibidas (Lilial, Lyral, hidroquinona, DEA, coal tar, DBP, DEHP, parabenos de cadeia longa) e restrição de microplásticos (2023).
Este documento é material de apoio educacional do Protocolo Superhumano e não substitui avaliação individual com profissional de saúde.
