# Combo Jejum + Carnívora (material de jejum)

ANTONIO KRAYCHETE
ANTONIO KRAYCHETE
 
2 
 
A Arma Secreta do Protocolo Superhumano 
Você chegou a um ponto da jornada que poucos alcançam. Você limpou sua 
alimentação, eliminou o ruído e começou a dar ao seu corpo o que ele realmente 
precisa. Agora, vamos adicionar uma arma poderosa ao seu arsenal, uma ferramenta 
ancestral que foi esquecida pela modernidade, mas que seu corpo nunca deixou de 
reconhecer: o jejum. 
O jejum não é uma moda. Não é sobre passar fome. É uma estratégia biológica de 
reset. É a sua chance de acelerar a cura, quebrar platôs e levar sua clareza mental a 
um nível que você nem sabia que existia. Nomes como Dr. Jason Fung, um dos 
maiores especialistas do mundo no assunto e autor do livro "The Complete Guide to 
Fasting", têm resgatado essa prática, mostrando com base na ciência o que nossos 
ancestrais já sabiam na prática. 
Para quem vive no caos da alimentação moderna, jejuar parece um ato extremo. Para 
você, que já está no caminho carnívoro, vai ser a evolução natural. 
 
Jejum: O Elo Perdido do Ser Humano 
Durante milhões de anos, os humanos viveram em ciclos de abundância e escassez. 
Caçavam, comiam, e depois passavam longos períodos sem comida — não por 
escolha, mas por design da natureza. Esse ciclo moldou o metabolismo humano. 
O corpo aprendeu a prosperar no jejum, usando gordura e cetonas como 
combustível primário. 
O Protocolo Superhumano restaura o que você comeu. 
O jejum restaura como você come — o ritmo natural entre nutrição e ausência, entre 
força e repouso metabólico. 
É por isso que os dois se completam. Dieta baseada em produtos animais e jejum são 
as duas metades do mesmo código ancestral. 

Você Está
Pronto para 
o Jejum? 
Você Está
Pronto para 
o Jejum? 
CAPÍTULO 1
CAPÍTULO 1
RESET METABÓLICO

4 
 
CAPÍTULO 1 
Você Está Pronto para o Jejum? 
Antes de usar uma arma, você precisa estar treinado. Com o jejum, é a mesma coisa. 
Tentar jejuar sem preparar o corpo é como ir para a guerra sem munição. Você vai 
falhar. 
A boa notícia? Qualquer dieta dentro do Protocolo SUperhumano é o seu 
treinamento. 
O processo que você está vivendo agora se chama adaptação à gordura. Seu corpo 
está reaprendendo a usar a fonte de energia mais limpa e eficiente que existe: a 
gordura — tanto a que está no seu prato quanto a que está armazenada em você. 
Você deixa de ser um “queimador de açúcar”, que precisa de combustível a cada 3 
horas para não entrar em colapso, e se torna um “queimador de gordura”: estável, 
constante, autossuficiente. 
 
Sinais claros de que você está pronto — de que sua máquina mudou: 
1. A Fome Perdeu o Controle Sobre Você: 
Lembra daquela fome desesperada, que te deixava irritado, fraco, incapaz de pensar? 
Ela sumiu. Agora, a fome é um sinal calmo, um lembrete, não uma emergência. Você 
consegue passar horas sem comer e se sente perfeitamente bem, porque seu corpo 
sabe que tem dezenas de milhares de calorias de energia disponível no seu próprio 
estoque. 
2. Sua Energia é Linear, Não uma Montanha-Russa: 
Você acorda disposto e se mantém assim ao longo do dia. Aquela queda de energia 
brutal depois do almoço ou no meio da tarde não existe mais. Isso acontece porque 
você não vive mais de picos de glicose. Sua energia vem de uma fonte constante: as 
cetonas e a gordura. 
3. A Neblina Mental Desapareceu: 
Sua mente está mais afiada. O foco é mais profundo. A memória, mais nítida. O 
cérebro adora cetonas, um combustível de elite que reduz a inflamação neural e 
estabiliza a atividade elétrica. Se você se sente mais presente e menos distraído, é um 
sinal claro de que seu cérebro está sendo bem alimentado. 
4. Você Já Começou a Jejuar Sem Perceber: 
Talvez você já esteja pulando o café da manhã naturalmente, sem esforço, 
 
5 
 
simplesmente porque não sente fome. Isso é o jejum espontâneo. É o seu corpo te 
dizendo: “Estou bem. Não preciso de comida agora. Tenho tudo de que preciso aqui 
dentro.” 
Se você se identifica com esses sinais, parabéns. 
Você não está apenas pronto para começar a jejuar. 
Você já está no caminho. 
O jejum agora será apenas uma formalidade. 

Benefícios
Reais do Jejum 
Intermitente e
Prolongado 
Benefícios
Reais do Jejum 
Intermitente e
Prolongado 
CAPÍTULO 2
CAPÍTULO 2
RESET METABÓLICO

7 
 
CAPÍTULO 2 
Benefícios Reais do Jejum 
Intermitente e Prolongado 
O jejum é a forma mais concreta de praticar delayed gratification — a capacidade de 
adiar recompensas imediatas por algo maior no futuro. 
É o treino biológico da disciplina. 
Cada hora em que você escolhe não comer é um lembrete de que você está no 
comando, não seus impulsos. 
A dopamina deixa de ser liberada pela comida e passa a ser liberada pelo progresso. 
Essa mudança é o núcleo da transformação — física, mental e até espiritual. 
Você não está apenas deixando de comer; está ensinando seu cérebro a adiar 
prazer em troca de poder. 
 
O jejum não é para perder peso rápido. 
É para reconstruir sua saúde de dentro para fora. É uma ferramenta de precisão que 
ativa processos que a alimentação constante, mesmo que limpa, mantém adormecidos. 
 
Clareza Mental de Elite: 
Se as dietas do Protocolo Superhumano limpam a neblina mental, o jejum a pulveriza. 
Ao jejuar, você aumenta a produção de cetonas, o combustível preferido do cérebro. 
Além disso, o corpo libera hormônios de alerta, como a noradrenalina, que te deixam 
mais focado e presente. 
Nossos ancestrais precisavam dessa nitidez para caçar quando a comida era escassa. 
Você vai usar essa mesma vantagem biológica para dominar seu trabalho, seus treinos 
e sua vida. 
 
Autofagia: A Faxina Celular que Te Rejuvenesce: 
Este é talvez o benefício mais profundo e menos compreendido. 
Autofagia significa “comer a si mesmo”. É um processo em que seu corpo identifica e 
recicla componentes celulares velhos, danificados e disfuncionais — lixo acumulado 
que gera inflamação e acelera o envelhecimento. 
 
8 
 
A alimentação constante, especialmente o consumo de proteína, desliga esse 
processo. 
O jejum é o gatilho mais poderoso para ligar a autofagia. 
É o seu corpo fazendo uma manutenção interna, eliminando o que não serve para dar 
lugar ao novo. 
É, literalmente, um processo antienvelhecimento. 
 
Reset Metabólico: Dominando a Insulina: 
A resistência à insulina é a mãe da maioria das doenças modernas: obesidade, 
diabetes tipo 2, gordura no fígado. 
Uma alimentação baixa em carboidrato já reduz drasticamente a insulina por zerar os 
carboidratos. 
O jejum leva isso a outro nível. 
Ele força períodos prolongados onde a insulina fica em níveis mínimos, quebrando o 
ciclo de resistência de uma vez por todas. 
É a forma mais rápida e eficaz de ensinar seu corpo a ouvir os sinais hormonais 
novamente. 
É você retomando o controle do seu metabolismo. 
 
Aniquilação da Inflamação Crônica: 
A inflamação é o inimigo silencioso que causa dores articulares, problemas de pele, 
fadiga e doenças autoimunes. 
A dieta que você está fazendo no espectro Superhumano remove os principais gatilhos 
inflamatórios vindos das plantas e ultraprocessados. 
O jejum vai além: ele ativa vias anti-inflamatórias e dá ao sistema imune um descanso 
completo. 
É por isso que pessoas com dores crônicas ou doenças autoimunes relatam um alívio 
quase imediato durante e após um período de jejum. 
Você não está apenas gerenciando a inflamação. Você está eliminando a causa. 

Comece 
o Jejum 
Comece 
o Jejum 
CAPÍTULO 3
CAPÍTULO 3
RESET METABÓLICO

10 
 
CAPÍTULO 3 
Comece o Jejum 
A força não vem da complexidade. 
Vem da simplicidade e da consistência. 
Não tente ser um herói no primeiro dia. 
Você já fez o trabalho duro de se adaptar à gordura. 
Agora, vamos apenas formalizar o que seu corpo já está começando a pedir. 
 
Protocolos Simples e Graduais — A Escada da Maestria 
1. Protocolo 16:8 (O Primeiro Passo Natural) 
O que é: Jejuar por 16 horas e se alimentar em uma janela de 8 horas. Na 
prática, para a maioria, isso significa simplesmente pular o café da manhã. 
Como Fazer: Se você terminou o jantar às 20h, sua primeira refeição do dia 
seguinte será ao meio-dia. Durante o período de jejum, você pode consumir 
água, café puro, chás sem açúcar e caldo de ossos com sal. 
Por que Funciona: É a transição mais suave que existe. Como carnívoro, sua 
fome matinal já diminuiu ou desapareceu. Você não estará "se forçando" a 
jejuar; estará apenas ouvindo seu corpo. 
 
2. Protocolo 24 Horas (O Próximo Nível: Uma 
Refeição por Dia - OMAD) 
O que é: Fazer uma única e robusta refeição por dia. 
Como Fazer: Se jantou às 19h na segunda-feira, sua próxima refeição será às 
19h na terça-feira. Você ainda come todos os dias, o que simplifica a logística e 
a vida social. 
Quando Usar: Comece com 1 a 2 vezes por semana. É uma ferramenta 
fantástica para quebrar a rotina e aprofundar os benefícios do jejum sem um 
compromisso extremo. 

11 
 
3. Protocolo 36 Horas (A Ferramenta de Precisão) 
O que é: Passar um dia inteiro sem comer. É um protocolo mais potente, ideal 
para quebrar platôs de peso ou para fazer um "reset" mais profundo após um 
período de excessos (como feriados). 
Como Fazer: Termina o jantar no domingo à noite. Passa toda a segunda-feira 
apenas com líquidos permitidos. Volta a comer no café da manhã de terça-feira. 
Aviso: Este é um passo avançado. Só tente quando estiver 100% confortável 
com os protocolos mais curtos. É uma arma poderosa, e deve ser usada com 
respeito. 
 
Toda vez que você completa um jejum, mesmo que curto, você prova a si mesmo que 
tem controle. 
Você reforça a identidade de alguém que não cede ao impulso. 
Cada vitória dessas reprograma seu cérebro. 
O corpo muda depois. 
Mas a mente muda primeiro. 
E é essa mente que vai te levar até o final dessa jornada. 
 
--- NOVOS PROTOCOLOS AVANÇADOS --- 
4. Protocolo 48 Horas (O Acelerador de Autofagia): 
o O que é: Dois dias inteiros sem comer. Aqui é onde a mágica realmente 
acontece. Após 48 horas, o processo de autofagia atinge um pico 
significativo. Seu corpo não está apenas reciclando lixo celular; ele está 
fazendo uma reforma completa, eliminando células pré-cancerígenas e 
ativando a regeneração de tecidos de uma forma que jejuns mais curtos 
não conseguem. É a ferramenta definitiva para quebrar platôs teimosos e 
promover um rejuvenescimento celular profundo. 
o Como Fazer: A lógica é a mesma, mas estendida. Se sua última refeição 
foi o jantar de domingo, você passará toda a segunda e terça-feira 
apenas com líquidos permitidos (água, sal, caldo de ossos, café/chá). 
Você voltará a comer apenas no café da manhã de quarta-feira. 
o Aviso Importante: Isto não é para iniciantes. Este protocolo exige que 
você já tenha dominado os jejuns de 24 e 36 horas. A reposição de 
eletrólitos (sódio, principalmente) torna-se crítica, não opcional. O mais 
interessante é que, para muitos, a fome que se manifesta no segundo dia 
 
12 
 
tende a diminuir drasticamente, tornando o processo mais mental do que 
físico. 
5. Protocolo 72 Horas (O Reset Completo do 
Sistema): 
o O que é: Três dias completos de jejum. Este é o protocolo terapêutico 
mais profundo que você pode fazer por conta própria com segurança. 
Estudos sugerem que jejuns de 72 horas podem resetar completamente 
o sistema imunológico, forçando o corpo a eliminar células imunes 
velhas e danificadas e a gerar novas a partir de células-tronco. É uma 
reinicialização biológica. É o seu corpo se reconstruindo a partir do zero. 
o Como Fazer: Última refeição no jantar de domingo. Passa segunda, terça 
e quarta-feira em jejum total (apenas líquidos). A quebra do jejum 
acontece no café da manhã de quinta-feira. A hidratação e os eletrólitos 
são a sua linha de vida aqui. Caldo de ossos salgado será seu melhor 
amigo. 
o Aviso Importante: Este é o nível mais avançado da prática. Só o 
considere após ter experiência sólida com jejuns de 48 horas. A fome, 
neste ponto, já terá desaparecido quase que por completo, e o desafio se 
torna puramente mental e de disciplina. A quebra do jejum deve ser 
extremamente gentil: comece com caldo de ossos, espere uma hora, 
depois coma uma porção pequena de carne. Não sobrecarregue seu 
sistema digestivo. Trate este protocolo com o respeito que uma 
ferramenta de tamanha potência merece. 

Erros Comuns
no Jejum e 
Como Evitá-los 
Erros Comuns
no Jejum e 
Como Evitá-los 
CAPÍTULO 4
CAPÍTULO 4
RESET METABÓLICO

14 
 
CAPÍTULO 4 
Erros Comuns no Jejum e Como 
Evitá-los 
O caminho para a maestria é pavimentado com a correção de erros. No jejum, 
pequenos deslizes podem tornar a experiência um inferno. Evite-os e o processo será 
suave e poderoso. 
1. O Erro: Desidratação e Falta de Eletrólitos. 
o O Sintoma: Dor de cabeça, fraqueza, cãibras, tontura, irritabilidade. 
o Por que Acontece: Ao cortar carboidratos e jejuar, seus níveis de insulina 
caem, e os rins excretam mais sódio e água. Se você bebe apenas água 
pura, está diluindo ainda mais seus minerais. 
o A Solução: Beba água com sal. Use um sal integral de boa qualidade. A 
melhor ferramenta aqui é o caldo de ossos caseiro e salgado. Ele 
hidrata e repõe minerais, tornando o jejum infinitamente mais fácil. Não 
subestime isso. Eletrólitos não são opcionais. 
2. O Erro: Tentar Ser Herói no Primeiro Dia. 
o O Sintoma: Fome avassaladora, frustração e a crença de que "jejum não 
é para mim". 
o Por que Acontece: Tentar um jejum de 48 horas sem nunca ter pulado o 
café da manhã é como tentar levantar 200kg no supino no seu primeiro 
dia de academia. É receita para o desastre. 
o A Solução: Respeite o processo. Comece com o jejum de 16:8. 
Domine-o. Sinta-se confortável. Depois, e somente depois, avance para 
24 horas. O jejum é uma habilidade. E habilidades são construídas com 
prática gradual, não com saltos suicidas. 
3. O Erro: Comer Pouco (e com Medo da Gordura) nas Janelas de 
Alimentação. 
o O Sintoma: Fome constante mesmo nos dias de alimentação, falta de 
energia, perda de massa muscular e estagnação. 
 
15 
 
o Por que Acontece: Você traz a mentalidade de "dieta de restrição" para a 
carnívora. Come cortes magros e porções pequenas, com medo de 
engordar. Seu corpo entra em pânico, achando que a comida é escassa, 
e desacelera o metabolismo para se proteger. 
o A Solução: Nas suas janelas de alimentação, coma até a saciedade 
total. Priorize cortes gordos de carne. A gordura é o sinal de segurança 
para o seu corpo. Ela te dá energia, estabiliza hormônios e elimina a 
fome. Não tenha medo do que te nutre. O jejum funciona porque você o 
combina com nutrição densa, não com fome crônica. 
4. O Erro: Quebrar o Jejum com um Banquete. 
o O Sintoma: Desconforto digestivo, inchaço, gases, e uma sensação de 
peso no estômago. 
o Por que Acontece: Seu sistema digestivo estava em repouso. Jogar uma 
quantidade enorme de comida de uma vez é um choque para ele. 
o A Solução: Quebre o jejum gentilmente. Comece com algo leve e de 
fácil digestão. Um copo de caldo de ossos ou uma porção pequena de 
carne moída são excelentes opções. Espere 30-60 minutos e então faça 
sua refeição principal, com calma e mastigando bem. 
5. O Erro: Não Ouvir o Próprio Corpo. 
o O Sintoma: Insistir no jejum mesmo se sentindo genuinamente mal 
(fraqueza extrema, náusea, tontura persistente). 
o Por que Acontece: Você confunde disciplina com teimosia. Acredita que 
precisa sofrer para ter resultados. 
o A Solução: O corpo não mente. Uma coisa é a onda de fome, que 
passa. Outra é um mal-estar real. Se seu corpo está gritando por ajuda, 
ouça. Pare o jejum, coma, reavalie (Faltou sal? Dormi mal? Estresse?). 
Disciplina é fazer o que é certo, não o que é mais difícil. Jejum é maestria, 
não martírio.
