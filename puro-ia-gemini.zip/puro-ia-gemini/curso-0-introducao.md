# Curso Introdução à Carnívora: abertura e Bloco 0 (introdução)

Index
0. Introdução e o que esperar do curso
0.1 - Introdução ao Curso
0.2 - Quem Sou Eu
1. O que é a dieta carnívora
1.1 - Entendendo a Dieta Carnívora
1.2 - Quanto Eu Devo Comer?
1.3 - A Importância da Gordura
1.4 - A Importância dos Eletrólitos
1.5 - Carnívoro vs Herbívoro vs Onívoro
1.6 - Recapitulando
2. Antropologicamente, por que a dieta carnívora faz sentido?
2.1 - Introdução
2.2 - Evolução
2.3 - Era do Gelo
2.4 - Isótopos Estáveis
2.5 - Revolução Agrícola
2.6 - Populações Carnívoras Atuais
2.7 - "Mas os Cara Só Viviam 30 Anos"
2.8 - Recapitulando
3. Anatomicamente E Fisiologicamente
3.1 - Carboidratos Não São Essenciais
3.2 - A Cetose: O Combustível Natural do Corpo Humano
3.3 - Sistema Digestivo 
3.4 - Sistema Especializado para Absorver Gordura
3.5 - Dentes e Mandíbula
3.6 - Recapitulando
4. Estudos sobre a dieta cetogênica e carnívora
4.1 - Entendendo Estudos
4.2 - Como Podemos Ter Causalidade na Nutrição?
4.3 - O Primeiro Experimento Documentado
4.4 - Transtorno Bipolar, Esquizofrenia e Cetose
4.5 - Depressão e Cetose
4.6 - Autismo e Cetose
4.7 - Compulsão Alimentar, Vício em Comida e Cetose
4.8 - Esclerose Múltipla e a Dieta Carnívora
4.9 - Colesterol: O Medo Que Não Faz Sentido
4.10 - Bônus: Como Saber Se Você Tem Síndrome Metabólica?
4.11 - Recapitulando
5. Agora, se pra você faz sentido, como começar?
5.1 - Intro e Regras
5.2 - Se voce quiser fazer testes de sangue
5.3 - Possível Transição 
5.4 - Agora Você Está na Carnívora
5.5 - Você Ainda Gosta de Fazer Cálculos? 
5.6 - Possíveis sintomas de transição e soluções
5.7 - Recapitulando
6. Por que plantas fazem mal?
6.1 - Botânica 101: O que as plantas realmente querem?
6.2 - Mecanismos de defesa Químicos
6.3 - Antes vs Depois
6.4 - Recapitulando
7. Médicos que usam essa dieta
7.1 - Introdução
7.2 - Dr. Shawn Baker – O Cirurgião que Popularizou a Dieta Carnívora
7.3 - Dr. Anthony Chaffee – O Neurocirurgião Que Questiona Tudo Sobre a Nutrição Moderna
7.4 - Dr. Robert Kiltz – Fertilidade com a Dieta Carnívora
7.5 - Vilhjalmur Stefansson – O Explorador Que Viveu Anos Só Com Carne
7.6 - Dr. Ken Berry – O Médico Que Abandonou as Diretrizes Tradicionais
7.7 - Dr. Philip Ovadia – O Cirurgião Cardíaco que Abandonou a Medicina Convencional
7.8 - Dra. Georgia Ede – A Psiquiatra Que Provou Que a Nutrição Afeta a Mente
7.9 - Dr. Chris Palmer – O Psiquiatra Que Usa a Dieta Cetogênica e Carnívora Para Tratar Doenças Mentais
8. Casos de Sucesso  na dieta carnívora
8.1 - Introdução
8.2 - Mikhaila Peterson: A Dieta Carnívora Salvou Sua Vida
8.3 - Jordan Peterson: Como a Dieta Carnívora Mudou Sua Vida
8.4 - Kerry Mann: A Revolução da Dieta Carnívora
8.5 - Adam Lacy: Vitiligo e Dano Cerebral
8.6 - Dianne Ladd: De Esclerose Múltipla à Recuperação Inacreditável
8.7 - Bradley marshall: Eczema Curado
8.8 - Kent Lee - Dieta Carnívora e a Transformação Após a Colectomia
8.9 - Rebekah Heishman: Nova Vida Com a Dieta Carnívora
8.10 - Fabiana Bier - A carnívora na ajuda da Bipolaridade
8.11 - Recapitulando
Bloco 0 - Intro
Bloco 0 - Introdução
Fala Galera, começamos hoje o curso mais completo do brasil sobre dieta carnívora. Espero que vocês venham com o intuito de aprender com a informação apresentada, e não de serem juízes das minhas habilidades de fazer apresentações. hahaha
0.1 Intro 
A dieta carnívora está em alta nos Estados Unidos e no resto do mundo. Médicos como Dr. Eric Westman, Dr. Anthony Chaffee e Dr. Shawn Baker estão usando essa abordagem para tratar diabetes, hipertensão e outras doenças metabólicas. Psiquiatras e neurocientistas como Dr. Georgia Ede e Dr. Chris Palmer, de Harvard, aplicam essa alimentação no tratamento de depressão, ansiedade, esquizofrenia e muitas outras doenças psiquiátricas.
 E, mais do que isso, milhares de pessoas estão adotando esse estilo "restritivo"—comendo apenas carne, ovos e frutos do mar—para perder peso, recuperar energia e se sentir melhor do que nunca.
Mas ainda estamos nadando contra a maré. Quando você diz que não come pão, arroz, frutas e vegetais, todo mundo vira especialista em nutrição e começa a repetir as mesmas frases de sempre: "Mas e as fibras?", "E os nutrientes?", "Carne dá câncer!", "Carne causa gota!". Ate alguns de voces assistindo devem estar se perguntando isso! haha. Só que, quando a gente olha de perto, nada disso se sustenta.
Nesse curso, eu vou te deixar preparado pra iniciar uma dieta carnívora e mostrar por que a ela  faz sentido. Primeiro, vamos entender o que essa dieta realmente é. Depois, vamos mergulhar na antropologia para ver como o ser humano sempre teve a carne como base alimentar. Em seguida, vamos explorar nossa anatomia e as provas de que fomos feitos para comer carne. Depois, a ciência: o que já sabemos sobre dietas cetogênicas e carnívoras? Quais são as evidências? Depois, talvez o mais importante, como começar e o que esperar. Não só isso, vamos ver médicos que utilizam a dieta carnívora pra tratar seus pacientes e, por fim, você vai conhecer histórias reais de pessoas que transformaram sua saúde com essa dieta.
Se você chegou até aqui, parabéns. Talvez você queira perder peso, talvez esteja sem energia e precise de remédios ou estimulantes para funcionar, ou talvez esteja apenas curioso sobre esse estilo de vida. No final das contas, todos vocês estão questionando aquilo que sempre disseram sobre alimentação. E isso já é um passo gigantesco.

0.2 Quem sou eu
Antes de começar o curso e entrar em detalhe sobre todos esses assuntos interessantes, deixa eu me apresentar.
Meu nome é Antonio Kraychete. Se você ainda não me conhece, eu sou o criador da maior comunidade carnívora do Brasil e produzo conteúdo sobre dieta carnívora, saúde metabólica e nutrição baseada em ciência. Meu trabalho já alcançou milhões de pessoas, ajudando a transformar vidas com informação real e sem amarras ideológicas.
Talvez você já tenha me visto no Instagram, no YouTube ou no TikTok. Nas redes sociais, eu já acumulo:📊 Instagram: 106K seguidores | 28M+ visualizações📊 YouTube: 7.5K inscritos | 700K+ visualizações📊 TikTok: 24K seguidores | 8.4M visualizações no último ano
Além disso, já entrevistei alguns dos maiores especialistas do mundo sobre dieta carnívora e saúde, como:✅ Dr. Dario Birolini (Gastrocirurgião)✅ Dr. Thomas Seyfried (Pesquisador e Cientista)✅ Dr. Anthony Chaffee (Médico)✅ Bart Kay (Cientista)✅ Alessandro Medeiros (Atleta)
✅ Lua Ferrari (Nutri)✅ Daniela Godoy (Nutri)
✅ Dr Ciro Campos Cardiologista

Mas antes de falar de tudo isso, deixa eu te contar um pouco da minha história.
Eu sempre fui um cara cético. Minha formação é em Engenharia Mecânica pela University of Central Florida, e lá aprendi a interpretar estudos científicos, conduzir experimentos e estruturar pesquisas com método científico. Isso me deu uma base sólida para questionar tudo que sempre me disseram sobre alimentação.
Mas não foi só estudo que me trouxe até aqui. Minha transformação começou quando eu cheguei aos 100 kg, sem energia, desmotivado e diagnosticado com TDAH. Eu não conseguia focar, me sentia ansioso e sem direção. Para compensar, dependia de Venvanse e consumia 300 mg de cafeína por dia só para funcionar. Mas eu percebi que isso não era sustentável. Eu estava apenas mascarando um problema mais profundo. Foi então que um vídeo me pegou de surpresa. Era o Kerry Mann, um cara que sofria com depressão debilitante—chegando a pensar em suicídio, mesmo tendo três filhas e uma esposa. Além disso, ele tinha IBS, gota, problemas articulares, hipertensão e uma lista de lavanderia de problemas de saúde. No vídeo, ele contou que estava na dieta carnívora há 100 dias. Depois de descrever todos os seus problemas, ele pegou uma bandeja quadrada cheia de mais de 20 potes de remédio e disse: "Vocês tão vendo isso? Eu não preciso mais de NADA disso"... enquanto jogava tudo pra cima. Na hora, pensei: "Ou esse cara é maluco, ou ele achou uma fórmula que pouca gente sabe." Na mesma hora, tive a realização de que talvez a comida não estivesse só afetando meu peso, mas também minha mente. A partir daí, mergulhei nos estudos sobre nutrição, metabolismo e fisiologia. E quanto mais eu lia, mais percebia que a realidade era o oposto do que me ensinaram a vida toda. Carboidratos não são essenciais. A carne vermelha não é vilã. E comer só carne poderia ser a solução para vários problemas que eu achava que não tinham saída.
Quando comecei a dieta carnívora, os resultados foram imediatos. Perdi gordura, minha disposição voltou, minha mente clareou e minha saúde mental melhorou drasticamente. Com duas semanas parei de tomar venvanse e tirei um break por 6 meses do café. Minha ansiedade foi embora. Coisas que eu nem esperava melhoraram, como minha impulsividade. O melhor, foi que eu comecei a me sentir no topo do mundo. O que eu achava impossível aconteceu: eu voltei a me sentir no controle da minha própria vida.
Agora, eu passo meu tempo estudando, testando, entrevistando especialistas e ajudando milhares de pessoas a terem essa mesma transformação. Não importa se você quer perder peso, melhorar a energia, reverter uma doença metabólica ou simplesmente entender mais sobre nutrição de verdade. Esse curso é para você.
Milhares de pessoas já mudaram completamente de vida ao adotar esse estilo de alimentação. Histórias de perda de peso impressionante, reversão de doenças metabólicas, melhora da saúde mental e uma energia que parecia impossível de recuperar. E tudo isso sem as restrições complicadas das dietas convencionais, sem passar fome e sem depender de medicamentos.Depoimentos Stay Hard
Ainda assim, a maioria das pessoas cresce ouvindo que carne faz mal, que carboidratos são essenciais e que sem fibra o intestino simplesmente para de funcionar. Essas ideias foram repetidas tantas vezes que parecem verdades absolutas, mas será que realmente fazem sentido? Quando olhamos para a ciência de forma crítica, percebemos que a história é bem diferente. E é exatamente isso que eu vou te mostrar ao longo desse curso.
Antes de entrarmos com as informações interessantes, deixa eu te fazer um pedido: acompanhe esse curso com a mente aberta. Algumas coisas podem parecer contraintuitivas no começo, mas tudo que eu vou te mostrar é baseado em ciência, lógica e experiência real. Esse conhecimento pode mudar completamente a forma como você enxerga a comida, a saúde e o seu próprio corpo. E quero deixar claro, nada nesse curso eh conselho médico, nem nutricional.E claro, se quiser que eu te ajude mais de perto nessa jornada, pode me mandar mensagem no meu Instagram [contato removido] ou no meu e-mail: [contato removido].
