# Protocolo Superhumano - Conservantes e Aditivos (guia dos rótulos de alimentos)

# INTRODUÇÃO

## Por que os conservantes existem?

Vivemos em uma era em que a alimentação precisa durar mais tempo, viajar longas distâncias e abastecer milhões de pessoas. Por isso, os conservantes fazem parte da realidade da indústria alimentícia moderna.

O problema não é apenas a existência deles, mas o contexto: excesso de ultraprocessados, baixa qualidade alimentar, inflamação crônica, sedentarismo, deficiência nutricional e exposição constante a substâncias que o corpo precisa metabolizar diariamente.

**Saúde não depende de um único ingrediente isolado.**  
Ela é resultado do conjunto: qualidade da alimentação, sono, exposição solar, movimento, gestão do estresse, metabolismo e capacidade do organismo de lidar com inflamação e oxidação.

Quando falamos de conservantes, é importante sair do medo simplista e entender que existem diferenças entre eles — além da dose, frequência de consumo e contexto alimentar da pessoa. Alguns compostos têm funções importantes para segurança alimentar, evitando contaminações graves e proliferação bacteriana.

Ao mesmo tempo, o consumo excessivo de ultraprocessados ricos em aditivos pode estar associado a piora metabólica, inflamatória e intestinal em parte da população.

## Os interesses da indústria alimentícia

Uma pergunta comum é: "Se alguns aditivos podem fazer mal, por que eles ainda são usados?"

A indústria alimentícia movimenta bilhões e possui enorme influência econômica e política. Isso não significa que tudo que ela produz seja automaticamente ruim, mas significa que existem interesses comerciais envolvidos nas decisões de formulação, marketing e regulamentação dos alimentos.

Muitas vezes, o objetivo principal da indústria não é saúde metabólica, e sim:

- Durabilidade do produto e estabilidade na prateleira
- Redução de custos de produção
- Aumento de palatabilidade e maior consumo
- Escala de produção em massa

Além disso, processos regulatórios podem ser lentos. Em alguns casos, substâncias amplamente utilizadas só começam a ser revistas anos depois, conforme novos estudos surgem e aumenta a pressão pública e científica.

**Desenvolva senso crítico alimentar**  
Não para viver com medo da comida, mas para entender que nem sempre praticidade industrial significa melhor escolha para a saúde no longo prazo. Uma das maiores vantagens de priorizar alimentos in natura é que você naturalmente reduz a exposição a aditivos e conservantes sem precisar viver obcecado lendo rótulos.

## Como ler um rótulo alimentar

Ao ler um rótulo, alguns pontos devem acender um sinal de atenção:

- Listas de ingredientes muito longas (quanto mais longa, mais processado)
- Excesso de açúcares adicionados em diversas formas
- Óleos vegetais refinados em excesso
- Corantes artificiais com nomes de códigos (ex: Amarelo 5, Vermelho 40)
- Muitos estabilizantes, espessantes e realçadores de sabor
- Produtos onde a carne aparece em pequena quantidade e o restante é composto por amidos, farinhas e aditivos

## O QUE O MUNDO JÁ BANIU — E AQUI AINDA É PERMITIDO

Um dado muito revelador: alguns aditivos e ingredientes permitidos no Brasil já foram restringidos ou proibidos em outros países. Isso mostra como segurança alimentar não é algo totalmente absoluto ou imutável.

A pergunta que todo consumidor deveria fazer é:

**Se é proibido na Europa, no Canadá ou em outros países desenvolvidos...**  
...por qual motivo ainda é permitido no Brasil? Regulamentações mudam com o tempo conforme surgem novos estudos, revisões toxicológicas e pressões públicas. Gorduras trans industriais, por exemplo, foram amplamente usadas por décadas e hoje são proibidas ou severamente restringidas em muitos países devido à associação com doenças cardiovasculares.

- Gorduras Trans Industriais — Proibido ou restrito em: EUA, UE, Canadá, vários países | Brasil: PROIBIDO DESDE 2023 — Doenças cardiovasculares, Inflamação
- rBGH / rBST (hormônio bovino) — Proibido ou restrito em: UE, Canadá, Austrália, Japão | Brasil: PERMITIDO — Alterações hormonais, IGF-1 elevado
- Azodicarbonamida (AZO) — Proibido ou restrito em: UE, Reino Unido, Austrália | Brasil: PERMITIDO — Formação de compostos oxidativos
- BHA (E320) — Proibido ou restrito em: Japão, alguns países da UE | Brasil: PERMITIDO — Possível carcinogênio, estresse oxidativo
- Corantes artificiais (vários) — Proibido ou restrito em: Restrições na UE (alerta obrigatório) | Brasil: PERMITIDO — Hiperatividade em crianças
- Propil Galato — Proibido ou restrito em: Restrições em partes da UE | Brasil: PERMITIDO — Possíveis efeitos hormonais
- BPA em embalagens — Proibido ou restrito em: UE baniu em contato com alimentos | Brasil: PERMITIDO — Disrupção endócrina, neurológico
- Sacarina — Proibido ou restrito em: Restrições históricas em vários países | Brasil: PERMITIDO — Discussões sobre fígado e rins (animais)

## GUIA COMPLETO POR CATEGORIA

A seguir, as principais categorias de aditivos, seus nomes, onde encontrar e os riscos discutidos na literatura científica.

- FUNDO VERDE = Geralmente seguro
- FUNDO AMARELO = Atenção / contexto
- FUNDO VERMELHO = Evitar / preocupante

CONSERVANTES

BHT / BHA (E320 / E321) — Cereais, salgadinhos, carnes processadas, embalagens — Estresse oxidativo, possível carcinogênico em altas doses; NIH classifica como "razoavelmente carcinogênico"
TBHQ (E319) — Cereais matinais, fast food, biscoitos — Potencial toxicidade, possível carcinógeno
Propionato de Cálcio (E282) — Pães, bolos industriais, tortilhas — Possíveis alterações comportamentais em crianças suscetíveis, úlceras gástricas
EDTA (E385) — Maionese, molhos, enlatados, refrigerantes — Interferência no equilíbrio de minerais, problemas renais em excesso
Fosfatos adicionados (E338–E452) — Embutidos, queijos processados, frios, carnes — Impactos no metabolismo mineral e saúde renal, especialmente em nefropatas
Propil Galato (E310) — Balas, refrigerantes, óleos, gorduras — Possíveis efeitos hormonais e irritativos, dermatite de contato
Nitrito de Sódio (E250) — Bacon, presunto, salsicha, linguiça, mortadela — Formação de nitrosaminas (potencialmente cancerígenas); associado a câncer colorretal
Benzoato de Sódio (E211) — Refrigerantes, molhos, picles, sucos industriais — Efeitos oxidativos, possível impacto comportamental; combina com Vitamina C formando benzeno
Parabenos (propilparabeno) (E216) — Alimentos processados, sucos, adoçantes — Possíveis alterações hormonais (disruptor endócrino)
Ácido Sórbico / Sorbato de Potássio (E200 / E202) — Queijos, iogurtes, vinhos, sucos, embutidos — Considerado dos conservantes mais seguros; inibidor de fungos. Pode causar reações em indivíduos sensíveis
Ácido Cítrico (E330) — Conservas, sucos, refrigerantes, azeitonas em lata — Geralmente seguro. Versões industriais derivadas de milho podem conter traços de MSG. Erosão dentária em excesso
Ácido Láctico (E270) — Picles, laticínios fermentados, embutidos, pães — Produzido por fermentação — geralmente seguro. Pode irritar trato digestivo em sensíveis em grandes quantidades
Sorbato de Cálcio (E203) — Queijos processados, produtos de panificação — Perfil similar ao sorbato de potássio — considerado seguro nas doses aprovadas
Nitrato de Potássio (E252) — Bacon, presunto, salames, carnes curadas tradicionais — Similar ao nitrito de sódio; risco de formação de nitrosaminas em alta temperatura sem vitamina C
Sulfitos / Dióxido de Enxofre (E220–E228) — Vinhos, frutas secas, sucos, crustáceos, vinagre — Proibido em alguns países para crianças; pode desencadear crises asmáticas e reações alérgicas graves
Gluconato Ferroso (E579) — Azeitonas pretas em lata (para manter cor) — Geralmente seguro nas quantidades usadas como corante; pode alterar sabor em excesso
Cloreto de Cálcio (E509) — Picles, conservas de tomate, queijos — Essencialmente sal sem sódio — considerado seguro como conservante
Nisina (E234) — Queijos processados, carnes enlatadas — Antibiótico natural produzido por bactérias; pode impactar microbiota intestinal em exposição frequente

ADOÇANTES ARTIFICIAIS

Aspartame (NutraSweet, Equal) — Refrigerantes diet, gomas, iogurtes light — Discussões sobre sintomas neurológicos, sensibilidade individual; IARC classificou como "possível carcinogênico" (2023)
Sucralose (Splenda) — Refrigerantes, adoçantes, alimentos diet — Possível impacto negativo na microbiota intestinal
Sacarina (Sweet'N Low) — Alimentos diet, refrigerantes, balas — Discussões sobre metabolismo, fígado e rins em estudos animais
Acessulfame K (Ace-K) — Bebidas energéticas, alimentos diet combinados — Possíveis alterações neurológicas e cognitivas em estudos preliminares

INGREDIENTES QUE SE ESCONDEM NOS RÓTULOS

A indústria usa nomes técnicos e científicos para que o consumidor não reconheça que está consumindo, na prática, açúcar com outro nome. Esses ingredientes aparecem frequentemente em produtos rotulados como "diet", "zero", "sem açúcar" ou "natural" — e são mais problemáticos do que o açúcar comum em alguns aspectos.

Maltodextrina (Amido de milho ultraprocessado) — Adoçantes em pó, suplementos, proteínas, produtos diet, temperos, snacks — IG entre 95 e 136 — maior que o açúcar comum (65). Eleva glicemia rapidamente. Está em adoçantes "sem açúcar" como base da fórmula
Dextrose (Glicose pura (açúcar)) — Energéticos, suplementos, pães, embutidos, balas, cereais — É literalmente glicose — o mesmo açúcar que eleva insulina. Nome técnico usado para não aparecer como "açúcar" na lista
Amido modificado (Carboidrato processado quimicamente) — Iogurtes, molhos, sopas prontas, nuggets, embutidos, snacks — Aumenta a carga glicêmica, pode impactar microbiota. Usado para textura e volume sem declarar "açúcar"
Xarope de glicose (Açúcar líquido concentrado) — Balas, achocolatados, biscoitos, barras de cereal, sorvetes — Açúcar de alta absorção. Aparece depois do "açúcar" na lista para parecer menor, ou separado para iludir sobre quantidade total
Xarope de milho rico em frutose (HFCS) (Frutose industrial concentrada) — Refrigerantes, ketchup, molhos, pães de forma, cereais matinais — Frutose em excesso sobrecarrega o fígado, estimula produção de gordura hepática e não suprime a grelina (hormônio da fome)
Isomalte / Sorbitol / Xilitol (Alcoóis de açúcar (polióis)) — Balas "zero açúcar", chocolates diet, gomas sem açúcar — Parcialmente absorvidos — têm calorias e causam desconforto intestinal em doses maiores. Xilitol é tóxico para cães

Atenção especial: a maltodextrina no adoçante em pó
A maioria dos adoçantes em sachê ou pó — mesmo os rotulados como "zero caloria" — usam maltodextrina como base para dar volume e fluidez ao produto. Uma colher de adoçante em pó pode conter mais carboidrato de rápida absorção do que uma colher de açúcar comum, com índice glicêmico superior.

EMULSIFICANTES

- Polissorbato 80 (E433) — Sorvetes, molhos, pães, cosméticos — Alterações na microbiota e aumento da permeabilidade intestinal (estudos animais)
- Polissorbato 60 e 65 (E435/E436) — Produtos de padaria, margarina, sorvetes — Possíveis impactos digestivos e intestinais
- Carboximetilcelulose (E466) — Sorvetes, molhos, queijos processados — Possível desequilíbrio intestinal em indivíduos suscetíveis
- Carragenina (E407) — Leite de coco, bebidas vegetais, frios — Discussões sobre irritação intestinal e inflamação, especialmente a forma degradada
- Lecitina de Soja / Girassol (E322) — Chocolates, margarinas, pães, biscoitos, suplementos — Geralmente seguro. Versão de soja pode ser problemática para alérgicos à soja; prefira lecitina de girassol
- Goma Arábica (E414) — Balas, refrigerantes, coberturas, gomas de mascar — Fibra solúvel natural de origem vegetal.
- Pectina (E440) — Geleias, iogurtes, sucos, doces — Fibra natural extraída de frutas.
- Goma Guar (E412) — Sorvetes, iogurtes, molhos, produtos sem glúten — Fibra solúvel; geralmente segura. Em excesso pode causar distensão e gases em pessoas sensíveis
- Goma Xantana (E415) — Produtos sem glúten, molhos, sorvetes, laticínios — Produzida por fermentação bacteriana; geralmente segura. Pode causar distúrbios digestivos em doses elevadas
- Mono e Diglicerídeos de Ácidos Graxos (E471) — Pães, margarinas, sorvetes, produtos industriais — Derivados de gorduras — podem conter gorduras trans; qualidade depende da matéria-prima utilizada

CORANTES ALIMENTARES

- Vermelho 40 (Allura Red) (E129) — Balas, refrigerantes, cereais, sorvetes — Exige alerta na UE: "pode ter efeito negativo na atividade e atenção em crianças"
- Vermelho 3 (Eritrosina) (E127) — Cerejas em calda, balas, sorvetes — Banido para alguns usos pela FDA nos EUA; possível interferência tireoidiana
- Amarelo 5 (Tartrazina) (E102) — Sucos, balas, macarrão instantâneo — Exige alerta na UE; associado a reações alérgicas e hiperatividade em crianças
- Amarelo 6 (Sunset Yellow) (E110) — Balas, refrigerantes, snacks — Exige alerta na UE; possíveis reações comportamentais em crianças suscetíveis
- Azul 1 (Brilliant Blue) (E133) — Balas, geleias, bebidas energéticas — Possíveis alterações comportamentais; restrições em alguns países
- Azul 2 (Indigotina) (E132) — Bebidas, balas, sorvetes — Possíveis reações em indivíduos alérgicos
- Verde 3 (Fast Green) (E143) — Balas, geleias, enlatados decorativos — Banido na UE; discussões sobre genotoxicidade
- Urucum (Bixina) (E160b) — Manteiga, queijo, margarinas, snacks — Corante natural derivado da semente de urucum; geralmente seguro, pode causar reações alérgicas em sensíveis
- Corante Caramelo (Classe IV) (E150d) — Refrigerantes de cola, cervejas escuras, molhos — Classe IV usa amônia e sulfitos no processo; subproduto 4-MEI classificado como possível carcinogênico pela IARC
- Dióxido de Titânio (E171) — Balas, chicletes, coberturas brancas, suplementos — Banido na UE desde 2022; nanopartículas com possível genotoxicidade e impacto na microbiota intestinal
- Curcumina / Cúrcuma (E100) — Mostarda, queijos, margarina, suplementos — Corante natural com propriedades anti-inflamatórias documentadas — considerado seguro.
- Riboflavina (Vitamina B2) (E101) — Laticínios, cereais, bebidas energéticas — Vitamina essencial usada como corante amarelo.
- Clorofila / Clorofilina (E140/E141) — Bebidas verdes, gomas, doces naturais — Corante natural derivado de plantas; geralmente seguro

AROMATIZANTES E REALÇADORES DE SABOR

- Glutamato Monossódico (MSG) (E621) — Temperos, salgadinhos, macarrão instantâneo, fast food — Sensibilidade individual, dores de cabeça e desconfortos em algumas pessoas ("síndrome do restaurante chinês")
- Aromatizantes artificiais (Vários) — Praticamente todos os ultraprocessados — Compostos pouco transparentes na rotulagem; aumentam hiperpalatabilidade alimentar
- Extrato de Levedura Autolisada — Caldos industriais, sopas prontas, temperos — Contém glutamato naturalmente — mesmos efeitos do MSG em sensíveis. Usado para evitar declarar 'MSG' no rótulo
- Diacetil — Manteiga artificial, pipoca de micro-ondas, margarinas — Associado à doença pulmonar grave em exposição ocupacional; em consumo alimentar o risco é menor mas discutido
- Acetato de Isoamila (sabor banana artificial) — Balas, refrigerantes e sucos artificiais — Composto sintético; pouco estudado em longo prazo; aumenta hiperpalatabilidade em ultraprocessados

PLASTIFICANTES E EMBALAGENS

- BPA (Bisfenol A) — Embalagens plásticas, latas / Enlatados, plástico policarbonato, recibos térmicos — Banido na UE para uso em alimentos; possíveis efeitos hormonais, neurológicos e metabólicos
- PFOAs (PFAS) — Embalagens antiaderentes / Microondas, embalagens antimancha, utensílios antiaderentes — Alterações hormonais, colesterol elevado, possíveis impactos cardiovasculares; proibido em muitos países
- Azodicarbonamida (AZO) — Agente branqueador/madurador / Pães industriais, tortilhas, pãezinhos de fast food — Banido na UE e Austrália; formação de compostos oxidativos e radicais livres
- Ftalatos — Plastificantes / Embalagens flexíveis, filmes plásticos, PVC em contato com alimento — Disrupção endócrina, possível impacto reprodutivo; restrições crescentes em vários países

GOMAS E ESPESSANTES

- Amido de Milho Modificado (E1400-E1450) — Sopas, molhos, iogurtes, produtos light — Carboidrato ultraprocessado; aumenta carga glicêmica; usado para textura sem declarar 'açúcar'
- Carboximetilcelulose (CMC) (E466) — Sorvetes, bebidas, queijos processados, suplementos — Estudos em camundongos mostraram promoção de colite e síndrome metabólica; impacto na microbiota documentado
- Metilcelulose (E461) — Produtos light, substitutos de gordura — Fibra sintética; pode causar distúrbios gastrointestinais em doses altas
- Hidroxipropilmetilcelulose (HPMC) (E464) — Cápsulas de suplementos, produtos sem glúten — Considerado seguro nas doses aprovadas; pouco absorvido pelo organismo
- Agar-Agar (E406) — Sobremesas, gelatinas vegetais, sorvetes — Derivado de algas marinhas (planta); considerado seguro. Em alguns protocolos de cura intestinal (ex: protocolo GAPS) é evitado por poder alimentar bactérias indesejadas em intestinos comprometidos
- Gelatina / Colágeno (-) — Sobremesas, gummies, suplementos, gelatinas — Proteína animal — segura e nutritiva; fonte de glicina e prolina

ACIDULANTES E REGULADORES DE ACIDEZ

- Ácido Fosfórico (E338) — Refrigerantes de cola, bebidas energéticas — Associado à erosão dentária, redução de densidade óssea (interfere na absorção de cálcio) e disfunção renal em excesso
- Ácido Tartárico (E334) — Vinhos, sucos, balas, produtos de panificação — Natural nas uvas; geralmente seguro nas quantidades alimentares
- Ácido Málico (E296) — Refrigerantes, balas azedas, sucos artificiais — Natural nas maçãs; seguro em doses normais; versão sintética usada em excesso em balas azedas pode irritar mucosa
- Carbonato de Sódio / Bicarbonato (E500) — Pães, biscoitos, produtos de panificação — Seguro — fermento químico tradicional sem riscos documentados nas doses alimentares
- Fosfato Dissódico (E339) — Queijos processados, carnes, refrigerantes — Faz parte do grupo dos fosfatos adicionados; em excesso impacta metabolismo mineral e saúde renal
- Sulfato de Cálcio (E516) — Tofu, farinha de trigo, conservas — Usado como coagulante no tofu; geralmente seguro nas quantidades alimentares

O INTESTINO: ONDE TUDO COMEÇA

Contexto importa em saúde — isso é verdade. Dose, frequência, qualidade geral da dieta e estilo de vida fazem diferença real. Mas existe um ponto que não pode ser relativizado: a exposição crônica e diária a conservantes e aditivos alimentares tem evidência científica crescente de impacto direto sobre o intestino.

E o intestino não é apenas um órgão digestivo. Ele é o centro de regulação imunológica, metabólica e neurológica do corpo. Quando ele é comprometido, as consequências aparecem em lugares que parecem não ter relação: pele, humor, imunidade, peso, hormônios.

70% do sistema imunológico está no intestino
Ele abriga mais de 100 trilhões de micro-organismos e produz cerca de 90% da serotonina do corpo. Comprometer o intestino é comprometer o organismo como um todo.

O que a ciência mostra sobre aditivos e intestino

Revisões publicadas em revistas como Nature Reviews Gastroenterology (2024) e FASEB Journal (2025) apontam um padrão consistente: a exposição a determinados aditivos alimentares afeta o intestino por múltiplas vias. Os mecanismos mais documentados são:

- Alteração da microbiota — Emulsionantes (Polissorbato 80, CMC), adoçantes artificiais, corantes azo — Redução da diversidade bacteriana, proliferação de bactérias pró-inflamatórias, disbiose
- Aumento da permeabilidade intestinal — Carragenina, emulsionantes, corantes artificiais, açúcar em excesso, nanopartículas — Leaky gut: passagem de fragmentos bacterianos para a corrente sanguínea, ativando resposta inflamatória sistêmica
- Redução da camada de muco intestinal — Polissorbato 80, carboximetilcelulose (CMC), detergentes alimentares — A camada de muco é a primeira linha de defesa do intestino; sua redução aumenta contato direto de bactérias com o epitélio
- Resposta imune anormal — Corantes azo, conservantes como benzoato, adoçantes artificiais — Ativação inflamatória crônica, exacerbação de DII, colite, síndrome do intestino irritável

O efeito cascata: quando o intestino adoece, o corpo responde

- Disbiose intestinal — Desequilíbrio da flora, redução de bactérias protetoras — Obesidade, diabetes tipo 2, ansiedade, depressão
- Permeabilidade aumentada (leaky gut) — Endotoxinas entram na corrente sanguínea, ativando inflamação sistêmica — Doenças autoimunes, artrite, doenças de pele, fadiga crônica
- Inflamação intestinal crônica — Ativação imune contínua, estresse oxidativo local — DII, colite ulcerativa, Crohn, síndrome do intestino irritável, câncer colorretal
- Eixo intestino-cérebro comprometido — Redução de serotonina intestinal, sinalização vagal alterada — Ansiedade, depressão, névoa mental, distúrbios do sono

Contexto importa — mas exposição crônica também importa
Um aditivo isolado, em uma dose ocasional, provavelmente não causa dano significativo. O problema real é o padrão moderno de alimentação: dezenas de aditivos diferentes, todos os dias, ao longo de anos. A exposição cumulativa e crônica é o que a ciência está investigando — e os sinais de alerta intestinal são consistentes.
Priorizar alimentos in natura não é perfeccionismo alimentar. É proteger o intestino — que protege todo o resto.

O QUE FAZER COM ESSA INFORMAÇÃO?

Estratégia prática para reduzir exposição

A boa notícia é que você não precisa decorar todos esses nomes ou viver lendo rótulos com ansiedade. Existe uma estratégia simples e eficaz:

• Priorize alimentos in natura
• Dietas baseadas em comida de verdade (como low carb e carnívora) naturalmente eliminam a maioria dos aditivos

• Quando comprar industrializados, prefira os de lista de ingredientes curta e reconhecível
• Fuja de produtos com corantes artificiais, especialmente se houver crianças na família
• Evite embalagens plásticas em contato com alimentos quentes — use vidro ou inox
• Prefira bacon, linguiça e embutidos sem nitrito adicionado (existem versões no mercado)

### A dieta carnívora e o low carb têm uma vantagem prática:
Um pedaço de carne in natura não precisa de marketing, corante ou uma composição química extensa no rótulo. Isso reduz não apenas a ingestão de aditivos industriais, mas também a fadiga mental de tentar decifrar ingredientes que muitas pessoas nem conhecem.

## NITRITO E NITRATO: A VERDADE QUE POUCOS CONTAM

Nitrito e nitrato são compostos que aparecem com frequência nas discussões sobre carnes processadas. Bacon, presunto e embutidos levam a fama. Mas existe um dado que muda completamente a perspectiva: a maior fonte de nitrato na dieta humana não é o bacon — são os vegetais.

### Nitrato por 100g: vegetais vs. bacon

* Aipo (salsão) (~2.400 mg) — Vegetal — rico em vitamina C e antioxidantes
* Espinafre (~1.900 mg) — Vegetal — rico em vitamina C e antioxidantes
* Rúcula (~4.800 mg) — Vegetal — maior teor de nitrato entre folhas
* Bacon (curado) (~50-100 mg) — Nitrito adicionado — sem vitamina C natural presente

### A diferença não está na quantidade de nitrato — está no contexto
O bacon não é o maior fornecedor de nitrato na dieta. O que o diferencia dos vegetais é o ambiente em que o nitrato/nitrito age: sem vitamina C, sem antioxidantes, em presença de proteínas animais e sob alta temperatura — as condições ideais para a formação de nitrosaminas.

---

## O papel da Vitamina C — e por que ela muda tudo

### Nos Vegetais — Cenário Seguro
Os vegetais vêm acompanhados de altas doses de vitamina C, antioxidantes e fibras. Quando você ingere, a vitamina C bloqueia ativamente a transformação do nitrato em substâncias nocivas.

Em vez disso, seu corpo converte o nitrato em óxido nítrico — um composto benéfico que relaxa as artérias, melhora a circulação e reduz a pressão arterial.

### No Bacon — Cenário de Risco
O bacon possui proteínas (aminas) e gorduras, mas quase nenhuma vitamina C. Sob altas temperaturas na frigideira, o nitrito reage com essas proteínas e forma compostos chamados nitrosaminas.

Essas substâncias são classificadas pela OMS como potencialmente cancerígenas — especialmente quando o bacon é frito até queimar.

---

## E a vitamina C adicionada ao bacon?

A boa notícia é que muitos bacons encontrados nos mercados hoje já vêm com vitamina C (ácido ascórbico ou eritorbato de sódio) adicionada na formulação. A indústria faz isso exatamente para inibir a formação de nitrosaminas durante o processamento e o preparo.

### O bom não é inimigo do ótimo
O ideal é optar por bacon sem nitrito adicionado — versões "naturais" ou curadas apenas com sal já existem no mercado. Mas se o que você tem acesso é um bacon convencional com vitamina C na formulação, isso já é significativamente melhor do que ignorar o assunto. Perfeição não precisa ser o inimigo do progresso alimentar.

---

## Como reduzir o risco na cozinha

Se você gosta de bacon e quer consumi-lo com mais segurança, a dica prática mais importante é: não fritar o bacon até queimar ou escurecer. É na tostagem excessiva que as nitrosaminas se formam em maior quantidade.

### Evitar
* Fritar em fogo alto até dourar escuro / queimar
* Bacon sem nenhum tipo de vitamina C no rótulo
* Consumo diário e em grande quantidade

### Preferível
* Assar no forno em temperatura média ou no micro-ondas
* Bacon com ácido ascórbico / eritorbato de sódio no rótulo
* Bacon curado apenas com sal (sem nitrito adicionado) — opção ótima

---

## Bacon sem vitamina C na embalagem vai me fazer mal?

Não. A ausência de vitamina C adicionada não transforma o bacon em veneno. O risco de formação de nitrosaminas existe em condições específicas — principalmente quando o bacon é frito até queimar em alta temperatura. Fora desse cenário, o corpo possui mecanismos próprios de proteção, incluindo a vitamina C que o próprio organismo bombeia para o estômago.

O que determina o risco real não é um ingrediente isolado — é a dose, a frequência e o contexto geral da dieta. Quem come bacon ocasionalmente, sem queimar, dentro de uma dieta baseada em comida de verdade, não tem motivo de preocupação. O bacon é um alimento de origem animal — não é um ultraprocessado químico.

Melhor ainda se vier sem nitrito adicionado — mas a ausência desse detalhe no rótulo não é motivo para renunciar a um alimento nutritivo e saboroso. O perfeito não pode ser inimigo do bom.

---

## Para deixar ainda mais claro: dados que mudam a perspectiva

### 5,5x mais nitrato dos vegetais do que das carnes curadas
Estudo com italianos mostrou que vegetais forneceram 5,5 vezes mais nitrato e nitrito do que toda a carne processada consumida — mas ninguém criminaliza o espinafre.

### Quanto de nitrosamina realmente causa danos? O caso dos 300mg
Em 1977, uma mulher foi hospitalizada com insuficiência hepática grave. Investigando, os médicos descobriram que ela havia sido envenenada pelo marido com amoras contaminadas — que continham 300 miligramas de nitrosamina (NDMA). O marido foi condenado por tentativa de homicídio.

Por que isso importa? Porque as nitrosaminas são tóxicas, sim — mas a dose faz o veneno. A quantidade presente em alguns fios de bacon ocasionais é incomparável com a dose utilizada em uma tentativa de assassinato. Contextualizar dose é essencial para não tratar bacon como arma química.

### O que um estudo com ratos e câncer de cólon revelou sobre o bacon

Pesquisadores injetaram em ratos azoximetano, um composto conhecido por causar câncer de cólon, e então os alimentaram com bacon para observar se a carne processada agravaria o quadro.

O resultado foi o oposto do esperado: o bacon não apenas não causou câncer — ele reduziu consistentemente o número de lesões pré-cancerígenas nos ratos. Trata-se de um único estudo — e ciência não se faz com um só estudo — mas o dado é relevante para mostrar que a relação entre bacon e câncer é muito menos direta do que manchetes sugerem.

📌 Cuidado com o marketing: "sem nitrato adicionado" pode ser enganoso
O suco de aipo possui concentrações tão altas de nitrato que a indústria o usa como ingrediente em produtos rotulados como "sem nitrato ou nitrito adicionado". Na prática, o nitrato continua lá — só veio de uma fonte vegetal com outro nome no rótulo.
Senso crítico alimentar também significa não cair em marketing de saúde que usa palavras como "natural" e "sem aditivos" enquanto faz essencialmente a mesma coisa com outros ingredientes.

# A QUÍMICA QUE DERRUBA O MITO

Baseado no artigo do Dr. Mark JS Miller, PhD, MBA — bioquímico com publicações no American Journal of Physiology e outras revistas científicas

Existe um equívoco persistente de que nitrato e nitrito na dieta causam câncer pela formação de nitrosaminas. Essa ideia surgiu de interpretações incorretas feitas décadas atrás, antes de entendermos a produção endógena de óxido nítrico e das espécies reativas de nitrogênio.

O Dr. Miller explica, com base em química básica e fisiologia humana, por que nitrato e nitrito alimentares não podem ser tratados como "causadores diretos de câncer".

## 1. A equação química simplesmente não fecha

Para formar uma nitrosamina, você precisa de um grupo nitroso com carga positiva (NO⁺). O nitrito (NO₂⁻) tem carga negativa, um oxigênio a mais e não atua diretamente como espécie nitrosante. A reação não se equilibra — é química básica. Sem equilíbrio de cargas, a reação não acontece. Ou seja, o nitrito NÃO forma nitrosaminas diretamente.

Para isso acontecer, ele precisaria antes ser convertido em outras espécies reativas de nitrogênio, como: NO⁺, N₂O₃ e NO₂.

✅ **Reação que FUNCIONA**
R–NH₂ + NO⁺ → R–NHNO + H⁺
Amina – Nitrosonium – Nitrosamina
Cargas balanceadas ✓

❌ **Reação que NÃO funciona**
R–NH₂ + NO₂⁻ → ???
Amina – Nitrito — equação desequilibrada
Cargas incompatíveis ❌

O ponto central do Dr. Miller é:
a simples presença de nitrato ou nitrito na dieta não significa formação automática de nitrosaminas.

## 2. Se o nitrito causasse câncer, a sua saliva seria cancerígena

O corpo tem um ciclo natural e constante: nitrato do plasma é bombeado para a saliva, convertido em nitrito por bactérias bucais, deglutido e transformado em óxido nítrico conforme a necessidade. Os níveis de nitrito na saliva excedem substancialmente o limite máximo de nitrito permitido na água potável pela EPA (Agência de Proteção Ambiental dos EUA).

Se o nitrito fosse o agente causador de câncer, nossa própria saliva seria classificada como cancerígena — e estaríamos todos com câncer gástrico. O Dr. Miller faz a pergunta diretamente: "Isso significa que precisamos proibir a saliva?"

## 3. A própria IARC contradiz a IARC

Se nitrato alimentar fosse um grande causador de câncer, dietas mais ricas em nitrato deveriam apresentar maiores taxas de câncer.

Mas ocorre o contrário.

Em seu próprio relatório de 2006, a Agência Internacional de Pesquisa sobre o Câncer (IARC) — a mesma que classifica carnes processadas como cancerígenas — reconheceu que os estudos epidemiológicos mostravam uma relação inversa entre nitrato na dieta e câncer.

O que se esperava encontrar:
Mais nitrato na dieta
↓
Mais câncer

O que a epidemiologia mostrou:
Mais nitrato na dieta
↓
MENOS câncer

A IARC atribuiu os resultados protetores aos "benefícios das frutas e verduras", manteve sua recomendação teórica — e as manchetes continuaram repetindo o mito. Como o próprio Dr. Miller conclui: "Essas imprecisões geram mais leituras, cliques e vendas."

## 4. O verdadeiro problema: inflamação crônica e produção excessiva de NO pela iNOS

O Dr. Miller argumenta que o principal mecanismo associado à formação de espécies nitrogenadas potencialmente danosas NÃO é o nitrato alimentar.

O problema ocorre principalmente em estados de:
• inflamação crônica,
• ativação imune,
• infecções persistentes.

Nessas situações, a enzima iNOS produz enormes quantidades de óxido nítrico, favorecendo a formação de espécies reativas de nitrogênio capazes de causar dano celular.

Um exemplo clássico é a infecção por Helicobacter pylori.

Segundo o autor:
o câncer gástrico relacionado ao H. pylori decorre da inflamação persistente e da resposta imune exagerada — não do nitrato ingerido na dieta.

## 5. O seu corpo já se protege — com uma bomba de vitamina C

📌 O corpo tem um mecanismo ativo de defesa contra nitrosaminas
Existe uma bomba ativa no organismo que transporta vitamina C do plasma diretamente para o interior do estômago. Ela age exatamente onde a preocupação com nitrosaminas existe — no meio ácido gástrico. Sua função: inibir as reações de nitrosação antes que elas aconteçam.
O Dr. Miller e sua equipe demonstraram que a suplementação com vitamina C suprimiu as impressões químicas de nitrosação no estômago de pacientes com Helicobacter pylori — e o processo cancerígeno foi revertido.
O verdadeiro vilão era a resposta inflamatória crônica à bactéria, não o nitrato ou nitrito ingerido. Isso reforça outro ponto importante: o contexto biológico importa muito mais do que demonizar nitrato ou nitrito isoladamente.

**Conclusão do Dr. Miller**
"Devemos deixar de lado os riscos hipotéticos da ingestão de nitrato/nitrito e o câncer. Na verdade, estamos prestando um desserviço à comunidade ao não promovermos dietas ricas em nitrato/nitrito para a saúde cardiovascular e o bem-estar em geral."
— Dr. Mark JS Miller, PhD, MBA

AVISO IMPORTANTE

Este material é de caráter educativo e foi desenvolvido como um guia de consulta para auxiliar na leitura de rótulos e na compreensão dos principais aditivos e conservantes alimentares.

As informações aqui apresentadas são baseadas em estudos, revisões científicas e regulamentações disponíveis até a data de produção deste conteúdo. Regulamentações alimentares estão em constante atualização — substâncias permitidas hoje podem ser restringidas ou proibidas futuramente, assim como o status de proibição em outros países pode mudar conforme novas evidências científicas surgem e pressões regulatórias avançam.

Choi HJ, Kim J, Park SH, Do KH, Yang H, Moon Y. Pro-inflammatory NF-κB and early growth response gene 1 regulate epithelial barrier disruption by food additive carrageenan in human intestinal epithelial cells. Toxicol Lett. 2012 Jun 20;211(3):289-95. doi: 10.1016/j.toxlet.2012.04.012. Epub 2012 Apr 26. PMID: 22581171.

Palli D, Russo A, Decarli A. Dietary patterns, nutrient intake and gastric cancer in a high-risk area of Italy. Cancer Causes Control. 2001; 12:163– 172.

Lerner A, Matthias T. Changes in intestinal tight junction permeability associated with industrial food additives explain the rising incidence of autoimmune disease. Autoimmun Rev. 2015 Jun;14(6):479-89. doi: 10.1016/j.autrev.2015.01.009. Epub 2015 Feb 9. PMID: 25676324.

Espejo-Herrera N, Gracia-Lavedan E, Pollan M, Aragonés N, Boldo E, Perez-Gomez B, Altzibar JM, Amiano P, Zabala AJ, Ardanaz E, Guevara M, Molina AJ, Barrio JP, Gómez-Acebo I, Tardón A, Peiró R, Chirlaque MD, Palau M, Muñoz M, Font-Ribera L, Castaño-Vinyals G, Kogevinas M, Villanueva CM. Ingested Nitrate and Breast Cancer in the Spanish Multicase-Control Study on Cancer (MCC-Spain). Environ Health Perspect. 2016 Jul;124(7):1042-9. doi: 10.1289/ehp.1510334. Epub 2016 Mar 4. PMID: 26942716; PMCID: PMC4937871.

O'Connor HJ, Schorah CJ, Habibzedah N, Axon AT, Cockel R. Vitamin C in the human stomach: relation to gastric pH, gastroduodenal disease, and possible sources. Gut. 1989 Apr;30(4):436-42. doi: 10.1136/gut.30.4.436. PMID: 2714677; PMCID: PMC1434036.

Ahluwalia A, Gladwin M, Coleman GD, Hord N, Howard G, Kim-Shapiro DB, Lajous M, Larsen FJ, Lefer DJ, McClure LA, Nolan BT, Pluta R, Schechter A, Wang CY, Ward MH, Harman JL. Dietary Nitrate and the Epidemiology of Cardiovascular Disease: Report From a National Heart, Lung, and Blood Institute Workshop. J Am Heart Assoc. 2016 Jul 6;5(7):e003402. doi: 10.1161/JAHA.116.003402. PMID: 27385425; PMCID: PMC5015377.
