# Curso Introdução à Carnívora: Bloco 5 (antes de iniciar, como começar, o que comer e evitar)

Bloco 5 - Antes de Iniciar
Bloco 5 - Antes de Iniciar 
5.1 Intro e Regras
Seja você alguém que veio direto do Módulo 1 ou alguém que assistiu todos os últimos módulos, o mais importante é que agora você está pronto para começar. Então, vamos direto ao que interessa: como iniciar a dieta carnívora da forma correta.
Se eu tivesse que explicar isso para um cachorro, seria bem simples: “Aqui, coma isso.” Pronto, ele comeria e viveria feliz. Mas nós, humanos, gostamos de complicar as coisas. Queremos regras, números, cálculos, estratégias… E, honestamente, muitas dessas preocupações são desnecessárias.
Se eu tivesse que explicar a dieta carnívora para você da forma mais direta possível, diria algo como: "Apenas coma um belo pedaço de carne. Repita quando estiver com fome." Na verdade, eu poderia resumir todo esse curso com essa única frase, mas sei que a maioria das pessoas gosta de um pouco mais de explicação. Então, vamos aos detalhes.
A verdade é que a dieta carnívora não exige contagem de calorias, controle rigoroso de macros ou monitoramento diário de exames. Se uma dieta precisa de um manual de instruções complexo para funcionar, então ela provavelmente não é sustentável a longo prazo.
Outro erro comum é achar que a carnívora é apenas uma "dieta para emagrecer". Sim, muitas pessoas perdem peso, mas esse não é o foco principal. O objetivo real é nutrir seu corpo da melhor forma possível, e a consequência disso é mais saúde, mais energia e um corpo funcionando de forma otimizada.
Se o seu único objetivo é perder peso o mais rápido possível, existem estratégias que podem ser mais eficazes. Mas se você quer melhorar sua saúde de verdade—e manter esses benefícios para o resto da vida—então a dieta carnívora pode ser exatamente o que você precisa.
Vamos as minhas regras:
0. Saiba o seu porquê
Antes de qualquer coisa, você precisa ter clareza sobre o motivo pelo qual está iniciando a dieta carnívora. Pode ser para melhorar sua saúde, ter mais energia, perder peso, aliviar sintomas de doenças autoimunes ou até simplesmente testar algo novo. Não importa qual seja o motivo—ele precisa estar forte na sua mente.
Mudar sua alimentação pode ser desafiador nos primeiros dias. Seu corpo pode passar por um período de adaptação, você pode sentir vontade de comer certos alimentos que faziam parte da sua rotina, e algumas pessoas ao seu redor podem até questionar sua decisão. Se você não tiver um motivo claro, qualquer dificuldade pode fazer você desistir.
E aqui está a verdade: quem começa a dieta carnívora só para "ver como é" ou porque um amigo falou dificilmente dura muito tempo. O mundo ao seu redor não vai facilitar sua jornada. Vai ter festa, vai ter pizza, vai ter gente te oferecendo bebida, e todo mundo vai ter uma opinião sobre o que você está fazendo. Se você não estiver 100% comprometido e souber exatamente o que quer, qualquer convite para "só uma fatia" ou "só um dia fora da dieta" pode te tirar do caminho.
Pense nisso como um contrato consigo mesmo. Por que você está fazendo isso? O que você quer alcançar? Ter essa resposta bem definida vai fazer toda a diferença quando você enfrentar desafios no caminho. Pense num número exato de dias e não quebre a promessa com você mesmo. Simples
 1. Um dia de cada vez
Quando você começa a dieta carnívora, não precisa pensar nisso como um compromisso para o resto da vida. Você não está assinando um contrato vitalício, nem entrando em uma corrida contra o tempo. Cada dia é uma nova oportunidade para aprender, ajustar e entender como seu corpo responde a essa mudança.
É normal sentir ansiedade no início. Muita gente entra já pensando: "E se eu não conseguir?" ou "E se eu sentir falta dos alimentos que costumava comer?". Mas a chave aqui é simples: foque no hoje. Não se preocupe com o mês que vem, o aniversário da sua tia ou a viagem de fim de ano. Apenas tome a decisão de fazer a dieta hoje. Amanhã, você decide novamente.
Outra coisa importante: cada pessoa tem uma experiência única. Algumas vão se adaptar rapidamente e sentir os benefícios já nos primeiros dias. Outras podem demorar algumas semanas para se sentir totalmente bem. Se você cometer algum erro, não significa que falhou. O aprendizado faz parte do processo. O importante é continuar.
Então, tire um pouco da pressão. Aproveite essa jornada como uma fase de descoberta sobre o que realmente funciona para você. Apenas foque no presente, e o resto se resolve naturalmente.
2. Aproveite o processo
Se alimentar bem não deveria ser um fardo. Uma das primeiras coisas que você precisa entender sobre a dieta carnívora é que ela não deve ser uma experiência de sofrimento.
Eu sempre falo para as pessoas contarem quantas refeições elas realmente gostam depois de começarem a carnívora. Se a resposta for poucas ou nenhuma, tem algo errado. Você precisa curtir o que está comendo, porque ninguém sustenta uma dieta a longo prazo se não sente prazer nela.
E a boa notícia? Carne é deliciosa! Existem infinitas maneiras de prepará-la. Você pode grelhar, assar, fritar, fazer na manteiga, na brasa, no sous-vide... Existem centenas de cortes e texturas diferentes, cada um com um sabor único.
Aproveite para explorar novas possibilidades! Experimente diferentes tipos de carne, veja quais cortes você gosta mais e descubra o que funciona para você. Se quiser variar, pode incluir ovos, queijos e até alguns temperos se sentir necessidade.
Se você está acostumado com muitas variedades de comida e acha que vai sentir falta da "diversão" na alimentação, faça disso um desafio positivo. Aprenda novas formas de cozinhar carne, experimente cortes diferentes, teste a carne de outros animais além da bovina.
Quanto mais você aproveitar esse processo, mais fácil será tornar a carnívora parte natural da sua vida.
3. Coma o suficiente
A grande maioria das dificuldades que as pessoas enfrentam ao começar a dieta carnívora vem do simples fato de não comerem o suficiente.
Muita gente chega na carnívora com um histórico de dietas restritivas, contando calorias, pesando comida, tentando comer "o mínimo possível". Esse tipo de mentalidade vai te atrapalhar.
Se você não comer o suficiente, seu corpo vai sentir falta de energia, você vai ter vontade de beliscar, pode sentir fadiga, dores de cabeça e até dificuldade para se adaptar.
E eu preciso reforçar uma coisa: se você está com fome, coma! Parece óbvio, mas a maioria das pessoas ignora isso. A fome não é um inimigo, ela é um sinal biológico de que seu corpo precisa de nutrientes.
Pensa assim:
Se você está sem ar, você segura a respiração? Não. Você respira.
Se você está com sede, você evita beber água? Não. Você bebe.
Se você está com fome, faz sentido evitar comer? Claro que não!
Se você está comendo alimentos certos, não precisa controlar a quantidade. Seu corpo tem mecanismos naturais para regular o apetite quando você tira os carboidratos da equação. Você vai perceber que, depois de um tempo, seu próprio corpo te avisa quando já comeu o suficiente.
Quando você começa a carnívora, coma até estar satisfeito. Não tente limitar a quantidade de carne no prato. Principalmente no começo, seu corpo está se ajustando e precisa de energia.

4. Não faça comparações
Se tem algo que pode te atrapalhar no início da dieta carnívora, é ficar se comparando com os outros. Cada pessoa tem um metabolismo diferente, um histórico diferente e um ponto de partida diferente.
Algumas pessoas perdem peso rapidamente, outras demoram um pouco mais. Algumas veem melhora na energia e disposição em poucos dias, enquanto outras precisam de semanas para se ajustar. E está tudo bem.
Se você ficar preso na ideia de que precisa ter os mesmos resultados que fulano ou ciclano, vai acabar frustrado e pode até desistir antes de sentir os verdadeiros benefícios.
Pensa no seguinte:
O seu corpo é único. Ele tem um histórico de anos (ou décadas) lidando com diferentes tipos de alimentação, inflamações, estresse e outros fatores.
Seu progresso deve ser medido comparando você com você mesmo. Como você se sente hoje em relação a uma semana atrás? E em relação ao mês passado?
Aliás, um erro comum é medir o sucesso da dieta apenas pelo peso na balança. Mas se o seu objetivo é saúde, o peso não deveria ser sua única métrica.
Aqui o que importa de verdade:Como está sua energia? Seu sono melhorou? Você sente menos fome ao longo do dia? Seu humor está mais estável? Sua mente está mais clara? Suas roupas estão servindo melhor?  Suas dores ou inflamações diminuíram?
Se você se comparar apenas com outras pessoas, vai perder a chance de perceber todas as mudanças positivas que estão acontecendo no seu próprio corpo.
5. Você está comendo por você
Se tem algo que pode te atrapalhar logo no começo da dieta carnívora, é a pressão social.
Muitas vezes, as pessoas ao seu redor não vão entender sua decisão. Vão fazer piadas, tentar te convencer de que carne faz mal, ou até mesmo insistir para você "abrir uma exceção" porque é um aniversário, uma viagem, ou "só um pedaço não mata ninguém."
E é aqui que muita gente se perde. Não tente agradar os outros às custas da sua própria saúde.
Se alguém te perguntar por que você não está comendo arroz, pão ou sobremesa, sua resposta pode ser tão simples quanto: "Porque eu não quero.", ou “Porque estou fazendo um experimento”Você não precisa de longas explicações ou debates nutricionais.
E se vierem com aqueles argumentos clássicos:
"Mas de onde você tira suas fibras?"
"E as vitaminas?"
"Isso não pode ser saudável!"
A melhor resposta muitas vezes é um sorriso e uma mudança de assunto. Afinal, você não precisa convencer ninguém, só precisa focar no que funciona para você. Ou você pode assistir esse curso completo e vai ter todas as respostas na ponta da língua!
No final do dia, quem vai viver com os benefícios ou as consequências da sua alimentação é você. Se você quer realmente transformar sua saúde, precisa aprender a colocar suas prioridades em primeiro lugar.

6. Foque em se alimentar bem (e não em passar fome)
Nos últimos anos, o jejum intermitente virou moda. Você já deve ter ouvido falar de protocolos como comer apenas em uma janela de 8 horas ou até ficar 24 horas sem comer. O argumento por trás disso é que períodos sem comida ativam processos como a autofagia, onde o corpo recicla células danificadas e melhora a regeneração. Parece ótimo, certo?
Mas aqui vai um alerta: se você está começando a dieta carnívora, seu foco NÃO deve ser o jejum. Seu foco deve ser se alimentar bem.
Muita gente que inicia a dieta comete um erro clássico: não comer o suficiente. Isso acontece porque, ao cortar carboidratos, você naturalmente perde fome e sente menos compulsão alimentar. Mas se você não comer o suficiente, pode acabar com sintomas como fadiga, tontura, desejo repentino por açúcar ou junk food e até dificuldade para dormir.
E sabe o que acontece depois? Muita gente desiste da dieta achando que “não funcionou” para eles. Mas a verdade é que eles só não estavam comendo o suficiente.
Então aqui está a regra mais importante para o início da dieta carnívora: coma até ficar satisfeito, coma gordura suficiente e coma sempre que sentir fome. Se você se alimentar adequadamente, seu corpo naturalmente encontrará um ritmo. Depois de um tempo, muita gente percebe que só precisa de uma ou duas refeições por dia. Mas isso acontece naturalmente, não porque você forçou.
No começo, sua prioridade deve ser nutrir seu corpo, não contar horas sem comer.

7: Nem tudo é sobre dieta
À medida que você se adapta à dieta carnívora, é normal começar a prestar mais atenção no seu corpo. Você pode perceber mudanças na digestão, na pele, na energia e até no humor. Isso é ótimo! Mas aqui vai um aviso: nem tudo que acontece com o seu corpo está ligado à dieta.
Muitas pessoas caem na armadilha de analisar obsessivamente cada detalhe do seu estado de saúde e tentar atribuir tudo à alimentação. Se um dia você acorda com dor de cabeça, pode ser apenas falta de sono ou estresse, e não porque comeu carne demais ou de menos. Se um espirro aparece do nada, pode ser apenas uma reação natural do seu corpo e não um sinal de que algo está errado com sua alimentação.
A dieta carnívora tem um impacto gigante na saúde, mas não resolve tudo da noite para o dia e não é a única variável na sua vida. Existem outros fatores como qualidade do sono, níveis de estresse, exercícios físicos, exposição ao sol e até mesmo hidratação que afetam como você se sente.
Em vez de ficar obcecado com pequenas variações diárias, faça uma análise mais ampla. Compare sua saúde com a de três meses atrás, não com a de ontem. Se sua energia melhorou, se seu sono está mais profundo, se você sente menos inflamação e sua mente está mais clara, isso é o que realmente importa.
Mantenha o foco no quadro geral e evite se prender a pequenas flutuações. O objetivo aqui é viver melhor, não se tornar um escravo da busca pela perfeição.

5.2 Se você quiser fazer testes de sangue e Se você toma remédio
Painel de Sangue:Se antes de começar, você quiser fazer um exame de sangue para comparar seus resultados após alguns meses na dieta carnívora (não depois de apenas um mês, pelo amor de Deus!), aqui está uma sugestão de painel completo de exames recomendado por uma nutricionista americana renomada.
Este painel cobre desde funções metabólicas, inflamação e saúde cardiovascular até hormônios e marcadores de estresse. Converse com seu médico e veja quais desses exames fazem sentido para você!
Anexado a este módulo, você encontrará o documento completo com a lista dos exames recomendados. Faça os exames antes de começar a dieta e depois de pelo menos três a seis meses para acompanhar suas mudanças de forma mais realista.
https://docs.google.com/document/d/1-gDQDdLEYGM_Vh8id6KuHYp-R-dsYt0GXf9ub-CzizU/edit?usp=sharing

Se você toma remédio:
Se você usa qualquer tipo de medicação, é fundamental avisar o seu médico antes de iniciar a dieta carnívora. Isso porque, na medida em que sua saúde melhora, a necessidade desses medicamentos pode diminuir e, em alguns casos, continuar tomando a dose de sempre pode ser perigoso.
Por exemplo:
Se você toma remédio para pressão alta, saiba que é muito comum a pressão baixar naturalmente com a dieta carnívora. Se continuar com a dose alta do remédio, você pode acabar com pressão arterial baixa demais, causando tontura, fraqueza e até risco de desmaios.
Se você usa medicação para diabetes, como insulina ou hipoglicemiantes, seus níveis de glicose podem cair mais rápido do que o normal na carnívora. Sem ajuste no remédio, isso pode causar hipoglicemia, o que é perigoso.
O mesmo vale para remédios de tireoide, antidepressivos, anticoagulantes e outros. À medida que sua saúde melhora, as necessidades de medicação também podem mudar.
Por isso, nunca ajuste a dose sozinho. Faça isso com acompanhamento médico para garantir segurança no processo.
A dieta carnívora pode ser uma virada de chave na sua saúde, mas é essencial agir com responsabilidade quando se trata de remédios. A decisão de manter, reduzir ou suspender a medicação deve sempre ser tomada com supervisão profissional.

5.3 Possível Transição 
Se você está vindo de uma dieta rica em carboidratos, fazer uma transição mais gradual pode ser uma boa estratégia para evitar sintomas desagradáveis e facilitar a adaptação. Existem algumas abordagens diferentes para isso, e escolher a certa pode fazer toda a diferença na sua experiência inicial.
E repetindo o que falamos no vídeo anterior, se você toma medicamentos para pressão alta, diabetes, dor crônica ou depressão, é essencial conversar com seu médico. Muitas pessoas que adotam a dieta carnívora experimentam normalização da pressão arterial e dos níveis de glicose, tornando alguns medicamentos desnecessários ou exigindo ajustes nas doses.

Opções para Reduzir os Carboidratos Gradualmente
Uma forma de facilitar a transição é reduzir os carboidratos aos poucos, permitindo que seu corpo tenha tempo para se adaptar à queima de gordura como principal fonte de energia.
Estratégia 1: Transição de Seis Semanas
Se você prefere uma transição mais suave, pode seguir um cronograma de seis semanas, aumentando progressivamente a quantidade de refeições carnívoras e reduzindo a ingestão de carboidratos ao longo do tempo.
Na primeira semana, inclua três refeições totalmente carnívoras, mantendo o restante da alimentação como de costume. Na segunda semana, aumente para oito refeições carnívoras e reduza os carboidratos em 25%. Na terceira semana, faça dez refeições carnívoras e tenha dois dias completamente carnívoros. Na quarta semana, tente passar cinco dias inteiros sem carboidratos e reduza o consumo geral em 50%. Na quinta semana, sua alimentação já será 85% carnívora, com apenas duas refeições contendo carboidratos. Por fim, na sexta semana, você estará completamente adaptado à dieta carnívora, sem consumir nenhum carboidrato.
Essa abordagem permite que o sistema digestivo e o metabolismo se ajustem gradualmente, tornando a transição mais tranquila e reduzindo desconfortos comuns na mudança para uma dieta carnívora.

Estratégia 2: Desafios Curtos de Carnívora
Outra forma de se adaptar à dieta carnívora é por meio de desafios progressivos. Essa estratégia funciona muito bem para quem prefere testar aos poucos, sem a pressão de um compromisso de longo prazo.
No primeiro desafio, experimente passar três dias seguidos comendo apenas carne. Sem carboidratos, sem exceções. Foque em carnes gordas para garantir energia e observe como seu corpo reage: fome, saciedade, energia e digestão.
Na semana seguinte, aumente para sete dias carnívoros. Durante esse período, preste atenção em sinais como melhora no sono, redução de inchaço e o fim das quedas de energia ao longo do dia.
Depois, avance para duas semanas inteiras sem carboidratos. Aqui, você começa a perceber mudanças mais claras no controle da fome, menos compulsão alimentar, estabilização do humor e energia constante. Se necessário, reduza ou elimine laticínios e aumente a hidratação, dando atenção especial aos eletrólitos (sal, potássio e magnésio).
Por fim, estabeleça o objetivo de completar 30 dias 100% carnívoro. Essa é a fase de compromisso real, onde você pode documentar as mudanças mais evidentes no corpo e na mente: mais energia, clareza mental, perda de peso, melhora na composição corporal e redução de inflamações. Se quiser, registre seu progresso com fotos ou anotações diárias.
Esse método é ideal para quem gosta de desafios curtos e quer testar os benefícios da dieta carnívora de forma prática, antes de decidir adotar esse estilo de vida de vez. Além disso, permite que você observe com clareza como seu corpo reage em cada etapa, sem a necessidade de mudanças radicais e imediatas.

Estratégia 3: Reduzindo Vegetais e Carboidratos aos Poucos
SEMANA 1
Reduza 25% dos carboidratos
Elimine ultraprocessados
Aumente 1 refeição carnívora por dia

SEMANA 2
Reduza 50% dos carboidratos
Corte grãos e leguminosas
Aumente carnes e ovos
Diminua frutas ricas em açúcar (banana, manga, uvas)

SEMANA 3
Reduza vegetais ricos em amido
Sua alimentação agora deve ser 70% carnívora
Aumente a ingestão de gordura animal

SEMANA 4
Retire todas as frutas e a maior parte dos vegetais
Foque em carnes, ovos e gorduras
Inclua órgãos, como fígado (não muito e opcional)
Consumo de sal e eletrólitos é essencial

SEMANA 5
90% carnívoro: poucas ou nenhuma inclusão vegetal
Se ainda consome laticínios, analise se eles ajudam ou atrapalham

SEMANA 6
100% carnívoro: apenas carnes, ovos e gorduras
Mantenha a hidratação e ajuste eletrólitos conforme necessário
Agora você está adaptado e pode seguir conforme seu objetivo: perda de peso, saúde metabólica, etc.
Por que seguir essa estratégia?
Ideal para quem tem apego a carboidratos e prefere um passo de cada vez
Permite uma adaptação gradual
Ajuda o intestino a se ajustar à menor ingestão de fibras
Evita quedas bruscas de energia que podem ocorrer ao cortar carboidratos de uma vez
Torna a transição mais confortável e sustentável

Atenção às Reações do Corpo
Independentemente do método escolhido, é normal que o corpo passe por um período de adaptação. Algumas pessoas relatam sintomas temporários, como fadiga, dores de cabeça, tontura e alterações intestinais, como conversamos no primeiro capítulo, a gripe low carb! Isso acontece porque o metabolismo está se ajustando à queima de gordura como principal fonte de energia, um processo chamado cetoadaptação.Ou porque você está desidratado! Então tome eletrólitos também!
Essa fase inicial pode ser desafiadora, mas é temporária. No próximo módulo, falaremos sobre os sintomas mais comuns dessa adaptação e como lidar com eles da melhor maneira possível.

5.4 - Agora Você Está na Carnívora
Agora que você começou a dieta carnívora, vamos deixar tudo claro: coma carne, ovos, frutos do mar, gordura animal e beba água. Isso é tudo. Sem frescura, sem necessidade de contar calorias ou pesar comida. Quando sentir fome, coma até estar satisfeito. Quando a fome voltar, coma de novo.

O que Comer e o que Evitar
O foco principal deve ser carnes gordurosas (como carne bovina, cordeiro, porco e até frango, embora carnes mais magras precisem de um complemento de gordura), ovos, frutos do mar e gorduras animais como manteiga, ghee e banha. Você pode adicionar sal a gosto e, se quiser, incluir órgãos na alimentação, mas isso não é obrigatório.
E os órgãos?
Os órgãos são muito nutritivos, mas devem ser consumidos com moderação. O fígado, por exemplo, é uma excelente fonte de vitamina A, ferro e B12, mas exagerar pode ser tóxico devido ao seu alto teor de vitamina A. Como regra geral, consumir fígado uma ou duas vezes por semana já é o suficiente para obter os benefícios sem exagerar. Outros órgãos como coração, rins e moela são ricos em nutrientes e podem ser incluídos conforme sua preferência.
O que NÃO comer:
❌ Plantas – Nada de vegetais, grãos, legumes ou frutas.❌ Açúcar – Nem mel, nem adoçantes, nem qualquer tipo de doce.❌ Nada artificial – Isso inclui temperos industrializados, molhos prontos e bebidas que não sejam água.
Uma dúvida comum é sobre o mel. Algumas pessoas acreditam que ele pode ser consumido porque é um "produto animal". Mas, na verdade, ele nada mais é do que néctar de planta processado por abelhas. Além disso, o mel tem mais frutose do que o xarope de milho rico em frutose! Se você quer eliminar o açúcar e evitar picos de insulina, ele deve ser evitado.

Quanto Comer?
Essa é talvez a pergunta mais comum que eu recebo. E a resposta curta é: coma o suficiente para se sentir bem. Mas, para quem quer um ponto de partida, aqui vão algumas diretrizes gerais:
📌 Homens: Cerca de 900g a 1kg de carne por dia (ou mais, se o apetite pedir).📌 Mulheres: Cerca de 600g a 800g de carne por dia (mas muitas mulheres podem precisar de mais no início).
Esses valores não são regras fixas – apenas um ponto de partida. Se você ainda sente fome depois de comer essa quantidade, coma mais. Se perceber que está satisfeito com menos, reduza. O importante é escutar seu corpo.
Muitas mulheres, por exemplo, passaram a vida toda restringindo calorias e podem precisar de um período de “recuperação nutricional” para reparar danos ao metabolismo. Se seu corpo está pedindo mais comida no começo, atenda a essa necessidade.

Com Que Frequência Devo Comer?
Nos primeiros dias, coma sempre que sentir fome. Se você terminou um bife de 500g e uma hora depois sente fome de novo, coma outro bife. O objetivo é quebrar a mentalidade de restrição alimentar e garantir que você esteja consumindo nutrição de verdade, não apenas distração alimentar.
Com o tempo, seu apetite vai se regular naturalmente. Muitas pessoas relatam que, depois de algumas semanas, sentem-se satisfeitas com apenas uma ou duas grandes refeições por dia. Isso acontece porque a proteína e a gordura são muito mais saciantes do que carboidratos.
Se no início você precisa comer três ou quatro vezes ao dia, tudo bem. Seu corpo está aprendendo um novo jeito de se alimentar.

E o Jejum?
Se você está comendo carne suficiente e mantendo sua gordura em um nível adequado, naturalmente vai perceber que pode passar longos períodos sem fome. Mas isso deve acontecer de forma natural, sem forçar.
Se você sente fome três vezes ao dia, coma três vezes ao dia. Com o tempo, é possível que você reduza para duas ou até uma refeição ao dia – e tudo bem! Deixe seu corpo guiar o processo.

A Importância da Gordura e dos eletrólitos
Volte para os capítulos 1.3 e o 1.4!

E se Eu Comer Algo Errado?
Se em algum momento você acabar comendo algo fora da dieta – seja porque cedeu a uma tentação, comeu algo sem perceber ou em uma ocasião social – simplesmente volte para a carnívora na refeição seguinte.
O erro de muitas pessoas é achar que um deslize significa o fim da dieta. Não é assim! O importante é a consistência ao longo do tempo. Uma refeição ruim não estraga tudo, desde que você volte ao caminho certo imediatamente.
Com o tempo, você vai perceber que os alimentos que antes pareciam irresistíveis começam a perder o apelo. Sua relação com a comida vai mudar completamente. O que antes era uma tentação, agora pode nem parecer comida de verdade.

Conclusão: Mantenha a Simplicidade
Se tem algo que eu posso te dizer é: não complique!
📌 Coma carne, ovos, frutos do mar e gordura animal.📌 Beba água.📌 Escute seu corpo.
Essa é a base da dieta carnívora. Sem frescura, sem complicação, sem necessidade de contar calorias ou pesar comida. Quanto mais simples, melhor!Uma alimentação feita pra nosso organismo deveria ser assim. E é.

5.5 - Você Ainda Gosta de Fazer Cálculos? Proteína e Gordura na Dieta Carnívora
Embora a dieta carnívora seja extremamente simples e baseada no princípio de comer até estar satisfeito, algumas pessoas preferem calcular a ingestão de proteína e gordura para ter um controle mais preciso. Se esse for o seu caso, entender a proporção ideal de cada macronutriente pode te ajudar a otimizar sua dieta de acordo com seus objetivos e sua resposta individual.
O primeiro ponto a considerar é que a necessidade de proteína na dieta carnívora pode ser um pouco maior do que em uma dieta cetogênica tradicional. Muitas pessoas conseguem consumir mais proteína sem sair do estado metabólico de cetose. Para iniciar, uma recomendação comum é ingerir cerca de 1,8 gramas de proteína por quilo de peso corporal ideal. Por exemplo, se seu peso ideal for 60 kg, um bom ponto de partida seria consumir em torno de 110 gramas de proteína por dia.
Além da proteína, a gordura desempenha um papel essencial na dieta carnívora, pois é a principal fonte de energia. Diferente de uma dieta cetogênica tradicional, na carnívora não há carboidratos para regular os níveis de cetose, então a principal forma de ajuste será a relação entre gordura e proteína. Se você sentir que sua energia está baixa ou que não está tendo os benefícios mentais esperados, pode ser um sinal de que precisa aumentar a gordura na sua alimentação. Por outro lado, se sentir que está com pouca força ou que não está progredindo nos treinos, pode ser interessante aumentar a proteína.
A recomendação geral é manter uma proporção mínima de 1:1 entre gordura e proteína, o que significa consumir pelo menos 1g de gordura para cada 1g de proteína. No entanto, algumas pessoas se sentem melhor com proporções maiores, como 1,5:1 ou até 2:1, especialmente se buscam um estado mais cetogênico. Para atingir essas proporções, muitas vezes é necessário adicionar gordura extra às refeições, já que a maioria das carnes vendidas no mercado tem a gordura visível removida. Boas opções para aumentar a gordura na dieta incluem manteiga, banha de porco, ghee e sebo bovino. Se possível, procure cortes mais gordurosos no açougue ou peça carne moída com um teor de gordura maior.
Com o tempo, seu corpo se adapta e seu apetite se torna mais regulado, tornando o processo mais intuitivo. Já comentamos que a maioria dos homens acaba consumindo entre 900g e 1kg de carne por dia, enquanto as mulheres geralmente ficam entre 600g e 800g. Mas a melhor forma de guiar sua alimentação sempre será a sua fome e sua energia.

Como Calcular a Proporção de Gordura e ProteínaComo uma explicação bem básica e que funciona: se no final do dia você comeu uma proporção de 1g de gordura para 1g de proteína (por exemplo, 150g de proteína e 150g de gordura no dia), então aproximadamente 70% das suas calorias vieram da gordura e 30% da proteína. Esse é um cálculo útil para ajustar sua dieta de acordo com seus objetivos, seja priorizar cetose, otimizar energia ou apenas garantir um bom balanço de macronutrientes.
Se você quiser calcular a proporção exata entre gordura e proteína, é importante lembrar o valor calórico de cada macronutriente. Cada grama de proteína tem 4 kcal, enquanto cada grama de gordura tem 9 kcal.
Imagine que ao longo do dia você consumiu 200 g de proteína e 100g de gordura. A proporção de gordura para proteína seria bem baixa, 0.5 para 1. Para calcular o balanço total, basta fazer o mesmo cálculo:
200g de proteína × 4 kcal = 800 kcal de proteína
100g de gordura × 9 kcal = 900 kcal de gordura
Total de calorias no dia: 800 kcal (proteína) + 900 kcal (gordura) = 1.700 kcal
Agora, dividimos cada macronutriente pelo total de calorias:
800 kcal de proteína ÷ 1.700 kcal totais × 100 = 47% de proteína
900 kcal de gordura ÷ 1.700 kcal totais × 100 = 53% de gordura
Ou seja, 47% das calorias do dia vieram da proteína e 53% da gordura.Voce pode usar esses cálculos para qualquer proporção que você quiser.Claro que fiz um EXCEL para ajudar vocês!Cálculos Proteína vs Gordura Carnivora - Google Sheets

Conclusão: Personalize Sua Dieta Conforme Seu Corpo
O cálculo da proporção entre proteína e gordura pode ajudar a ajustar sua dieta para atender melhor às suas necessidades. Se você sente fome constante ou falta de energia, pode ser interessante aumentar a gordura. Se sente fraqueza, pouca força nos treinos ou dificuldade em ganhar massa muscular, talvez precise aumentar a proteína.
Se seu objetivo for um estado mais cetogênico, pode testar uma proporção de gordura pra proteína de 1,5:1 ou até 2:1, adicionando mais fontes de gordura à dieta. No entanto, a melhor abordagem será sempre ouvir o seu corpo. No começo, esses cálculos podem ser úteis, mas com o tempo, você perceberá que a fome e a energia serão os melhores guias para uma alimentação adequada.

5.6 - Possíveis sintomas de transição e soluções
Gente, é importantíssimo entender que não são 15 dias de dieta carnívora que vão te fazer cair duro no chão. No entanto, o período de adaptação pode trazer alguns sintomas desconfortáveis, que variam em intensidade dependendo se você fez uma transição gradual ou se mergulhou de cabeça na carnívora da noite para o dia. De qualquer forma, tudo tem solução.
Os sintomas mais comuns são conhecidos como "keto flu", ou gripe cetogênica. Isso pode incluir dificuldade de concentração, irritabilidade, dores de cabeça, desejo intenso por carboidratos, tontura, insônia, cãibras nas pernas, palpitações, falta de energia, baixa tolerância ao exercício, náusea, diarreia ou constipação. Esses sintomas costumam durar de alguns dias a no máximo duas semanas. Mas calma: se você seguir as recomendações certas, a transição pode ser muito mais tranquila ou até sem sintomas.
A boa notícia é que você pode minimizar – e muitas vezes evitar – tanto os sintomas físicos quanto os emocionais da transição. Aqui estão algumas soluções práticas:
🔹 Primeira solução: Volte à regra número 0 – Saiba seu porquê. Antes de tudo, entenda que esse processo faz parte da adaptação do seu corpo. É temporário e significa que seu organismo está aprendendo a funcionar sem carboidratos como fonte primária de energia. Se você sabe o porquê está fazendo essa mudança, fica muito mais fácil resistir a esse período inicial sem desistir.
🔹 Repondo eletrólitos ao longo do dia. Grande parte dos sintomas vem da perda de sódio, potássio e magnésio, que ocorre quando seu corpo libera líquidos extras no início da cetose. Para evitar isso, aumente o consumo de sal (salpique mais na comida, tome caldo de ossos ou até misture sal na água), coma alimentos ricos em potássio (como carne vermelha e frutos do mar) e, se necessário, complemente com magnésio. Eu tomei eletrólitos exógenos, e minhas indicações vão estar nas notas desse curso - se você mora no brasil, ou se você mora nos estados unidos
🔹 Mantenha-se bem hidratado. Beber água suficiente ajuda a evitar tontura, fadiga e cãibras musculares. Mas atenção: não exagere, porque beber água em excesso sem reposição de sal pode piorar os sintomas.
🔹 Reduza o estresse e durma bem. A adaptação pode ser mais difícil se seu corpo já estiver sobrecarregado. Priorize um sono de qualidade e tente reduzir situações estressantes. Técnicas de relaxamento, como respiração profunda e meditação, podem ajudar.
🔹 Pegue leve nos exercícios no começo. Se você sentir queda de energia ou falta de resistência, não force o treino nos primeiros dias. Isso é normal! Seu corpo ainda está aprendendo a usar gordura como combustível. Em algumas semanas, a maioria das pessoas sente um aumento na performance e na disposição.
🔹 Coma o bastante! Muita gente enfrenta sintomas porque simplesmente não come o suficiente. Se você não der ao corpo energia e nutrientes suficientes, vai sentir fraqueza, fome constante e outros efeitos da adaptação. Coma até a saciedade, sem medo de quantidade no início.
🔹 Preste atenção na gordura Se sua energia estiver baixa ou você sentir dificuldade de adaptação, pode ser que falte gordura. Lembre-se: a gordura é a fonte de energia principal na dieta carnívora. Ajuste a proporção e adicione mais gordura às refeições se for necessário.

5.7 - Recapitulando
Maravilha, senhoras e senhores. Agora vocês estão com a fórmula secreta para começar a dieta carnívora. Coma produtos derivados de animais até a saciedade, coma quando tiver com fome, beba água. Hahahahh - brincadeiras aparte, vamos recapitular o que aprendemos nesse modulo
Basicamente cobrimos tudo o que você precisa saber para iniciar e manter a dieta carnívora com sucesso. Começamos entendendo a importância de ter um motivo claro para embarcar nessa jornada, já que sem um "porquê" bem definido, as tentações e influências externas podem facilmente desviar você do caminho. Falamos também sobre a opção de fazer exames de sangue antes de começar, para que você possa comparar seus resultados após alguns meses e avaliar os impactos da dieta no seu corpo.
Depois, abordamos as possíveis estratégias de transição para tornar a adaptação mais fácil, seja reduzindo os carboidratos gradualmente ou mergulhando de cabeça na carnívora. Se você escolheu a abordagem direta, pode sentir alguns sintomas no começo, mas explicamos como minimizar esses efeitos, garantindo uma adaptação mais tranquila. Já na fase em que você está 100% na dieta, exploramos como estruturar sua alimentação de maneira simples, destacando a importância de incluir carnes, ovos, frutos do mar e gorduras animais, sem precisar contar calorias obsessivamente.
Para aqueles que gostam de números, também detalhamos como calcular a proporção entre proteína e gordura, ajudando a ajustar a dieta de acordo com seus objetivos. Além disso, discutimos os sintomas mais comuns da transição e como resolvê-los, lembrando que qualquer desconforto inicial faz parte do processo de adaptação e não significa que a dieta não está funcionando.
Agora, o mais importante é observar como você se sente ao longo do tempo. Me diga como está sua experiência após 30, 60 e 90 dias. Também, se quiser que eu te ajude mais de perto nessa jornada, pode me mandar mensagem no meu Instagram [contato removido] ou no meu e-mail: [contato removido].
